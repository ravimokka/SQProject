import React, { Component, useState, useEffect }  from "react";
import { Layout, Menu, Dropdown, Icon, Button, Avatar, Drawer, Input } from "antd";
import { Link } from "react-router-dom";
import AppRouter from "../../router";
import { NotificationTab } from "../components/Header";
import "./PageLayout.scss";
import ReactApexChart from 'react-apexcharts'
import 'bootstrap/dist/css/bootstrap.min.css';
import $ from 'jquery';
import Popper from 'popper.js';
import 'bootstrap/dist/js/bootstrap.bundle.min';
import { isAbsolute } from "path";
import "./chat.css"
import  ChatHistory from "./chat_history.js"


class ChartRoom extends Component {
  constructor(props) {
    super(props);
    this.state = {
    online:false,
    }

  }



componentWillMount() {
    var profile_data = JSON.parse(sessionStorage.getItem("session_data"));
    this.setState({User_Name:profile_data['first_name'] + "  " + profile_data['last_name']});
    this.setState({User_Email:profile_data['email']});
}

  render() {

    return (
         <div class="messaging">
  <div class="inbox_msg">
	<div class="inbox_people">
	  <div class="headind_srch">
		<div class="recent_heading">
		  <h4>Recent</h4>
		</div>
		<div class="srch_bar">
		  <div class="stylish-input-group">
			<input type="text" class="search-bar"  placeholder="Search"  / >
			</div>
		</div>
	  </div>
	  <div class="inbox_chat scroll">
		<div class="chat_list active_chat">
		  <div class="chat_people">
            <img src="https://ptetutorials.com/images/user-profile.png" alt="sunil" class="chat_img" />
			<div class="chat_ib">
			  <h5>Ravi<span class="chat_date">Dec 25</span></h5>
			  <p>Test, which is a new approach to have all solutions
				astrology under one roof.</p>
			</div>
		  </div>
		</div>
		<div class="chat_list">
		  <div class="chat_people">
          <img src="https://ptetutorials.com/images/user-profile.png" alt="sunil" class="chat_img" />
			<div class="chat_ib">
			  <h5>Surya<span class="chat_date">Dec 25</span></h5>
			  <p>Test, which is a new approach to have all solutions
				astrology under one roof.</p>
			</div>
		  </div>
		</div>
		<div class="chat_list">
		  <div class="chat_people">
          <img src="https://ptetutorials.com/images/user-profile.png" alt="sunil" class="chat_img" />
			<div class="chat_ib">
			  <h5>Anbu Deva<span class="chat_date">Dec 25</span></h5>
			  <p>Test, which is a new approach to have all solutions
				astrology under one roof.</p>
			</div>
		  </div>
		</div>
		<div class="chat_list">
		  <div class="chat_people">
          <img src="https://ptetutorials.com/images/user-profile.png" alt="sunil" class="chat_img" />
			<div class="chat_ib">
			  <h5>Vijay<span class="chat_date">Dec 25</span></h5>
			  <p>Test, which is a new approach to have all solutions
				astrology under one roof.</p>
			</div>
		  </div>
		</div>

	  </div>
	</div>
	<div class="mesgs">
	  <div class="msg_history">
		<div class="incoming_msg">
         <img src="https://ptetutorials.com/images/user-profile.png" alt="sunil" class="incoming_msg_img" />
		  <div class="received_msg">
			<div class="received_withd_msg">
			  <p>Test which is a new approach to have all
				solutions</p>
			  <span class="time_date"> 11:01 AM    |    June 9</span></div>
		  </div>
		</div>
		<div class="outgoing_msg">
		  <div class="sent_msg">
			<p>Test which is a new approach to have all
			  solutions</p>
			<span class="time_date"> 11:01 AM    |    June 9</span> </div>
		</div>
		<div class="incoming_msg">
          <img src="https://ptetutorials.com/images/user-profile.png" alt="sunil" class="incoming_msg_img" />
		  <div class="received_msg">
			<div class="received_withd_msg">
			  <p>Test, which is a new approach to have</p>
			  <span class="time_date"> 11:01 AM    |    Yesterday</span></div>
		  </div>
		</div>
		<div class="outgoing_msg">
		  <div class="sent_msg">
			<p>Apollo University, Delhi, India Test</p>
			<span class="time_date"> 11:01 AM    |    Today</span> </div>
		</div>
		<div class="incoming_msg">
           <img src="https://ptetutorials.com/images/user-profile.png" alt="sunil" class="incoming_msg_img" />
		  <div class="received_msg">
			<div class="received_withd_msg">
			  <p>We work directly with our designers and suppliers,
				and sell direct to you, which means quality, exclusive
				products, at a price anyone can afford.</p>
			  <span class="time_date"> 11:01 AM    |    Today</span></div>
		  </div>
		</div>
	  </div>
	  <div class="type_msg">
		<div class="input_msg_write">
		  <input type="text" class="write_msg" placeholder="Type a message" />
		  <button class="msg_send_btn" type="button"><i class="fa fa-paper-plane" aria-hidden="true"></i></button>
		</div>
	  </div>
	</div>
  </div>
</div>

    );
  }
}

export default ChartRoom;
