import React, { Component, useState, useEffect }  from "react";
import { Layout, Menu, Dropdown, Icon, Button, Avatar, Drawer, Input } from "antd";
import { Link } from "react-router-dom";
import AppRouter from "../../router";
import { NotificationTab } from "../components/Header";
import "./PageLayout.scss";
import ReactApexChart from 'react-apexcharts'
import 'bootstrap/dist/css/bootstrap.min.css';
import $ from 'jquery';
import Popper from 'popper.js';
import 'bootstrap/dist/js/bootstrap.bundle.min';
import { isAbsolute } from "path";
import "./chat.css"
import  ChatHistory from "./chat_history.js"


class ChartRoom extends Component {
  constructor(props) {
    super(props);
    this.state = {
    online:false,
    }

  }



componentWillMount() {
    var profile_data = JSON.parse(sessionStorage.getItem("session_data"));
    this.setState({User_Name:profile_data['first_name'] + "  " + profile_data['last_name']});
    this.setState({User_Email:profile_data['email']});
}

  render() {

    return (
     <div class="row" onload="ajax();">
        <div class="col-xs-1"></div>
            <div class="col-xs-2" class="user_list">
                <div  class="user_header">
                    <span>Users List</span>
                </div>
                 <form  method='get' action='/chatting'>
                        <ul class="list-group">
                            <li class="list-group-item"> <a href="" >
                                     Raveendra Mokka
                           {this.state.online == false?
                            <span class="online"></span> :

                            <span  class="offline"></span>
                            }
                           </a>
                            </li>
                            <li class="list-group-item"> <a href="" >
                                     Raveendra

                            {this.state.online == true?
                            <span   class="online"></span> :

                            <span class="offline"></span>
                            }
                                </a>
                            </li>
                        </ul>
                  </form>
          </div>




             <div class="col-xs-6" class="msg_head">


                <div class="select_user">
                    <span>Raveendra Mokka</span>
                </div>
                <div id="chat-box" >
                    <div id="chats" class="msg_box">

                    <ChatHistory />
                    </div>

                </div>

                <div>
                    <form method="POST" action="">
                    <div class="form-group send_text_box">
                        <input type="text" class="form-control" name="send_msg" placeholder="Enter text" />
                    </div>
                    <button type="submit" class="btn btn-primary pull-right">Send</button>
                    </form>
                </div>:

    </div>




      </div>

    );
  }
}

export default ChartRoom;
