
.user_list {
  background-color: #f5f5f5;
  margin: 0px 10px;
  border-radius: 4px;
  padding: 10px 20px 20px 20px;
  overflow-y: scroll;
  height: 350px;
  padding: 10px 0px 0px 0px;
}

.user_header{
   text-align: center;
   font-size: 18px;
   background-color: #ddd;border-radius: 4px;
   color: #5e5fa4;margin-bottom: 8px;

}

.online{
    height: 12px;
    width: 12px;
    background-color: #1fc124;
    border-radius: 6px;
    float: right;margin-top: 5px;

}


.offline{
    height: 12px;
    width: 12px;
    background-color: #8a8a8a;
    border-radius: 6px;
    float: right;margin-top: 5px;
}

.msg_head{
     background-color: #f5f5f5;
     margin: 0px 5px;
     border-radius: 4px;
     width:440px;
     padding: 10px 20px 20px 20px;
}

.select_user{
       text-align: center;
       font-size: 18px;
       color: #22aa45;
       background-color: #ddd;
       border-radius: 4px;
}


.msg_box{
        overflow-y: scroll;
        height: 350px;
        padding: 10px 0px 0px 0px;
}

.send_msg {
        text-align:right;
        padding:2px 5px;
}

.send_msg_list{
      background-color: #28a7ab;
      color:#fff;
      margin: 1px 0;
      padding: 6px 12px;
      border-radius: 12px;
}

.re_msg{
    text-align:left;
    padding:2px 5px;
}

.re_msg_list{
    background-color: #dd92b2;
    color: #fff;
    margin: 1px 0;
    padding: 6px 12px;
    border-radius: 12px;

}

.send_text_box{
   margin-right:90px;


}

.btn{
   margin-left:320px;
   margin-top:-90px;
}

