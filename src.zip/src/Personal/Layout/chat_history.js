import React, { Component, useState, useEffect }  from "react";
import { Layout, Menu, Dropdown, Icon, Button, Avatar, Drawer, Input } from "antd";
import { Link } from "react-router-dom";
import AppRouter from "../../router";
import { NotificationTab } from "../components/Header";
import "./PageLayout.scss";
import ReactApexChart from 'react-apexcharts'
import 'bootstrap/dist/css/bootstrap.min.css';
import $ from 'jquery';
import Popper from 'popper.js';
import 'bootstrap/dist/js/bootstrap.bundle.min';
import { isAbsolute } from "path";
import "./chat.css"


class ChatHistory extends Component {
  constructor(props) {
    super(props);
    this.state = {
    online:false,
    }

  }



componentWillMount() {
    var profile_data = JSON.parse(sessionStorage.getItem("session_data"));
    this.setState({User_Name:profile_data['first_name'] + "  " + profile_data['last_name']});
    this.setState({User_Email:profile_data['email']});
}

  render() {

    return (
      <div id="chat-box">

        <div class="send_msg" >
            <p>
                <span class="send_msg_list" > hi </span>
            </p>
        </div>

        <div class="re_msg">

            <p>
                <span class="re_msg_list" > hi </span>
            </p>
            <p>
                <span class="re_msg_list" > hi </span>
            </p>
            <p>
                <span class="re_msg_list" > hi </span>
            </p>
            <p>
                <span class="re_msg_list" > hi </span>
            </p>
            <p>
                <span class="re_msg_list" > hi </span>
            </p>
            <p>
                <span class="re_msg_list" > hi </span>
            </p>
            <p>
                <span class="re_msg_list" > hi </span>
            </p>
            <p>
                <span class="re_msg_list" > hi </span>
            </p>
            <p>
                <span class="re_msg_list" > hi </span>
            </p>
            <p>
                <span class="re_msg_list" > hi </span>
            </p>
            <p>
                <span class="re_msg_list" > hi </span>
            </p>
            <p>
                <span class="re_msg_list" > hi </span>
            </p>
            <p>
                <span class="re_msg_list" > hi </span>
            </p>
            <p>
                <span class="re_msg_list" > hi </span>
            </p>
            <p>
                <span class="re_msg_list" > hi </span>
            </p>
            <p>
                <span class="re_msg_list" > hi </span>
            </p>
            <p>
                <span class="re_msg_list" > hi </span>
            </p>
            <p>
                <span class="re_msg_list" > hi </span>
            </p><p>
                <span class="re_msg_list" > hi </span>
            </p>
            <p>
                <span class="re_msg_list" > hi </span>
            </p>
            <p>
                <span class="re_msg_list" > hi </span>
            </p>
            <p>
                <span class="re_msg_list" > hi </span>
            </p>
            <p>
                <span class="re_msg_list" > hi </span>
            </p>

        </div>



                </div>





    );
  }
}

export default ChatHistory;
