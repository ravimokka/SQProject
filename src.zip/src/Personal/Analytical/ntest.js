import React, { Component } from 'react';
import CanvasJSReact from '../../assets/canvasjs.react';
import 'bootstrap/dist/css/bootstrap.min.css';
import $ from 'jquery';
import Popper from 'popper.js';
import 'bootstrap/dist/js/bootstrap.bundle.min';
import { Row, Col, Card, Button, Icon, Progress } from "antd";
import Chart from 'react-apexcharts'
import ChartHistoryGroupColumn from "../components/charts/ChartHistoryGroupColumn";
import ChartBreakdownDonut from "../components/charts/ChartBreakdownDonut";


var CanvasJSChart = CanvasJSReact.CanvasJSChart;
var CanvasJS = CanvasJSReact.CanvasJS;

class Analytical extends Component {
	addSymbols(e){
		var suffixes = ["", "K", "M", "B"];
		var order = Math.max(Math.floor(Math.log(e.value) / Math.log(1000)), 0);
		if(order > suffixes.length - 1)
			order = suffixes.length - 1;
		var suffix = suffixes[order];
		return CanvasJS.formatNumber(e.value / Math.pow(1000, order)) + suffix;
	}
	render() {

const options = {
    animationEnabled: true,
    theme: "light2",
    title:{
        text:""
    },
    axisX: {
        title: "",
        reversed: true,
    },
    axisY: {
        title: "",
        labelFormatter: this.addSymbols
    },
    dataPointWidth: 20,
    height:155,
    data: [{
        type: "bar",
        showInLegend: true,
        color: "#1df20a",
        legendText: "Actual",
        dataPoints: [

            { y: 3.2, label: "Net Profit/(Loss) …" },
                ]
			},

			{
		type: "bar",
		showInLegend: true,
         color: "blue",
         Text: "test",
         legendText: "Budget",
		dataPoints: [
			{ y:  5, label: "Net Profit/(Loss) …" },

		]
	},
			]



}




const options1 = {
    title: {
        text: "NET PROFIT / LOSS"
    },
dataPointWidth: 40,
height:155,
    animationEnabled: true,
			data: [{
		type: "column",
		name: "Proven Oil Reserves (bn)",
		legendText: "Actual",
		showInLegend: true,
		color: "blue",
		dataPoints:[
			{ label: "SQBL", y: 266.21 },
			{ label: "SQCL", y: 302.25 },

		]
	},
	{
		type: "column",
		name: "Oil Production (million/day)",
		text:"Status",
		legendText: "Budget",
		axisYType: "secondary",
		showInLegend: true,
		color: "#1df20a",
		dataPoints:[
			{ label: "SQBL", y: 10.46 },
			{ label: "SQCL", y: 2.27 },

		]
	}]


}


const options2 = {
			animationEnabled: true,
			height:155,
			title: {
				text: "BUDGET ACHIEVEMENT"
			},
			subtitles: [{
				text: "100.00% Positive",
				verticalAlign: "center",
				fontSize: 50,

			}],
			data: [{
				type: "doughnut",
				color: "#1df20a",
				showInLegend: true,


			}]
}


		return (
		<div>
			<h1>FINANCIAL YEAR</h1>

<ul className="card-statistics-block">
			<button  className="btn btn-outline-secondary "><span>2019</span></button>
			</ul>
			<ul className="card-statistics-block">


	  <a class="btn btn-outline-secondary" href="#">Jul</a>

      <a class="btn btn-outline-secondary" href="#">Aug</a>
      <a class="btn btn-outline-secondary" href="#">Set</a>
      <a class="btn btn-outline-secondary" href="#">Oct</a>
      <a class="btn btn-outline-secondary" href="#">Nov</a>
      <a class="btn btn-outline-secondary" href="#">Dec</a>
      <a class="btn btn-outline-secondary" href="#">Jan</a>
      <a class="btn btn-outline-secondary" href="#">Feb</a>
      <a class="btn btn-outline-secondary" href="#">Mar</a>
      <a class="btn btn-outline-secondary" href="#">Apr</a>
      <a class="btn btn-outline-secondary" href="#">May</a>
      <a class="btn btn-outline-secondary" href="#">Jun</a>

</ul>

              <Col xs={24} sm={24} md={12} lg={24} className="c-mb">

                <Card
                  bordered={false}
                  className="mi-card mi-card-boxshadow card-statistics"
                  style={{ minHeight: "100%" }}
                >
                  <div className="card-statistics-block">
                   <CanvasJSChart

                    options = {options}
				/* onRef={ref => this.chart = ref} */
			/>

			<CanvasJSChart options = {options1}
				/* onRef={ref => this.chart = ref} */
			/>
				<CanvasJSChart options = {options2}
				/* onRef={ref => this.chart = ref} */
			/>
                  </div>
                  <div className="card-statistics-block">
                   <CanvasJSChart options = {options}
				/* onRef={ref => this.chart = ref} */
			/>
			<CanvasJSChart options = {options1}
				/* onRef={ref => this.chart = ref} */
			/>
				<CanvasJSChart options = {options2}
				/* onRef={ref => this.chart = ref} */
			/>
                  </div>


                  <div className="card-statistics-block">
                   <CanvasJSChart options = {options}
				/* onRef={ref => this.chart = ref} */
			/>
			<CanvasJSChart options = {options1}
				/* onRef={ref => this.chart = ref} */
			/>
				<CanvasJSChart options = {options2}
				/* onRef={ref => this.chart = ref} */
			/>

                  </div>
                </Card>



            </Col>





				</div>


		);
	}
}

export default Analytical;