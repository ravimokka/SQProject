import React, { Component } from 'react';
import { Row, Col, Card, Button, Icon, Progress } from "antd";
import 'bootstrap/dist/css/bootstrap.min.css';
import $ from 'jquery';
import Popper from 'popper.js';
import 'bootstrap/dist/js/bootstrap.bundle.min';
import Chart from 'react-apexcharts'
import ReactApexChart from 'react-apexcharts'
import ChartHistoryGroupColumn from "../components/charts/ChartHistoryGroupColumn";
import ChartBreakdownDonut from "../components/charts/ChartBreakdownDonut";





class Analytical extends React.Component{
      constructor(props) {
        super(props);

        this.state = {
          options: {
            plotOptions: {
              bar: {
                horizontal: true,
                dataLabels: {
                  position: 'top',
                },
              }
            },

            dataLabels: {
              enabled: false,
              offsetX: -6,
              style: {
                fontSize: '12px',
                colors: ['#1df20a']
              }
            },
            stroke: {
              show: true,
              width: 1,
              colors: ['#fff']
            },

            xaxis: {
              categories:["test"],
            }
          },

          series: [{
            data: [44]
          }, {
            data: [53]
          }],
        }

      }


  render() {
    return (
    <Col xs={24} sm={24} md={12} lg={24} className="c-mb">

                <Card
                  bordered={false}
                  className="mi-card mi-card-boxshadow card-statistics"
                  style={{ minHeight: "100%" }}
                >
                  <div className="card-statistics-block">

                  <ReactApexChart options={this.state.options} series={this.state.series} type="bar" width={300} height={150} />
                     </div>


                </Card>



            </Col>




    )
  }
}

export default Analytical;