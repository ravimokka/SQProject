import React, { Component } from 'react';
import { Row, Col, Card, Button, Icon, Progress, Form , Modal, Table} from "antd";
import 'bootstrap/dist/css/bootstrap.min.css';
import $ from 'jquery';
import Popper from 'popper.js';
import 'bootstrap/dist/js/bootstrap.bundle.min';
import Chart from 'react-apexcharts'
import ReactApexChart from 'react-apexcharts'
import ChartHistoryGroupColumn from "../components/charts/ChartHistoryGroupColumn";
import ChartBreakdownDonut from "../components/charts/ChartBreakdownDonut";
import ReactMultiSelectCheckboxes from 'react-multiselect-checkboxes';

import axios from "axios";


const t = [10, 20, 32, 34,5,63,6,75,7]



class Analytical extends React.Component {
  constructor(props) {
    super(props);
   this.state = {
        options: {
          chart: {
            shadow: {
              enabled: true,
              color: '#000',
              top: 18,
              left: 7,
              blur: 10,
              opacity: 1
            },
            toolbar: {
              show: false
            }
          },
          colors: ['#77B6EA', '#545454'],
          dataLabels: {
            enabled: true,
          },
          stroke: {
            curve: 'smooth'
          },
          title: {
            text: 't',
            align: 'left'
          },
          grid: {
            borderColor: '#e7e7e7',
            row: {
              colors: ['#f3f3f3', 'transparent'], // takes an array which will be repeated on columns
              opacity: 0.5
            },
          },
          markers: {

            size: 6
          },
          xaxis: {
            categories: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul'],
            title: {
              text: 'Month'
            }
          },
          yaxis: {
            title: {
              text: 'Temperature'
            },
            min: 5,
            max: 40
          },
          legend: {
            position: 'top',
            horizontalAlign: 'right',
            floating: true,
            offsetY: -25,
            offsetX: -5
          }
        },
        series: [
    {
            name: "High - 2013",
            data: t
          },
          {
            name: "Low - 2013",
            data: [12, 11, 14, 18, 17, 13, 13]
          }
        ],


        options1: {
            plotOptions: {
              bar: {
                horizontal: false,
                columnWidth: '55%',
                endingShape: 'rounded'
              },
            },
            dataLabels: {
              enabled: false
            },
            stroke: {
              show: true,
              width: 2,
              colors: ['transparent']
            },
            xaxis: {
              categories: ['Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct'],
            },
            yaxis: {
              title: {
                text: '$ (thousands)'
              }
            },
            fill: {
              opacity: 1
            },
            tooltip: {
              y: {
                formatter: function (val) {
                  return "$ " + val + " thousands"
                }
              }
            }
          },
          series1: [{
            name: 'Net Profit',
            data: [44, 55, 57, 56, 61, 58, 63, 60, 66]
          }, {
            name: 'Revenue',
            data: [76, 85, 101, 98, 87, 105, 91, 114, 94]
          }],






   options2: {
            plotOptions: {
              bar: {
                horizontal: true,
                dataLabels: {
                  position: 'top',
                },
              }
            },
            dataLabels: {
              enabled: true,
              offsetX: -6,
              style: {
                fontSize: '12px',
                colors: ['#fff']
              }
            },
            stroke: {
              show: true,
              width: 1,
              colors: ['#fff']
            },

            tooltip: {
              y: {
                formatter: function (val) {
                  return val + "K"
                }
              }
            },

            xaxis: {
              categories: ["Amount_USD"],
            }
          },

          series2:[],







 options3: {
            chart: {
              stacked: true,
            },
            plotOptions: {
              bar: {
                horizontal: true,
              },

            },
            stroke: {
              width: 1,
              colors: ['#fff']
            },

            title: {
              text: 'Fiction Books Sales'
            },
            xaxis: {
              categories: [2008, 2009, 2010, 2011, 2012, 2013, 2014],
              labels: {
                formatter: function (val) {
                  return val + "K"
                }
              }
            },
            yaxis: {
              title: {
                text: undefined
              },

            },
            tooltip: {
              y: {
                formatter: function (val) {
                  return val + "K"
                }
              }
            },
            fill: {
              opacity: 1

            },

            legend: {
              position: 'top',
              horizontalAlign: 'left',
              offsetX: 40
            }
          },
          series3: [{
            name: 'Marine Sprite',
            data: [44, 55, 41, 37, 22, 43, 21]
          }, {
            name: 'Striking Calf',
            data: [53, 32, 33, 52, 13, 43, 32]
          }, {
            name: 'Tank Picture',
            data: [12, 17, 11, 9, 15, 11, 20]
          }, {
            name: 'Bucket Slope',
            data: [9, 7, 5, 8, 6, 9, 4]
          }, {
            name: 'Reborn Kid',
            data: [25, 12, 19, 32, 25, 24, 10]
          }],
 options4: {
            stroke: {
              width: [0, 4]
            },
            title: {
              text: 'Traffic Sources'
            },
            labels: ['01 Jan 2001', '02 Jan 2001', '03 Jan 2001', '04 Jan 2001', '05 Jan 2001', '06 Jan 2001', '07 Jan 2001', '08 Jan 2001', '09 Jan 2001', '10 Jan 2001', '11 Jan 2001', '12 Jan 2001'
            ],
            xaxis: {
              type: 'datetime'
            },
            yaxis: [{
              title: {
                text: 'Website Blog',
              },

            }, {
              opposite: true,
              title: {
                text: 'Social Media'
              }
            }]
          },
          series4: [{
            name: 'Website Blog',
            type: 'column',
            data: [440, 505, 414, 671, 227, 413, 201, 352, 752, 320, 257, 160]
          }, {
            name: 'Social Media',
            type: 'line',
            data: [23, 42, 35, 27, 43, 22, 17, 31, 22, 22, 12, 16]
          }],

       options5: {
        chart: {
          stacked: false,
        },
        stroke: {
          width: [0, 2, 5],
          curve: 'smooth'
        },
        plotOptions: {
          bar: {
            columnWidth: '50%'
          }
        },

        fill: {
          opacity: [0.85, 0.25, 1],
          gradient: {
            inverseColors: false,
            shade: 'light',
            type: "vertical",
            opacityFrom: 0.85,
            opacityTo: 0.55,
            stops: [0, 100, 100, 100]
          }
        },
        labels: ['01/01/2003', '02/01/2003', '03/01/2003', '04/01/2003', '05/01/2003', '06/01/2003', '07/01/2003', '08/01/2003', '09/01/2003', '10/01/2003', '11/01/2003'
        ],
        markers: {
          size: 0
        },
        xaxis: {
          type: 'datetime'
        },
        yaxis: {
          title: {
            text: 'Points',
          },
          min: 0
        },
        tooltip: {
          shared: true,
          intersect: false,
          y: {
            formatter: function (y) {
              if (typeof y !== "undefined") {
                return y.toFixed(0) + " points";
              }
              return y;
            }
          }
        }
      },
      series5: [{
        name: 'TEAM A',
        type: 'column',
        data: [23, 11, 22, 27, 13, 22, 37, 21, 44, 22, 30]
      }, {
        name: 'TEAM B',
        type: 'area',
        data: [44, 55, 41, 67, 22, 43, 21, 41, 56, 27, 43]
      }, {
        name: 'TEAM C',
        type: 'line',
        data: [30, 25, 36, 30, 45, 35, 64, 52, 59, 36, 39]
      }],




options6: {
            dataLabels: {
              enabled: false
            },
            fill: {
              type: 'gradient',
            },
            legend: {
              formatter: function (val, opts) {
                return val + " - " + opts.w.globals.series[opts.seriesIndex]
              }
            },
            responsive: [{
              breakpoint: 480,
              options: {
                chart: {
                  width: 200
                },
                legend: {
                  position: 'bottom'
                }
              }
            }]
          },
          series3: [5,5,8],




          options7: {
            labels: ['Team A', 'Team B', 'Team C', 'Team D', 'Team E'],
            responsive: [{
              breakpoint: 480,
              options: {
                chart: {
                  width: 200
                },
                legend: {
                  position: 'bottom'
                }
              }
            }]
          },
          series7: [44, 55, 13, 43, 22],

    books:[],
    intHeader:[],
    filter:[],
     data:[],
     chart_data:[],
     donut_data:[]

      }



  }



  componentWillMount() {
    this.loadAnalytical();
    this.loadIntHeaders();


  }

  handleSubmit = (e) => {
     this.setState({value: e.target.value});
 };


handleSubmit = (e) => {
    e.preventDefault();
    this.setState({value: e.target.value});
     this.loadCheckbox(
         {Column:e.target.value }
  );
  };

handleSubmit12 = (e) => {
    e.preventDefault();

     this.loadData(
         {A:this.state.value, B:this.state.value1}
  );
  };




handleSubmit1 = (e) => {
    e.preventDefault();
    this.setState({value1: e.target.value});
     this.loadCheckbox(
         {Column:e.target.value }
  );
  };


  handleSubmit1 = (e) => {
    e.preventDefault();
    this.setState({value1: e.target.value});
     this.loadCheckbox(
         {Column:e.target.value }
  );
  };


  async loadAnalytical()
  {
    const promise = await axios.post("http://127.0.0.1:8070/api/v1/sqd_api", { firstName: 'Mokka Ravi', lastName: 'Flintstone' });
    const status = promise.status;
    if(status===200)
    {
      const data = promise.data.data;
      console.log(data);
      this.setState({books:data});
      const d = [{'name': 'Actual','data': []}, {'name': 'Budget','data': []}]
      const dou = [1,3,4]
      this.setState({donut_data:dou})
      this.setState({chart_data:d})
       console.log(this.state.chart_data);

    }
  }

  async loadIntHeaders()
  {
    const promise = await axios.post("http://127.0.0.1:8070/api/v1/intHeader", { firstName: 'Mokka Ravi', lastName: 'Flintstone' });
    const status = promise.status;
    if(status===200)
    {
      const data = promise.data.data;
      console.log(data);
      this.setState({intHeader:data});
      const d = [{'name': 'Actual','data': []}, {'name': 'Budget','data': []}]
      const dou = [1,3,4]
      this.setState({donut_data:dou})
      this.setState({chart_data:d})
       console.log(this.state.chart_data);

    }
  }


  async loadCheckbox(data){

    const headers  = new Headers()
    headers.append('Content-Type', 'application/json');
    const options = {
    method : 'POST',
    headers,
    body:JSON.stringify(data),
    }

    const promise = await axios.post("http://127.0.0.1:8070/api/v1/filter_api", options);
    const status = promise.status;
    if(status===200)
    {
      const data = promise.data.data;
      this.setState({filter:data});
      console.log(data);
    }

}



async loadData(data){

    const headers  = new Headers()
    headers.append('Content-Type', 'application/json');
    const options = {
    method : 'POST',
    headers,
    body:JSON.stringify(data),
    }
    this.setState({chart_data : []})
    const promise = await axios.post("http://127.0.0.1:8070/api/v1/data", options);
    const status = promise.status;
    if(status===200)
    {
      const data = promise.data.data;
      this.setState(data);
      const g_data = [this.state.Actual, this.state.Budget]
      this.setState({g:g_data})
      var i;
      var keys_list =[];
      var value_list =[];

      var chart_list = []
      for (i = 0; i < Object.keys(data).length; i++) {
            console.log(data[i])
            var key = Object.keys(data)[i]
//            keys_list.push(key)
            var value = data[key]
//            value_list.push(value)
            var data_dict = {};
            data_dict['name']=key;
            data_dict['data']=[value];
            chart_list.push(data_dict)
        }
      const d = [{'name': 'Actual','data': [this.state.Actual]}, {'name': 'Budget','data': [this.state.Budget]}]
      this.setState({c:['test']})
      this.setState({chart_data:chart_list})
      console.log(data);
    }

}

handleSubmitDonut = (e) => {
    e.preventDefault();
    this.setState({value3: e.target.value});
     this.DonutCheckbox(
         {Column:e.target.value }
  );
  };
async DonutCheckbox(data){

    const headers  = new Headers()
    headers.append('Content-Type', 'application/json');
    const options = {
    method : 'POST',
    headers,
    body:JSON.stringify(data),
    }
    this.setState({donut_data : []})
    const promise = await axios.post("http://127.0.0.1:8070/api/v1/count_api", options);
    const status = promise.status;
    if(status===200)
    {
      const data = promise.data.data;
      this.setState(data);
      console.log(data);
      var i;
      var keys_list =[];
      var value_list =[];

      var chart_list = []
      for (i = 0; i < Object.keys(data).length; i++) {
            console.log(data[i])
            var key = Object.keys(data)[i]

            keys_list.push(key)
            var value = data[key]
            if (this.state.value3 != value){value_list.push(value)}
            else {
            }

            var data_dict = {};
            data_dict['name']=key;
            data_dict['data']=[value];
            chart_list.push(data_dict)

      }
      const d_data = [this.state.SQBL, this.state.SQBL-1, this.state.SQBL-2, this.state.SQCL, this.state.SQCL-1,
                       this.state.SQBL-2]
      this.setState({donut_data:value_list})

    }

}

handleSubmitPie = (e) => {
    e.preventDefault();
    this.setState({value4: e.target.value});
     this.PieCheckbox(
         {Column:e.target.value }
  );
  };
async PieCheckbox(data){

    const headers  = new Headers()
    headers.append('Content-Type', 'application/json');
    const options = {
    method : 'POST',
    headers,
    body:JSON.stringify(data),
    }
    this.setState({donut_data : []})
    const promise = await axios.post("http://127.0.0.1:8070/api/v1/count_api", options);
    const status = promise.status;
    if(status===200)
    {
      const data = promise.data.data;
      this.setState(data);
      console.log(data);
      var i;
      var keys_list =[];
      var value_list =[];

      var chart_list = []
      for (i = 0; i < Object.keys(data).length; i++) {
            console.log(data[i])
            var key = Object.keys(data)[i]

            keys_list.push(key)
            var value = data[key]
            if (this.state.value4 != value){value_list.push(value)}
            else {
            }

            var data_dict = {};
            data_dict['name']=key;
            data_dict['data']=[value];
            chart_list.push(data_dict)

      }
      const d_data = [this.state.SQBL, this.state.SQBL-1, this.state.SQBL-2, this.state.SQCL, this.state.SQCL-1,
                       this.state.SQBL-2]
      this.setState({donut_data:value_list})

    }

}







  render() {
    return (
      <div>
        <div id="content">

          <Row type="flex" gutter={24}>
            <Col xs={24} sm={24} md={{span: 12, order: 4}} lg={12} xl={{span:12, order: 5}} className="c-mb">
              <Card
                title=""
                style={{ minHeight: "100%" }}
                bordered={false}
                className="mi-card mi-card-header-borderless mi-card-boxshadow" >
                <div id="chart">
                     {/* <div class="dropdown">
                            <button class="btn btn-default dropdown-toggle" type="button" data-toggle="dropdown">
                            Column
                           <span class="caret"></span></button>
                            <ul class="dropdown-menu" style={{ marginTop : "10.6rem", fontSize: "5px"}}>
                            {this.state.books.map((value,index)=>
                              {return   <a class="btn btn-custom btn-block btn-detail" onClick={this.handleSubmit}
                              style={{ cursor: "pointer;", fontSize: "12px"}} key={index}> {value} </a> }
                              )}
                            </ul>

                    </div>

                    <div class="dropdown" style={{ marginLeft : "5.5rem", marginTop : "-2.4rem"}}>
                            <button class="btn btn-default dropdown-toggle" type="button" data-toggle="dropdown">
                            Filter
                           <span class="caret"></span></button>
                            <ul class="dropdown-menu" style={{ marginTop : "10.6rem", fontSize: "5px"}}>
                              {this.state.books.map((value,index)=>
                              {return   <a  class="btn btn-custom btn-block btn-detail" onClick={this.handleSubmit}
                              style={{ cursor: "pointer;", fontSize: "12px"}} key={index}> {value} </a> }
                              )}
                            </ul>

                    </div>

                    <div class="dropdown" style={{ marginLeft : "10rem", marginTop : "-2.4rem"}}>
                            <button class="btn btn-default dropdown-toggle" type="button" data-toggle="dropdown">
                            Value
                           <span class="caret"></span></button>
                            <ul class="dropdown-menu">
                               {this.state.filter.map((value,index)=>
                              {return   <a  class="btn btn-custom btn-block btn-detail" onClick={this.handleSubmit}
                              style={{ cursor: "pointer;", fontSize: "12px"}} key={index}> {value} </a> }
                              )}
                            </ul>

                    </div>  */}
                    <div>




           {/*  <select class="custom-select"  value={this.state.value} onChange={this.handleSubmit}
                    style={{ width:"110px"}}>
                     <option  value="" >Column</option>
                     {this.state.books.map((value,index)=>
                              {return   <option class="btn btn-custom btn-block btn-detail" type="checkbox"
                              style={{ cursor: "pointer;", fontSize: "14px"}} key={index}> {value} </option> }
                              )}

                     </select>

<div className="dropdown" id="valueItemDrop" style={{ width:"110px"}}>
    <button className="custom-select" id="dLabel" type="button" data-toggle="dropdown" aria-haspopup="true"
        aria-expanded="false">
        Xaxis
    </button>
    <ul className="dropdown-menu" aria-labelledby="dLabel">

        <li className="checkbox form-group" size="4">

            {this.state.books.map((value,index)=>
                              {return   <label class="btn btn-custom btn-block btn-detail"
                              style={{ cursor: "pointer;", fontSize: "11px", marginTop:"-40px"}} key={index}>
                              <div style={{ marginTop:"32px;" }}>
                              <input type="checkbox" id="valuePot" value="Value Pot" name="Value Pot" style={{ marginLeft:"-135px" }}/>
                              </div>
                              {value} </label> }
                              )}

        </li>



    </ul>
</div>

<div className="dropdown" id="valueItemDrop" style={{ width:"110px", marginLeft:"150px", marginTop:"-40px"}}>
    <button className="custom-select" id="dLabel" type="button" data-toggle="dropdown" aria-haspopup="true"
        aria-expanded="false">
        Yaxis
    </button>
    <ul className="dropdown-menu" aria-labelledby="dLabel">

        <li className="checkbox form-group" size="4">

            {this.state.books.map((value,index)=>
                              {return   <label class="btn btn-custom btn-block btn-detail"
                              style={{ cursor: "pointer;", fontSize: "11px", marginTop:"-40px"}} key={index}>
                              <div style={{ marginTop:"32px;" }}>
                              <input type="checkbox" id="valuePot" value="Value Pot" name="Value Pot" style={{ marginLeft:"-135px" }}/>
                              </div>
                              {value} </label> }
                              )}

        </li>



    </ul>
</div>  */}




<select class="custom-select"  value={this.state.value} onChange={this.handleSubmit}
                    style={{ width:"110px", marginLeft:"20px" }}>
                     <option  value="" >Xaxis</option>
                     {this.state.books.map((value,index)=>
                              {return   <option class="btn btn-custom btn-block btn-detail"
                              style={{ cursor: "pointer;", fontSize: "14px"}} key={index}> {value} </option> }
                              )}


                             </select>


<select class="custom-select"  value={this.state.value1} onChange={this.handleSubmit1}
                    style={{ width:"110px", marginLeft:"20px" }}>
                     <option  value="" >Yaxis</option>
                     {this.state.books.map((value,index)=>
                              {return   <option class="btn btn-custom btn-block btn-detail"
                              style={{ cursor: "pointer;", fontSize: "14px"}} key={index}> {value} </option> }
                              )}


                             </select>

<React.Fragment>
    <button onClick={this.handleSubmit12} className='nextBtn'
      type='button'>OK</button>
    </React.Fragment>
                    {/* <select class="custom-select"  value={this.state.value} onChange={this.handleSubmit}
                    style={{ width:"110px", marginLeft:"20px" }}>
                     <option  value="" >Filter</option>
                     {this.state.books.map((value,index)=>
                              {return   <option class="btn btn-custom btn-block btn-detail"
                              style={{ cursor: "pointer;", fontSize: "14px"}} key={index}> {value} </option> }
                              )}

                     </select>

                     <select class="custom-select" value={this.state.value} onChange={this.handleSubmit}
                     style={{ width:"110px" , marginLeft:"20px"}} >
                     <option  value="" >Value</option>
                      {this.state.filter.map((value,index)=>
                              {return   <option class="custom-select"
                              style={{ cursor: "pointer;", fontSize: "12px"}} key={index}> {value} </option> }
                              )}

                    </select> */}

                  {/*   <select class="btn btn-default" value={this.state.value} onChange={this.handleSubmit}
                       style={{ width:"110px" }}>
                      {this.state.books.map((value,index)=>
                              {return   <option class="btn btn-custom btn-block btn-detail"
                              style={{ cursor: "pointer;", fontSize: "12px"}} key={index}> {value} </option> }
                              )}

                    </select>
                     <select class="btn btn-default" value={this.state.value} onChange={this.handleSubmit}
                     style={{ width:"110px" }} >
                      {this.state.filter.map((value,index)=>
                              {return   <option class="btn btn-custom btn-block btn-detail"
                              style={{ cursor: "pointer;", fontSize: "12px"}} key={index}> {value} </option> }
                              )}

                    </select> */}

                    </div>



            <ReactApexChart options={this.state.options} series={this.state.series} type="line" width="420" height="350" />
          </div>

              </Card>

            </Col>

            <Col xs={24} sm={24} md={{span: 12, order: 4}} lg={12} xl={{span:12, order: 5}} className="c-mb">
              <Card
                title="Column Charts"
                style={{ minHeight: "100%" }}
                bordered={false}
                className="mi-card mi-card-header-borderless mi-card-boxshadow" >
                <div id="chart">
             <ReactApexChart options={this.state.options2} series={this.state.series1} type="bar" width="420" height="350" />
         </div>
              </Card>
            </Col>


          </Row>


           <Row type="flex" gutter={24}>


           <Col xs={24} sm={24} md={{span: 12, order: 4}} lg={12} xl={{span:12, order: 5}} className="c-mb">
              <Card
                title="Grouped Bar Chart"
                style={{ minHeight: "100%" }}
                bordered={false}
                className="mi-card mi-card-header-borderless mi-card-boxshadow" >
                <div id="chart">
                <div>
<select class="custom-select"  value={this.state.value} onChange={this.handleSubmit}
                    style={{ width:"110px", marginLeft:"20px" }}>
                     <option  value="" >Xaxis</option>
                     {this.state.books.map((value,index)=>
                              {return   <option class="btn btn-custom btn-block btn-detail"
                              style={{ cursor: "pointer;", fontSize: "14px"}} key={index}> {value} </option> }
                              )}


                             </select>


<select class="custom-select"  value={this.state.value1} onChange={this.handleSubmit1}
                    style={{ width:"110px", marginLeft:"20px" }}>
                     <option  value="" >Yaxis</option>
                     {this.state.intHeader.map((value,index)=>
                              {return   <option class="btn btn-custom btn-block btn-detail"
                              style={{ cursor: "pointer;", fontSize: "14px"}} key={index}> {value} </option> }
                              )}


                             </select>

<React.Fragment>
    <button onClick={this.handleSubmit12} className='btn btn-info' style={{marginLeft:"20px"}}
      type='button'>OK</button>
    </React.Fragment>


                    </div>

            <ReactApexChart options={this.state.options2} series={this.state.chart_data} type="bar" width="420" height="350" />
          </div>
              </Card>
            </Col>


            <Col xs={24} sm={24} md={{span: 12, order: 4}} lg={12} xl={{span:12, order: 5}} className="c-mb">
              <Card
                title="Stacked Bar Chart"
                style={{ minHeight: "100%" }}
                bordered={false}
                className="mi-card mi-card-header-borderless mi-card-boxshadow" >
                <div id="chart">
            <ReactApexChart options={this.state.options3} series={this.state.series3} type="bar" width="420" height="350" />
          </div>
              </Card>
            </Col>


          </Row>

           <Row type="flex" gutter={24}>


            <Col xs={24} sm={24} md={{span: 12, order: 4}} lg={12} xl={{span:12, order: 5}} className="c-mb">
              <Card
                title=" Line & Column"
                style={{ minHeight: "100%" }}
                bordered={false}
                className="mi-card mi-card-header-borderless mi-card-boxshadow" >
                <div id="chart">
            <ReactApexChart options={this.state.options4} series={this.state.series4} type="line" width="420" height="350" />
          </div>
              </Card>
            </Col>

            <Col xs={24} sm={24} md={{span: 12, order: 4}} lg={12} xl={{span:12, order: 5}} className="c-mb">
              <Card
                title=" Line Column Area"
                style={{ minHeight: "100%" }}
                bordered={false}
                className="mi-card mi-card-header-borderless mi-card-boxshadow" >
                <div id="chart">
            <ReactApexChart options={this.state.options5} series={this.state.series5} type="line" width="420" height="350" />
          </div>
              </Card>
            </Col>


          </Row>


<Row type="flex" gutter={24}>
        <Col xs={24} sm={24} md={{span: 12, order: 4}} lg={12} xl={{span:12, order: 5}} className="c-mb">
            <Card
                title="Grouped Bar Chart"
                style={{ minHeight: "100%" }}
                bordered={false}
                className="mi-card mi-card-header-borderless mi-card-boxshadow" >
               <div id="chart">
                    <select class="custom-select"  value={this.state.value3} onChange={this.handleSubmitDonut}
                        style={{ width:"110px", marginLeft:"20px" }}>
                         <option  value="" >Xaxis</option>
                         {this.state.books.map((value,index)=>
                                  {return   <option class="btn btn-custom btn-block btn-detail"
                                  style={{ cursor: "pointer;", fontSize: "14px"}} key={index}> {value} </option> }
                                  )}
                   </select>
                  <ReactApexChart options={this.state.options6} series={this.state.donut_data} type="donut" width="420" height="350" />
             </div>
         </Card>
      </Col>


<Col xs={24} sm={24} md={{span: 12, order: 4}} lg={12} xl={{span:12, order: 5}} className="c-mb">
            <Card
                title="Pie chart "
                style={{ minHeight: "100%" }}
                bordered={false}
                className="mi-card mi-card-header-borderless mi-card-boxshadow" >
               <div id="chart">
                    <select class="custom-select"  value={this.state.value4} onChange={this.handleSubmitPie}
                        style={{ width:"110px", marginLeft:"20px" }}>
                         <option  value="" >Xaxis</option>
                         {this.state.books.map((value,index)=>
                                  {return   <option class="btn btn-custom btn-block btn-detail"
                                  style={{ cursor: "pointer;", fontSize: "14px"}} key={index}> {value} </option> }
                                  )}
                   </select>
                  <ReactApexChart options={this.state.options7} series={this.state.series7} type="pie" width="420" height="350" />
             </div>
         </Card>
      </Col>

</Row>





          <Row type="flex" gutter={24}>

          </Row>
        </div>
      </div>
    );
  }
}
export default Analytical;