import React, { Component } from 'react';
import { Row, Col, Card, Button, Icon, Progress } from "antd";
import 'bootstrap/dist/css/bootstrap.min.css';
import $ from 'jquery';
import Popper from 'popper.js';
import 'bootstrap/dist/js/bootstrap.bundle.min';
import Chart from 'react-apexcharts'
import ReactApexChart from 'react-apexcharts'
import ChartHistoryGroupColumn from "../components/charts/ChartHistoryGroupColumn";
import ChartBreakdownDonut from "../components/charts/ChartBreakdownDonut";
import ReactMultiSelectCheckboxes from 'react-multiselect-checkboxes';

import axios from "axios";

class Analytical extends React.Component{
  constructor(){
       super();

       this.state = {
        checkbox: false,
        inputValue: ""
       }
  }

  handleCheckbox(e){
    this.setState({checkbox: e.target.checked})
    console.log(this.state.inputValue)
  }

  handleInput(e){
    this.setState({inputValue: e.target.value})

  }

  render(){
    return (
        <div>
        <input type="checkbox" onChange={this.handleCheckbox.bind(this)} checked={this.state.checkbox}/>
        <input type="text" value={this.state.inputValue} onChange={this.handleInput.bind(this)}/>
      </div>
    )
  }
}


export default Analytical;

