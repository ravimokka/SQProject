import { Chart, Tooltip, Axis, Legend, Pie, Coord } from 'viser-react';
import * as React from 'react';
import { Row, Col, Card, Button, Icon, Progress, Form , Modal, Table} from "antd";
import axios from "axios";
import ReactApexChart from 'react-apexcharts'
const CollectionCreateForm = Form.create({ name: "form_in_modal" })(
  // eslint-disable-next-line
class extends React.Component {
  constructor(props) {
    super(props);
    this.state = {

    };
  }
    render() {
      const { visible, onCancel, onCreate, form } = this.props;
      const { getFieldDecorator } = form;

      const formItemLayout = {
        labelCol: {
          xs: { span: 240 },
          sm: { span: 8 }
        },
        wrapperCol: {
          xs: { span: 24 },
          sm: { span: 16 }
        }
      };


const columns = [{title: 'Order Number',dataIndex: 'oNumber',key: 'oNumber',}]

const data = [
  {
    key: '1',
    oNumber: 'DVO524',
    confDate: '05/07/2019',
    customer: 'Jone Deo',
    salePer: 'SQBL',
    total: '$26300',
    tags: ['Success'],
  }]




      return (
        <Modal visible={visible}
          title="Create a new collection"
          okText=""
          onCancel={onCancel}
          onOk={onCreate}
        style={{overflowY:"scroll", maxHeight:"500%", marginTop:"50px", marginBottom:"50px"}}>
         <Table columns={columns} dataSource={data} />
        </Modal>
      );
    }
  }
);

const DataSet = require('@antv/data-set');
const scale = [{
  dataKey: 'percent',
  min: 0,
  formatter: '.0%',
}];


const scale1 = [{
  dataKey: 'percent',
  min: 0,
  formatter: '.0%',
}];




const sourceData12 = [
  { item: 'A', count: 40 },
  { item: 'B', count: 21 },
  { item: 'C', count: 17 },
  { item: 'D', count: 13 },
  { item: 'E', count: 9 }
];




class AnalyticalTest extends React.Component {

 constructor(props) {
    super(props);
   this.state = {

options2: {
            plotOptions: {
              bar: {
                horizontal: true,
                dataLabels: {
                  position: 'top',
                },
              }
            },
            dataLabels: {
              enabled: false,
              offsetX: -6,
              style: {
                fontSize: '12px',
                colors: ['#fff']
              }
            },
            stroke: {
              show: true,
              width: 1,
              colors: ['#fff']
            },

            xaxis: {
              categories: [""],
            }
          },

          series2:[],


          series2:[],




    books:[],
     intHeader:[],
     filter:[],
     chart_data:[],
     donut_data:[],
     pie_data:[],
     l:[],
     sourceData :[
  { item: 'A', count: 20 }
],

sourceData_donut:[{ item: 'B', count: 2 }]

      }


   }

 showModal = () => {
    this.setState({ modalVisible: true });
  };

  handleCancel = () => {
    this.setState({ modalVisible: false });
  };



  saveFormRef = formRef => {
    this.formRef = formRef;
  };

  showDrawer = () => {
    this.setState({
      drawerVisible: true
    });
  };

  onClose = () => {
    this.setState({
      drawerVisible: false
    });
  };





   componentWillMount() {
    this.loadAnalytical();
     this.loadIntHeaders();


  }

   async loadAnalytical()
  {
    const promise = await axios.post("http://127.0.0.1:8070/api/v1/sqd_api", { firstName: 'Mokka Ravi', lastName: 'Flintstone' });
    const status = promise.status;
    if(status===200)
    {
      const data = promise.data.data;
      console.log(data);

      this.setState({books:data});
      const d = [{'name': 'Actual','data': []}, {'name': 'Budget','data': []}]
      this.setState({chart_data:d})
       console.log(this.state.chart_data);

    }
  }

async loadIntHeaders()
  {
    const promise = await axios.post("http://127.0.0.1:8070/api/v1/intHeader", { firstName: 'Mokka Ravi', lastName: 'Flintstone' });
    const status = promise.status;
    if(status===200)
    {
      const data = promise.data.data;
      console.log(data);
      this.setState({intHeader:data});
      const d = [{'name': 'Actual','data': []}, {'name': 'Budget','data': []}]
      const dou = [1,3,4]
      this.setState({donut_data:dou})
      this.setState({chart_data:d})
       console.log(this.state.chart_data);

    }
  }




handleSubmit = (e) => {
     this.setState({value_x: e.target.value});
 };

handleSubmit1 = (e) => {
    this.setState({value_y: e.target.value});
  };


handleSubmit12 = (e) => {
    e.preventDefault();

     this.loadData(
         {A:this.state.value_x, B:this.state.value_y}
  );
  };


async loadData(data){

    const headers  = new Headers()
    headers.append('Content-Type', 'application/json');
    const options = {
    method : 'POST',
    headers,
    body:JSON.stringify(data),
    }
    this.setState({chart_data : []})
 const promise = await axios.post("http://127.0.0.1:8070/api/v1/data", options);
    const status = promise.status;
    if(status===200)
    {
      const data = promise.data.data;
      this.setState(data);
      var i;
      var keys_list =[];
      var value_list =[];

      var chart_list = []
      for (i = 0; i < Object.keys(data).length; i++) {
            console.log(data[i])
            var key = Object.keys(data)[i]
//            keys_list.push(key)
            var value = data[key]
//            value_list.push(value)
            var data_dict = {};
            data_dict['name']=key;
            data_dict['data']=[value];
            chart_list.push(data_dict)
        }

      const g_data = [this.state.Actual, this.state.Budget]
      this.setState({g:g_data})
//
//      const d = [{'name': 'Actual','data': [this.state.Actual]}, {'name': 'Budget','data': [this.state.Budget]}]
//      this.setState({c:['test']})
     const d = [{'name': 'Actual','data': [1, 23]}, {'name': 'Budget','data': [1, 2,4,5]}]
      this.setState({chart_data:chart_list})
      console.log(data);
    }

}


handleSubmitDonut = (e) => {
    e.preventDefault();
    this.setState({value_donut: e.target.value});
     this.DonutCheckbox(
         {Column:e.target.value }
  );
  };
async DonutCheckbox(data){

    const headers  = new Headers()
    headers.append('Content-Type', 'application/json');
    const options = {
    method : 'POST',
    headers,
    body:JSON.stringify(data),
    }

    this.setState({sourceData_donut : []})
    const promise = await axios.post("http://127.0.0.1:8070/api/v1/count_api", options);
    const status = promise.status;
    if(status===200)
    {
      const data = promise.data.data;
      this.setState(data);
      console.log(data);
      var i;
      var keys_list =[];
      var value_list =[];

      var chart_list = []
      var ct_list1 = []
      for (i = 0; i < Object.keys(data).length; i++) {
            console.log(data[i])
            var key = Object.keys(data)[i]

            keys_list.push(key)
            if (key != "label"){
            ct_list1.push(key)

            }
            else{}

            var value = data[key]
            if (this.state.value != value){value_list.push(value)}
            else {
            }

            var data_dict = {};
            if (key != "label"){
            data_dict['item']=key;
            data_dict['count']=value;
            chart_list.push(data_dict)

            }
            else{}


        }
        const sd = [{ item: 'D', count: 8000}, { item: '2019/2001', count: 800}]
         console.log(chart_list);
      this.setState({sourceData_donut:chart_list})
      const d_data = [this.state.SQBL, this.state.SQBL-1, this.state.SQBL-2, this.state.SQCL, this.state.SQCL-1,
                       this.state.SQBL-2]
      this.setState({donut_data:value_list})

    }

}








   handleSubmitPie = (e) => {
    e.preventDefault();
    this.setState({value_pie: e.target.value});
     this.PieCheckbox(
         {Column:e.target.value }
  );
  };
async PieCheckbox(data){

    const headers  = new Headers()
    headers.append('Content-Type', 'application/json');
    const options = {
    method : 'POST',
    headers,
    body:JSON.stringify(data),
    }

    this.setState({sourceData : []})
    const promise = await axios.post("http://127.0.0.1:8070/api/v1/count_api", options);
    const status = promise.status;
    if(status===200)
    {
      const data = promise.data.data;
      this.setState(data);
      console.log(data);
      var i;
      var keys_list =[];
      var value_list =[];

      var chart_list = []
      var ct_list1 = []
      for (i = 0; i < Object.keys(data).length; i++) {
            console.log(data[i])
            var key = Object.keys(data)[i]

            keys_list.push(key)
            if (key != "label"){
            ct_list1.push(key)

            }
            else{}

            var value = data[key]
            if (this.state.value != value){value_list.push(value)}
            else {
            }

            var data_dict = {};
            if (key != "label"){
            data_dict['item']=key;
            data_dict['count']=value;
            chart_list.push(data_dict)

            }
            else{}


        }
        const sd = [{ item: 'D', count: 8000}, { item: '2019/2001', count: 800}]
         console.log(chart_list);
      this.setState({sourceData:chart_list})
      const d_data = [this.state.SQBL, this.state.SQBL-1, this.state.SQBL-2, this.state.SQCL, this.state.SQCL-1,
                       this.state.SQBL-2]
      this.setState({donut_data:value_list})

    }

}


  render() {


const dv = new DataSet.View().source(this.state.sourceData);
dv.transform({
  type: 'percent',
  field: 'count',
  dimension: 'item',
  as: 'percent',
  align: 'left'
});
const pie_data = dv.rows;


const dv1 = new DataSet.View().source(this.state.sourceData_donut);
dv1.transform({
  type: 'percent',
  field: 'count',
  dimension: 'item',
  as: 'percent'
});
const don_data = dv1.rows;






    return (

    <div>
        <div id="content">
           <Row type="flex" gutter={24}>



            <Col xs={24} sm={24} md={{span: 12, order: 4}} lg={12} xl={{span:12, order: 5}} className="c-mb">
            <Card
                title="Group Bar chart "
                style={{ minHeight: "100%" }}
                bordered={false}
                className="mi-card mi-card-header-borderless mi-card-boxshadow" >
               <div id="chart">
                    <select class="custom-select"  value={this.state.value_x} onChange={this.handleSubmit}
                        style={{ width:"110px", marginLeft:"20px" }}>
                         <option  value="" >Xaxis</option>
                         {this.state.books.map((value,index)=>
                                  {return   <option class="btn btn-custom btn-block btn-detail"
                                  style={{ cursor: "pointer;", fontSize: "14px"}} key={index}> {value} </option> }
                                  )}
                   </select>

                   <select class="custom-select"  value={this.state.value_y} onChange={this.handleSubmit1}
                        style={{ width:"110px", marginLeft:"20px" }}>
                         <option  value="" >Yaxis</option>
                         {this.state.intHeader.map((value,index)=>
                                  {return   <option class="btn btn-custom btn-block btn-detail"
                                  style={{ cursor: "pointer;", fontSize: "14px"}} key={index}> {value} </option> }
                                  )}
                   </select>


    <React.Fragment>
    <button onClick={this.handleSubmit12} className='btn btn-info' style={{marginLeft:"10px"}}
      type='button'>OK</button>
    </React.Fragment>
   <React.Fragment>
        <button onClick={this.showModal} className='btn btn-primary' style={{marginLeft:"10px"}}
          type='button'>Table View</button>
          <CollectionCreateForm
              wrappedComponentRef={this.saveFormRef}
              visible={this.state.modalVisible}
              onCancel={this.handleCancel}
              onCreate={this.handleCreate}
          />
    </React.Fragment>



                  <ReactApexChart options={this.state.options2} series={this.state.chart_data} type="bar" width="420" height="350" />
             </div>
         </Card>
      </Col>


  <Col xs={24} sm={24} md={{span: 12, order: 4}} lg={12} xl={{span:12, order: 5}} className="c-mb">

        <Card
                title="Donut chart "
                style={{ minHeight: "100%" }}
                bordered={false}
                className="mi-card mi-card-header-borderless mi-card-boxshadow" >
         <div id="chart">
        <select class="custom-select"  value={this.state.value_donut} onChange={this.handleSubmitDonut}
                    style={{ width:"110px", marginLeft:"20px" }}>
                     <option  value="" >Xaxis</option>
                     {this.state.books.map((value,index)=>
                              {return   <option class="btn btn-custom btn-block btn-detail"
                              style={{ cursor: "pointer;", fontSize: "14px"}} key={index}> {value} </option> }
                              )}


                             </select>

        <Chart forceFit height={400} data={don_data} scale={scale1}>
        <Tooltip showTitle={false} />
        <Axis />
        <Legend dataKey="item" />
        <Coord type="theta" radius={0.75} innerRadius={0.6} />
        <Pie position="percent" color="item" style={{ stroke: '#fff', lineWidth: 1 }}
          label={['percent', {
            formatter: (val, item) => {
              return item.point.item + ': ' + val;
            }
          }]}
        />
      </Chart>
                             </div>


        </Card>


      </Col>




 </Row>


<Row type="flex" gutter={24}>




    <Col xs={24} sm={24} md={{span: 12, order: 4}} lg={12} xl={{span:12, order: 5}} className="c-mb">

        <Card
                title="Pie chart "
                style={{ minHeight: "100%" }}
                bordered={false}
                className="mi-card mi-card-header-borderless mi-card-boxshadow" >
         <div id="chart">
        <select class="custom-select"  value={this.state.value_pie} onChange={this.handleSubmitPie}
                    style={{ width:"110px", marginLeft:"20px" }}>
                     <option  value="" >Xaxis</option>
                     {this.state.books.map((value,index)=>
                              {return   <option class="btn btn-custom btn-block btn-detail"
                              style={{ cursor: "pointer;", fontSize: "14px"}} key={index}> {value} </option> }
                              )}


                             </select>

        <Chart forceFit height={400} data={pie_data} scale={scale} >
            <Tooltip showTitle={false} />
            <Coord type="theta" />
            <Axis />
            <Legend dataKey="item" />
                            <Pie
          position="percent"
          color="item"
          style={{ stroke: '#fff', lineWidth: 1 }}
          label={['percent', {
            formatter: (val, item) => {
              return item.point.item + ': ' + val;
            }
          }]}
        />
       </Chart>
                             </div>


        </Card>


      </Col>


 </Row>


  <Row type="flex" gutter={24}>

     </Row>


        </div>
      </div>

    );
  }
}





export default AnalyticalTest;