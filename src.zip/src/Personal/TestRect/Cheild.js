import React, { Component } from "react";

import { Row, Col, Card, Button, Icon, Progress } from "antd";

import Parent from "./React";

import { Test } from  "../Test";
const DataSet = require("@antv/data-set");






class Child2 extends React.Component {
 constructor(props) {
    super(props);
   this.state = {
     value_pie :'',
     count:0,
     name:' test react'
   };
   this.test = this.handleSubmit.bind(this);
 }

 handleSubmit = (e) => {
    e.preventDefault();
    this.setState({count:'200'});
    this.setState({name:'mokka ravi'});
 };

render() {
      return (
            <div>
               <span>{this.state.count}</span>

                <Test trigger= {this.handleSubmit}  name = {this.state.name}/>

            </div>

        );
    }
}
export default Child2;


