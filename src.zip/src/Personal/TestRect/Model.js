import React, { Component } from 'react';
import { Row, Col, Card, Button, Icon, Progress,Table } from "antd";
import 'bootstrap/dist/css/bootstrap.min.css';
import $ from 'jquery';
import Popper from 'popper.js';
import 'bootstrap/dist/js/bootstrap.bundle.min';
import Chart from 'react-apexcharts'
import ReactApexChart from 'react-apexcharts'
import ChartHistoryGroupColumn from "../components/charts/ChartHistoryGroupColumn";
import ChartBreakdownDonut from "../components/charts/ChartBreakdownDonut";
import ReactMultiSelectCheckboxes from 'react-multiselect-checkboxes';


class Reactjs extends React.Component {
constructor(props) {
    super(props);
    this.state = {

line_table_columns : [{ title: 'Order Number',dataIndex: 'oNumber', key: 'oNumber',}],
line_table_data : [{ key: '1', oNumber: 'DVO524',}],



    };
  }

  render(){




    return (
   <div class="container">
   <button type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#myModal">Open Modal</button>
  <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
         {/* <button type="button" class="close" data-dismiss="modal" style={{marginLeft:"1px"}}>&times;</button> */}
          <h4 class="modal-title">Modal Header</h4>
        </div>
        <div class="modal-body">
         <Table columns={this.state.line_table_columns} dataSource={this.state.line_table_data} style={{overflowY:"scroll"}}/>

        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-info" data-dismiss="modal">Close</button>
          <button type="button" class="btn btn-primary" >Download</button>
        </div>
      </div>

    </div>
  </div>

</div>
    )
  }
}


export default Reactjs;
