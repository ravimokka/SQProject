import React, { Component, Router, Switch, Route, App } from "react";
import { Chart, Tooltip, Axis, Legend, Bar, Line} from "viser-react";

import Child2 from "./Reactjs";

class Parent extends React.Component {

constructor(props) {
    super(props);
   }
state = { data : "Hello World" }
render() {

        return (
            <div>

              <button onClick={this.props.trigger}> Update </button>
              <p>{this.props.name}</p>
              <p>{this.props.name}</p>
              <p>{this.props.name}</p>
            </div>
        );
    }
}
export default Parent;
