import React, { Component } from "react";
import {Link, Switch, Route } from "react-router-dom";
import { Row, Col, Card, Button, Icon, Progress} from "antd";
import SweetAlert from 'react-bootstrap-sweetalert';
import Parent from "./React";

import { Test } from  "../Test";
const DataSet = require("@antv/data-set");





   {/*
   class Child2 extends React.Component {
 constructor(props) {
    super(props)
    this.state = {
      sistemas: [],
      fromChild: 'empty',
      x:'tes1234t'
    };

  }

  update = (data) => {
    this.setState({fromChild: data})
    this.props.history.push("/test-react");

  }

  render() {
    return (
      <div className="App">
        <h1>Parent Component </h1>
        <p>data coming from child<b>: {this.state.fromChild} </b></p>
       <Test update={this.update}  data={this.state.x}/>
      </div>
    );
  }
}

export default Child2;
*/}



class Child2 extends React.Component {
 constructor(props) {
    super(props)
    this.state = {
      sistemas: [],
      fromChild: 'empty',
      x:{id: 1, name: 'Ford', color: 'mokka raveendra'}
    };

  }

  update = (data) => {
    this.setState({fromChild: data})
    this.props.history.push("/test-react");


  }

  render() {

    return (
      <div className="App">
       <SweetAlert
  success
  title="Woot!"
  onConfirm={this.hideAlert}
>
  I did it!
</SweetAlert>
      </div>
    );
  }
}

export default Child2;


