import React from "react";
import { css } from "@emotion/core";
// First way to import
import { ClipLoader } from "react-spinners";
import { FadeLoader	 } from "react-spinners";
import { RingLoader} from "react-spinners";


// Can be a string as well. Need to ensure each key-value pair ends with ;


class AwesomeComponent extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
    loading: false
    };
  }

  onClick = () => {
  /*
    Begin by setting loading = true, and use the callback function
    of setState() to make the ajax request. Set loading = false after
    the request completes.
  */
  this.setState({ loading: true }, () => {})

}

  render() {
  const override = css`
  display: block;
  margin: 0 auto;
  border-color: red;
  loading: true;
  color: "red";
  css: "";
`;
    return (
      <div>
       <button onClick={this.onClick}>
            Load Data
          </button>
        <RingLoader
          css={override}
          size={100} // or 150px
          color={"#123abc"}
          loading={this.state.loading}
        />
      </div>
    );
  }
}
 export default AwesomeComponent;