import React, { Component } from "react";

import { Row, Col, Card, Button, Icon, Progress } from "antd";


import ChartBreakdownDonut from "./ChartBreakdownDonut";
const DataSet = require("@antv/data-set");

class BankPersonal extends Component {
  constructor(props) {
    super(props);
    this.state = {
      chartData: [],
      selectedKey: "daily"
    };

  }
  render() {
    return (
      <div>

        <div id="content">
          <Row type="flex" gutter={24}>

            <Col xs={24} sm={24} md={{span: 12, order: 4}} lg={12} xl={{span:8, order: 5}} className="c-mb">
              <Card
                title="Breakdown"
                style={{ minHeight: "100%" }}
                bordered={false}
                className="mi-card mi-card-header-borderless mi-card-boxshadow"
              >
                <div>
                  <ChartBreakdownDonut />
                </div>
              </Card>
            </Col>

          </Row>
          <Row type="flex" gutter={24}>

          </Row>
        </div>
      </div>
    );
  }
}
export default BankPersonal;

