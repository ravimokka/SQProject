import { Chart, Tooltip, Axis, Legend, Pie, Coord, Line, Bar, Point} from 'viser-react';
import * as React from 'react';
import { Row, Col, Card, Button, Icon, Progress, Form , Modal, Table} from "antd";
import axios from "axios";
import ReactApexChart from 'react-apexcharts'
import 'bootstrap/dist/css/bootstrap.min.css';
import $ from 'jquery';
import Popper from 'popper.js';
import 'bootstrap/dist/js/bootstrap.bundle.min';


const DataSet = require('@antv/data-set');

class LineChart extends React.Component {

 constructor(props) {
    super(props);
   this.state = {






             books:[],
             intHeader:[],
             filter:[],
             select_status:"Status",
             select_amount_USD:"Amount_USD",
             chart_data:[],
             donut_data:[],
             pie_data:[],
             bar_data:[],
             ve_bar_data:[],
             line_data:[{name:"", 'A':1, 'B':12}],
             field_list:["A","B"],
             chartData: [],
             sourceData :[],
             line_chart_source_data:[{name: 'A', value: 13000000}],
             sourceData_donut:[],

             table_columns : [{ title: 'Order Number',dataIndex: 'oNumber', key: 'oNumber',}],
             table_data : [{ key: '1', oNumber: 'DVO524',}],


             load_table_columns : [{ title: 'Order Number',dataIndex: 'oNumber', key: 'oNumber',}],
             load_table_data : [{ key: '1', oNumber: 'DVO524',}],

             line_table_columns : [{ title: 'Order Number',dataIndex: 'oNumber', key: 'oNumber',}],
             line_table_data : [{ key: '1', oNumber: 'DVO524',}],

             bar_table_columns : [{ title: 'Order Number',dataIndex: 'oNumber', key: 'oNumber',}],
             bar_table_data : [{ key: '1', oNumber: 'DVO524',}],

             vertical_table_columns : [{ title: 'Order Number',dataIndex: 'oNumber', key: 'oNumber',}],
             vertical_table_data : [{ key: '1', oNumber: 'DVO524',}],

             Gbar_table_columns : [{ title: 'Order Number',dataIndex: 'oNumber', key: 'oNumber',}],
             Gbar_table_data : [{ key: '1', oNumber: 'DVO524',}],

             donut_table_columns : [{ title: 'Order Number',dataIndex: 'oNumber', key: 'oNumber',}],
             donut_table_data : [{ key: '1', oNumber: 'DVO524',}],

             pie_table_columns : [{ title: 'Order Number',dataIndex: 'oNumber', key: 'oNumber',}],
             pie_table_data : [{ key: '1', oNumber: 'DVO524',}],

             mix_table_columns : [{ title: 'Order Number',dataIndex: 'oNumber', key: 'oNumber',}],
             mix_table_data : [{ key: '1', oNumber: 'DVO524',}],
             value_xl : "Status",
             value_yl : "Amount_USD",
   }
}

// ============================= Loading all charts ====================================================================

componentWillMount() {
    this.loadAnalytical();
     this.loadIntHeaders();
     this.loadAll_count_view();
  }

 async loadAnalytical()
  {
    const promise = await axios.post("http://127.0.0.1:8070/api/v1/sqd_api");
    const status = promise.status;
    if(status===200)
    {
      const data = promise.data.data;
      console.log(data);
      this.setState({books:data});
    }
  }

async loadIntHeaders()
  {
    const promise = await axios.post("http://127.0.0.1:8070/api/v1/intHeader");
    const status = promise.status;
    if(status===200)
    {
      const data = promise.data.data;
      console.log(data);
      this.setState({intHeader:data});
      const d = [{'name': 'Actual','data': []}, {'name': 'Budget','data': []}]
      const dou = [1,3,4]
      this.setState({donut_data:dou})
      this.setState({chart_data:d})
       console.log(this.state.chart_data);

    }
  }

async loadAll_count_view()
  {
    this.setState({table_columns : []})
    this.setState({table_data : []})
    const promise = await axios.post("http://127.0.0.1:8070/api/v1/load_count_api");
    const status = promise.status;
    if(status===200)
    {
      const data = promise.data.data;
      var i;
      var keys_list =[];
      var bar_value_list =[];
      var load_chart_list = [];
      var load_donut_chart_list = [];
      var ct_list1 = [];
      var table_column_list = [];
      var table_data_list = [];
      var table_data_dict = {}
      for (i = 0; i < Object.keys(data).length; i++) {
            console.log(data[i])
            var key = Object.keys(data)[i]

            keys_list.push(key)
            if (key != "label"){
            ct_list1.push(key)

            }
            else{}

            var value = data[key]
            if (this.state.value_bar != value){bar_value_list.push(value)}
            else {
            }

            var data_dict = {};

            var load_data_dict = {};
            if (key != "label"){
            data_dict['name']=key;
            load_data_dict['item']=key;
            data_dict['value']=value;
            load_data_dict['count']=value;
            load_chart_list.push(data_dict)
            load_donut_chart_list.push(load_data_dict)
            var column_dict = {}
            column_dict['title'] =key;
            column_dict['dataIndex'] =key;
            column_dict['key'] =key;
            table_data_dict[key] = value;
            table_column_list.push(column_dict)
            }
            else{}
        }
      table_data_list.push(table_data_dict)
      this.setState({bar_data:load_chart_list})
      this.setState({ve_bar_data:load_chart_list})
      this.setState({sourceData:load_donut_chart_list})
      this.setState({sourceData_donut:load_donut_chart_list})

      this.setState({bar_table_columns:table_column_list})
      this.setState({bar_table_data:table_data_list})

      this.setState({vertical_table_columns:table_column_list})
      this.setState({vertical_table_data:table_data_list})

      this.setState({donut_table_columns:table_column_list})
      this.setState({donut_table_data:table_data_list})

      this.setState({pie_table_columns:table_column_list})
      this.setState({pie_table_data:table_data_list})
    }
  }

//========================================== Bar Chart ================================================================
handleSubmitBarChart = (e) => {
        e.preventDefault();
        this.setState({value_bar: e.target.value});
         this.BarCheckbox(
             {Column:e.target.value }
      );
 };


async BarCheckbox(data){
    const headers  = new Headers()
    headers.append('Content-Type', 'application/json');
    const options = {
    method : 'POST',
    headers,
    body:JSON.stringify(data),
    }

    this.setState({bar_data : []})

    this.setState({bar_table_columns:[]})
    this.setState({bar_table_data:[]})

    const promise = await axios.post("http://127.0.0.1:8070/api/v1/count_api", options);
    const status = promise.status;
    if(status===200)
    {
      const data = promise.data.data;
      this.setState(data);
      console.log(data);
      var i;
      var keys_list =[];
      var bar_value_list =[];
      var Bar_chart_list = []
      var ct_list1 = []
      var table_column_list = [];
      var table_data_list = [];
      var table_data_dict = {}

      for (i = 0; i < Object.keys(data).length; i++) {
            console.log(data[i])
            var key = Object.keys(data)[i]
            keys_list.push(key)
            if (key != "label"){
            ct_list1.push(key)

            }
            else{}

            var value = data[key]
            if (this.state.value_bar != value){bar_value_list.push(value)}
            else {
            }

            var data_dict = {};
            if (key != "label"){
            data_dict['name']=key;
            data_dict['value']=value;
            Bar_chart_list.push(data_dict)

            var column_dict = {}
            column_dict['title'] =key;
            column_dict['dataIndex'] =key;
            column_dict['key'] =key;
            table_data_dict[key] = value;
            table_column_list.push(column_dict)


            }
            else{}
        }

      table_data_list.push(table_data_dict)
      this.setState({bar_data:Bar_chart_list})
      this.setState({bar_table_columns:table_column_list})
      this.setState({bar_table_data:table_data_list})


    }

}


//=================================================== Line Chart Table Data Download ===================================
render() {


const bar_dv = new DataSet.View().source(this.state.bar_data);
bar_dv.transform({
  type: 'sort',
  callback(a, b) {
    return a.value - b.value > 0;
  },
});
const basic_bar_data = bar_dv.rows;


const line_chart_source_scale = [{
  dataKey: 'value',
  min: 0,
  formatter: function formatter(val) {
             if (val < 100000) {
                 return Math.round((val/1000) * 10)/10+'k';
              }
            else if (val >= 1000000){
               return val=(val/1000000)+"M";

            }
             else {
                return val;
            }
        }
},{
  dataKey: 'year',
  min: 0,
  max: 1,
}];

    return (

       <div id="chart">
                    <select class="custom-select"  value={this.state.value_bar} onChange={this.handleSubmitBarChart}
                        style={{ width:"110px", marginLeft:"20px" }}>
                         <option>{this.state.select_status}</option>
                         {this.state.books.map((value,index)=>
                                  {return   <option class="btn btn-custom btn-block btn-detail"
                                  style={{ cursor: "pointer;", fontSize: "14px"}} key={index}> {value} </option> }
                                  )}
                   </select>
                    <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#myModalBar" style={{marginLeft:"3px"}}>
                    Table View</button>
                      <div class="modal fade" id="myModalBar" role="dialog">
                        <div class="modal-dialog">
                          <div class="modal-content">
                            <div class="modal-header">
                             {/* <button type="button" class="close" data-dismiss="modal" style={{marginLeft:"1px"}}>&times;</button> */}
                              <h4 class="modal-title">Bar Chart Table Data</h4>
                            </div>
                            <div class="modal-body">
                             <Table columns={this.state.bar_table_columns} dataSource={this.state.bar_table_data} style={{overflowY:"scroll"}}/>

                            </div>
                            <div class="modal-footer">
                              <button type="button" class="btn btn-info" data-dismiss="modal">Close</button>
                              <button type="button" class="btn btn-primary" >Download</button>
                            </div>
                          </div>

                        </div>
                      </div>

               <Chart forceFit height={400} data={basic_bar_data} scale={line_chart_source_scale}>
                    <Coord type="rect" direction="LB" />
                    <Tooltip />
                    <Axis dataKey="country" label={{ offset: 12 }} />
                    <Bar position="name*value" />
                 </Chart>
            </div>
    );
  }
}
export default LineChart;