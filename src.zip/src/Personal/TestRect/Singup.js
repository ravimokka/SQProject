import React from "react";
import { css } from "@emotion/core";
// First way to import
import { ClipLoader } from "react-spinners";
import { FadeLoader	 } from "react-spinners";
import { RingLoader} from "react-spinners";


// Can be a string as well. Need to ensure each key-value pair ends with ;


class AwesomeComponent extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
    loading: false
    };
  }

  onClick = () => {
  /*
    Begin by setting loading = true, and use the callback function
    of setState() to make the ajax request. Set loading = false after
    the request completes.
  */
  this.setState({ loading: true }, () => {})

}

  render() {
  const override = css`
  display: block;
  margin: 0 auto;
  border-color: red;
  loading: true;
  color: "red";
  css: "";
`;
    return (
      <div id="login" style = {{
                              margin:"0",
                              padding:"0",
                              backgroundColor:"#17a2b8",
                              height:"100vh",
                              backgroundImage:"url(/assets/images/login-bg.jpg)"

                                  }}>
        <h3 class="text-center text-white pt-5"> SQ Signup form</h3>
        <div class="container" style={{marginTop:"150px", maxWidth:"600px",height:"400px",
                                        border: "1px solid #9C9C9C", backgroundColor:" #EAEAEA",
                                         padding:"50px", marginTop:"-3px"}}>
            <div id="login-row" class="row justify-content-center align-items-center">
                <div id="login-column" class="col-md-6">
                    <div id="login-box" class="col-md-12">
                        <form id="login-form" class="form" action="" method="post">

                            <div class="form-group">
                                <input type="text" name="username" id="username" class="form-control"/>
                            </div>
                            <div class="form-group">
                                <input type="text" name="password" id="password" class="form-control"/>
                            </div>
                            <div class="form-group">
                                <input type="text" name="password" id="password" class="form-control"/>
                            </div>
                            <div class="form-group">
                                <input type="text" name="password" id="password" class="form-control"/>
                            </div>
                            <div class="form-group">
                                <input type="text" name="password" id="password" class="form-control"/>
                            </div>
                            <div class="form-group">
                                <input type="submit" name="submit" class="btn btn-info btn-md" value="submit"/>
                                <input type="submit" name="submit" class="btn btn-info btn-md" value="Login"
                                                        style={{marginLeft:"170px", marginTop:"-60px"}}/>
                            </div>


                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    );
  }
}
 export default AwesomeComponent;