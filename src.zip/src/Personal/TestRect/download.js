import React, { Component } from "react";
import { Row, Col, Card, Button, Icon, Progress,Table } from "antd";
import { CSVLink } from "react-csv";

import ChartBreakdownDonut from "./ChartBreakdownDonut";
import LineChart from "./LineChart";
import BarChart from "./BarChart";


const DataSet = require("@antv/data-set");



class ManagementAllCharts extends Component {
  constructor(props) {
    super(props);
    this.state = {
      chartData: [],
      selectedKey: "daily",
      data : [
  { firstname: "Ravi", lastname: "Tomi", email: "ah@smthing.co.com" },
  { firstname: "Vamsi", lastname: "Labes", email: "rl@smthing.co.com" },
  { firstname: "Raju", lastname: "Min l3b", email: "ymin@cocococo.com" }
],
    };

  }
  render() {


    return (
      <div>
        <div id="content">

           <CSVLink data={this.state.data}>
                  <Button> Download me </Button>
                </CSVLink>;
        </div>
      </div>
    );
  }
}
export default ManagementAllCharts;

