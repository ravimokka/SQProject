import React, { Component, Router, Switch, Route, App } from "react";
import { Chart, Tooltip, Axis, Legend, Bar, Line} from "viser-react";




class RouterTest extends React.Component {

constructor(props) {
    super(props)
    this.state = {
      sistemas: [],
      child: 'Data received'
    };

  }

  update = (data) => {
    this.setState({ fromChild: data })
  }

  render() {
    return (
      <div className="App">
        <h1> test </h1>


      </div>
    );
  }
}export default RouterTest;
