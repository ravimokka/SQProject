import React, { Component} from "react";
import { Chart, Tooltip, Axis, Legend, Bar, Line} from "viser-react";
import RouterTest from "./router";
import {Link, Switch, Route } from "react-router-dom";
import ChatBot from 'react-simple-chatbot';
{/*
class Test extends React.Component {

constructor(props) {
    super(props)
    this.state = {
      sistemas: [],
      child: 'Data received'
    };

  }

  update = (data) => {
    this.setState({ fromChild: data })
  }

  render() {
    return (
      <div className="App">
        <h1>Child Component </h1>
        <h1>{this.props.data}</h1>
       <button onClick={() =>this.props.update(this.state.child)} >Click from Child</button>
      </div>
    );
  }
}export default Test;
*


class Test extends React.Component {

constructor(props) {
    super(props)
    this.state = {
      sistemas: [],
      child: 'Data received',
      data:this.props.location.data
    };

  }

  update = (data) => {
    this.setState({ fromChild: data })
  }

  render() {
  const { data } = this.props.location
    return (
      <div className="App">
        <Route exact path='/test-react' component={RouterTest}/>
        <h1>{this.state.data.color}</h1>

      </div>
    );
  }
}export default Test;
*/}


class ChatBox extends React.Component {

constructor(props) {
    super(props)
    this.state = {
      sistemas: [],
      child: 'Data received',
      data:this.props.location.data
    };

  }


  render() {

    return (
      <div className="App">

   <ChatBot
  steps={[
    {
      id: 'hello-world',
      message: 'Hello World!',
      end: true,
    },
  ]}
/>
      </div>
    );
  }
}export default ChatBox;















