import { Chart, Tooltip, Axis, Legend, Pie, Coord, Line, Bar, Point} from 'viser-react';
import * as React from 'react';
import { Row, Col, Card, Button, Icon, Progress, Form , Modal, Table} from "antd";
import { Host } from  "../../Host";
import axios from "axios";
import ReactApexChart from 'react-apexcharts'
import 'bootstrap/dist/css/bootstrap.min.css';
import $ from 'jquery';
import Popper from 'popper.js';
import 'bootstrap/dist/js/bootstrap.bundle.min';
import { CSVLink } from "react-csv";
import { css } from "@emotion/core";
import { RingLoader} from "react-spinners";

const DataSet = require('@antv/data-set');

class GroupBarChart extends React.Component {

 constructor(props) {
    super(props);
   this.state = {

        group_bar_options: {
                    plotOptions: {
                      bar: {
                        horizontal: true,
                        dataLabels: {
                          position: 'top',
                        },
                      }
                    },
                    dataLabels: {
                      enabled: false,
                      offsetX: -6,
                      style: {
                        fontSize: '12px',
                        colors: ['#fff']
                      }
                    },
                    stroke: {
                      show: true,
                      width: 1,
                      colors: ['#fff']
                    },

                    xaxis: {
                      categories: [""],
                      labels: {
                            formatter: function(val) {
                               if (val < 100000) {
                                            return Math.round((val/1000) * 10)/10+'k';
                                        }
                                else if (val >= 1000000){

                                return val=(val/1000000)+"M";

                                }
                                 else {
                                            return val;
                                        }

                            }
                        }
                    },
                    yaxis: {
                      categories: [2001, 2002, 2003, 2004, 2005, 2006, 2007],
                      labels: {
                            formatter: function(val) {
                               if (val < 100000) {
                                            return Math.round((val/1000) * 10)/10+'k';
                                        }
                                else if (val >= 1000000){

                                return val=(val/1000000)+"M";

                                }
                                 else {
                                            return val;
                                        }

                            }
                        }
                    }
                  },

      books:[],
     intHeader:[],
     filter:[],
     select_group:"Group",
     select_amount:"Amount",
     chart_data:[],
     donut_data:[],
     pie_data:[],
     bar_data:[],
     ve_bar_data:[],
     line_data:[{name:"", 'A':1, 'B':12}],
     field_list:["A","B"],
     chartData: [],
     sourceData :[],
     line_chart_source_data:[{name: 'A', value: 13000000}],
     sourceData_donut:[],
     value_xl : "Status",
     value_yl : "Amount_USD",
     loading:true,
     group_bar_display:false,

     table_columns : [{ title: 'Order Number',dataIndex: 'oNumber', key: 'oNumber',}],
     table_data : [{ key: '1', oNumber: 'DVO524',}],

     Gbar_table_columns : [{ title: 'Order Number',dataIndex: 'oNumber', key: 'oNumber',}],
     Gbar_table_data : [{ key: '1', oNumber: 'DVO524',}],
     download_group_barChart_table :[{ firstname: "Ravi", lastname: "Tomi", email: "ah@smthing.co.com" }],

   }
 }

// ============================= Loading all charts ====================================================================

componentWillMount() {
    this.loadAnalytical();
     this.loadIntHeaders();
     this.loadAllChartData({A:"Group", B:"Amount"});

  }

 async loadAnalytical()
  {
    const promise = await axios.post(Host.loginURL +"/header_api", { firstName: 'Mokka Ravi', lastName: 'Flintstone' });
    const status = promise.status;
    if(status===200)
    {
      const data = promise.data.data;
      console.log(data);
      this.setState({books:data});
    }
  }

async loadIntHeaders()
  {
    const promise = await axios.post(Host.loginURL +"/int_header_api", { firstName: 'Mokka Ravi', lastName: 'Flintstone' });
    const status = promise.status;
    if(status===200)
    {
      const data = promise.data.data;
      console.log(data);
      this.setState({intHeader:data});
      const d = [{'name': 'Actual','data': []}, {'name': 'Budget','data': []}]
      const dou = [1,3,4]
      this.setState({donut_data:dou})
      this.setState({chart_data:d})
       console.log(this.state.chart_data);

    }
  }

async loadAllChartData(data){

    const headers  = new Headers()
    headers.append('Content-Type', 'application/json');
    const options = {
    method : 'POST',
    headers,
    body:JSON.stringify(data),
    }
    this.setState({load_table_columns : []})
    this.setState({load_table_data : []})
    this.setState({line_data : []})
    this.setState({field_list : []})
    this.setState({line_chart_source_data : []})
    this.setState({chart_data:[]})
    this.setState({area_chart_series:[]})

     this.setState({download_lineChart_table:[]})
     this.setState({download_group_barChart_table:[]})
 const promise = await axios.post(Host.loginURL +"/all_data_api", options);
    const status = promise.status;

    if(status===200)
    {
      const data = promise.data.data;
      var l_data = [data];
      var table_dict = [data]
      this.setState(data);
      var i;
      var keys_list =[];
      var line_value_list =[];
      var line_chart_list = [];
      var load_bar_chart_list = [];
       var table_column_list = [];
       var table_data_list = [];
       var table_data_dict = {}
       var area_list = [];
       var area_chart_data = [];
      for (i = 0; i < Object.keys(data).length; i++) {
            console.log(data[i])
            var key = Object.keys(data)[i]
            keys_list.push(key)
            var value = data[key]
            line_value_list.push(value)
            var data_dict = {};
            data_dict['name']=key;
            data_dict['value']=value;
            line_chart_list.push(data_dict)
            var load_data_dict = {};
            load_data_dict['name']=key;
            load_data_dict['data']=[value];
            load_bar_chart_list.push(load_data_dict)
            var column_dict = {}
            column_dict['title'] =key;
            column_dict['dataIndex'] =key;
            column_dict['key'] =key;
            table_data_dict[key] = value;
            table_column_list.push(column_dict)

            var area_dict = {}
            area_list.push(value);
            area_dict['name']=key;
            area_dict['data'] = area_list;
            area_chart_data.push(area_dict);


        }
       table_data_list.push(table_data_dict)


      this.setState({line_chart_source_data:line_chart_list})
      this.setState({field_list:keys_list})
      this.setState({chart_data:load_bar_chart_list})
      this.setState({area_chart_series:area_chart_data})


      this.setState({line_table_columns:table_column_list})
      this.setState({line_table_data:table_data_list})

       this.setState({Gbar_table_columns:table_column_list})
      this.setState({Gbar_table_data:table_data_list})

       this.setState({mix_table_columns:table_column_list})
      this.setState({mix_table_data:table_data_list})

       this.setState({area_table_columns:table_column_list})
      this.setState({area_table_data:table_data_list})


       this.setState({download_lineChart_table:table_dict})
       this.setState({download_group_barChart_table:table_dict})
       this.setState({download_areaChart_table:table_dict})
       this.setState({loading:false})
       this.setState({group_bar_display:true})
 }
}


//================================================ Group Bar Chart ====================================================================
handleSubmit = (e) => {
     this.setState({value_x: e.target.value});
 };

handleSubmit1 = (e) => {
    this.setState({value_y: e.target.value});
  };


handleSubmit12 = (e) => {
    e.preventDefault();
    this.setState({loading:true})
     this.loadGroupBarData(
         {A:this.state.value_x, B:this.state.value_y}
  );
  };


async loadGroupBarData(data){

    const headers  = new Headers()
    headers.append('Content-Type', 'application/json');
    const options = {
    method : 'POST',
    headers,
    body:JSON.stringify(data),
    }
    this.setState({chart_data : []})
    this.setState({Gbar_table_columns:[]})
      this.setState({Gbar_table_data:[]})

      this.setState({download_group_barChart_table:[]})
 const promise = await axios.post(Host.loginURL +"/all_data_api", options);
    const status = promise.status;
    if(status===200)
    {
      const data = promise.data.data;
      var table_dict = data;
      this.setState(data);
      var i;
      var keys_list =[];
      var value_list =[];
      var chart_list = [];
       var table_column_list = [];
       var table_data_list = [];
       var table_data_dict = {}


      for (i = 0; i < Object.keys(data).length; i++) {
            console.log(data[i])
            var key = Object.keys(data)[i]
//            keys_list.push(key)
            var value = data[key]
//            value_list.push(value)
            var data_dict = {};
            data_dict['name']=key;
            data_dict['data']=[value];
            chart_list.push(data_dict)

            var column_dict = {}
            column_dict['title'] =key;
            column_dict['dataIndex'] =key;
            column_dict['key'] =key;
            table_data_dict[key] = value;
            table_column_list.push(column_dict)
        }

      table_data_list.push(table_data_dict)
      const g_data = [this.state.Actual, this.state.Budget]
      this.setState({g:g_data})
      this.setState({chart_data:chart_list})

      this.setState({Gbar_table_columns:table_column_list})
      this.setState({Gbar_table_data:table_data_list})

      this.setState({download_group_barChart_table:[table_dict]})
      this.setState({group_bar_display:true})
      this.setState({loading:false})

    }

}



render() {

const override = css`
  display: block;
  margin: 0 auto;
  border-color: red;
  loading: true;
  color: "red";
  css: "";
`;


  return (
   <div id="chart">
        <select class="custom-select"  value={this.state.value_x} onChange={this.handleSubmit}
            style={{ width:"110px", marginLeft:"20px" }}>
             <option>{this.state.select_group}</option>
             {this.state.books.map((value,index)=>
                      {return   <option class="btn btn-custom btn-block btn-detail"
                      style={{ cursor: "pointer;", fontSize: "14px"}} key={index}> {value} </option> }
                      )}
       </select>
       <select class="custom-select"  value={this.state.value_y} onChange={this.handleSubmit1}
            style={{ width:"110px", marginLeft:"20px" }}>
             <option>{this.state.select_amount}</option>
             {this.state.intHeader.map((value,index)=>
                      {return   <option class="btn btn-custom btn-block btn-detail"
                      style={{ cursor: "pointer;", fontSize: "14px"}} key={index}> {value} </option> }
                      )}
       </select>
       <React.Fragment>
            <button onClick={this.handleSubmit12} className='btn btn-info' style={{marginLeft:"10px"}}
              type='button'>OK</button>
        </React.Fragment>
        <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#myModal_GroupBar"
        style={{marginLeft:"3px"}}>Table View</button>
          <div class="modal fade" id="myModal_GroupBar" role="dialog">
            <div class="modal-dialog">
              <div class="modal-content">
                <div class="modal-header">
                 {/* <button type="button" class="close" data-dismiss="modal" style={{marginLeft:"1px"}}>&times;</button> */}
                  <h4 class="modal-title">Group Bar TableData</h4>
                </div>
                <div class="modal-body">
                 <Table columns={this.state.Gbar_table_columns} dataSource={this.state.Gbar_table_data} style={{overflowY:"scroll"}}/>

                </div>
                <div class="modal-footer">
                  <button type="button" class="btn btn-info" data-dismiss="modal">Close</button>
                  <CSVLink data={this.state.download_group_barChart_table}>
                  <button type="button" class="btn btn-primary" > Download </button>
                  </CSVLink>;
                </div>
              </div>

            </div>
          </div>
          <RingLoader
                  css={override}
                  size={150} // or 150px
                  color={"#123abc"}
                  loading={this.state.loading}
              />
      {this.state.group_bar_display == true?
      <ReactApexChart options={this.state.group_bar_options} series={this.state.chart_data}
                                                      type="bar" width="420" height="350" />:null
       }
   </div>
    );
  }
}
export default GroupBarChart;