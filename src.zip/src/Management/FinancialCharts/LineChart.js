import { Chart, Tooltip, Axis, Legend, Pie, Coord, Line, Bar, Point} from 'viser-react';
import * as React from 'react';
import { Row, Col, Card, Button, Icon, Progress, Form , Modal, Table} from "antd";
import axios from "axios";
import ReactApexChart from 'react-apexcharts'
import 'bootstrap/dist/css/bootstrap.min.css';
import $ from 'jquery';
import Popper from 'popper.js';
import 'bootstrap/dist/js/bootstrap.bundle.min';
import { CSVLink } from "react-csv";

const DataSet = require('@antv/data-set');

class LineChart extends React.Component {

 constructor(props) {
    super(props);
   this.state = {
             books:[],
             intHeader:[],
             filter:[],
             select_group:"Group",
             select_amount:"Amount",
             chart_data:[],
             donut_data:[],
             pie_data:[],
             bar_data:[],
             ve_bar_data:[],
             line_data:[{name:"", 'A':1, 'B':12}],
             field_list:["A","B"],
             chartData: [],
             sourceData :[],
             line_chart_source_data:[{name: 'A', value: 13000000}],
             sourceData_donut:[],

             table_columns : [{ title: 'Order Number',dataIndex: 'oNumber', key: 'oNumber',}],
             table_data : [{ key: '1', oNumber: 'DVO524',}],


             load_table_columns : [{ title: 'Order Number',dataIndex: 'oNumber', key: 'oNumber',}],
             load_table_data : [{ key: '1', oNumber: 'DVO524',}],

             line_table_columns : [{ title: 'Order Number',dataIndex: 'oNumber', key: 'oNumber',}],
             line_table_data : [{ key: '1', oNumber: 'DVO524',}],

             bar_table_columns : [{ title: 'Order Number',dataIndex: 'oNumber', key: 'oNumber',}],
             bar_table_data : [{ key: '1', oNumber: 'DVO524',}],

             vertical_table_columns : [{ title: 'Order Number',dataIndex: 'oNumber', key: 'oNumber',}],
             vertical_table_data : [{ key: '1', oNumber: 'DVO524',}],

             Gbar_table_columns : [{ title: 'Order Number',dataIndex: 'oNumber', key: 'oNumber',}],
             Gbar_table_data : [{ key: '1', oNumber: 'DVO524',}],

             donut_table_columns : [{ title: 'Order Number',dataIndex: 'oNumber', key: 'oNumber',}],
             donut_table_data : [{ key: '1', oNumber: 'DVO524',}],

             pie_table_columns : [{ title: 'Order Number',dataIndex: 'oNumber', key: 'oNumber',}],
             pie_table_data : [{ key: '1', oNumber: 'DVO524',}],

             mix_table_columns : [{ title: 'Order Number',dataIndex: 'oNumber', key: 'oNumber',}],
             mix_table_data : [{ key: '1', oNumber: 'DVO524',}],
             value_xl : "Group",
             value_yl : "Amount",

             download_lineChart_table :[{ firstname: "Ravi", lastname: "Tomi", email: "ah@smthing.co.com" }],
             download_barChart_table :[{ firstname: "Ravi", lastname: "Tomi", email: "ah@smthing.co.com" }],

   }
}

// ============================= Loading all charts ====================================================================

componentWillMount() {
    this.loadAnalytical();
     this.loadIntHeaders();
     this.loadAllChartData({A:"Group", B:"Amount"});
  }

 async loadAnalytical()
  {
    const promise = await axios.post("http://127.0.0.1:8070/api/v1/header_api");
    const status = promise.status;
    if(status===200)
    {
      const data = promise.data.data;
      console.log(data);
      this.setState({books:data});
    }
  }

async loadIntHeaders()
  {
    const promise = await axios.post("http://127.0.0.1:8070/api/v1/int_header_api");
    const status = promise.status;
    if(status===200)
    {
      const data = promise.data.data;
      console.log(data);
      this.setState({intHeader:data});
      const d = [{'name': 'Actual','data': []}, {'name': 'Budget','data': []}]
      const dou = [1,3,4]
      this.setState({donut_data:dou})
      this.setState({chart_data:d})
       console.log(this.state.chart_data);

    }
  }

async loadAllChartData(data){

    const headers  = new Headers()
    headers.append('Content-Type', 'application/json');
    const options = {
    method : 'POST',
    headers,
    body:JSON.stringify(data),
    }
    this.setState({load_table_columns : []})
    this.setState({load_table_data : []})
    this.setState({line_data : []})
    this.setState({field_list : []})
    this.setState({line_chart_source_data : []})
    this.setState({chart_data:[]})
    this.setState({area_chart_series:[]})

     this.setState({download_lineChart_table:[]})
     this.setState({download_group_barChart_table:[]})
 const promise = await axios.post("http://127.0.0.1:8070/api/v1/all_data_api", options);
    const status = promise.status;

    if(status===200)
    {
      const data = promise.data.data;
      var l_data = [data];
      var table_dict = [data]
      this.setState(data);
      var i;
      var keys_list =[];
      var line_value_list =[];
      var line_chart_list = [];
      var load_bar_chart_list = [];
       var table_column_list = [];
       var table_data_list = [];
       var table_data_dict = {}
       var area_list = [];
       var area_chart_data = [];
      for (i = 0; i < Object.keys(data).length; i++) {
            console.log(data[i])
            var key = Object.keys(data)[i]
            keys_list.push(key)
            var value = data[key]
            line_value_list.push(value)
            var data_dict = {};
            data_dict['name']=key;
            data_dict['value']=value;
            line_chart_list.push(data_dict)
            var load_data_dict = {};
            load_data_dict['name']=key;
            load_data_dict['data']=[value];
            load_bar_chart_list.push(load_data_dict)
            var column_dict = {}
            column_dict['title'] =key;
            column_dict['dataIndex'] =key;
            column_dict['key'] =key;
            table_data_dict[key] = value;
            table_column_list.push(column_dict)

            var area_dict = {}
            area_list.push(value);
            area_dict['name']=key;
            area_dict['data'] = area_list;
            area_chart_data.push(area_dict);


        }
       table_data_list.push(table_data_dict)


      this.setState({line_chart_source_data:line_chart_list})
      this.setState({field_list:keys_list})
      this.setState({chart_data:load_bar_chart_list})
      this.setState({area_chart_series:area_chart_data})


      this.setState({line_table_columns:table_column_list})
      this.setState({line_table_data:table_data_list})

       this.setState({Gbar_table_columns:table_column_list})
      this.setState({Gbar_table_data:table_data_list})

       this.setState({mix_table_columns:table_column_list})
      this.setState({mix_table_data:table_data_list})

       this.setState({area_table_columns:table_column_list})
      this.setState({area_table_data:table_data_list})


       this.setState({download_lineChart_table:table_dict})
       this.setState({download_group_barChart_table:table_dict})
       this.setState({download_areaChart_table:table_dict})
 }
}
// =================================================== Line Chart ======================================================

handleSubmitLineChart = (e) => {
     this.setState({value_xl:""})
     this.setState({value_xl: e.target.value});
 };

handleSubmitLineChart1 = (e) => {
    this.setState({value_yl:""})
    this.setState({value_yl: e.target.value});
  };


handleSubmitLineChartOK = (e) => {
    e.preventDefault();
     this.loadLineChartData(
         {A:this.state.value_xl, B:this.state.value_yl}
  );
  };


async loadLineChartData(data){

    const headers  = new Headers()
    headers.append('Content-Type', 'application/json');
    const options = {
    method : 'POST',
    headers,
    body:JSON.stringify(data),
    }
    this.setState({line_data : []})
    this.setState({field_list : []})
    this.setState({line_chart_source_data : []})

     this.setState({line_table_columns:[]})
      this.setState({line_table_data:[]})
      this.setState({download_lineChart_table:[]})
 const promise = await axios.post("http://127.0.0.1:8070/api/v1/all_data_api", options);
    const status = promise.status;

    if(status===200)
    {
      const data = promise.data.data;
      const table_dict = data
      var l_data = [data];
      this.setState(data);
      var i;
      var keys_list =[];
      var line_value_list =[];
      var line_chart_list = []
       var table_column_list = [];
       var table_data_list = [];
       var table_data_dict = {}
      for (i = 0; i < Object.keys(data).length; i++) {
            console.log(data[i])
            var key = Object.keys(data)[i]
            keys_list.push(key)
            var value = data[key]
            line_value_list.push(value)
            var data_dict = {};
            data_dict['name']=key;
            data_dict['value']=value;
            line_chart_list.push(data_dict)
            var column_dict = {}
            column_dict['title'] =key;
            column_dict['dataIndex'] =key;
            column_dict['key'] =key;
            table_data_dict[key] = value;
            table_column_list.push(column_dict)
        }

      table_data_list.push(table_data_dict)
      this.setState({download_lineChart_table:[table_dict]})
      this.setState({line_chart_source_data:line_chart_list})
      this.setState({field_list:keys_list})

      this.setState({line_table_columns:table_column_list})
      this.setState({line_table_data:table_data_list})
    }
}

//=================================================== Line Chart Table Data Download ===================================

handleDownload = (e) => {
    e.preventDefault();
     this.lineChart_TableDownload(
         {A:this.state.value_xl, B:this.state.value_yl}
  );
  };


async lineChart_TableDownload(data){
    const headers  = new Headers()
    headers.append('Content-Type', 'application/json');
    const options = {
    method : 'POST',
    headers,
    body:JSON.stringify(data),
    }
 const promise = await axios.post("http://127.0.0.1:8070/api/v1/download_api", options);
    const status = promise.status;

    if(status===200)
    {
      const data = promise.data.data;

    }
}






render() {
const line_chart_source_scale = [{
  dataKey: 'value',
  min: 0,
          formatter: function formatter(val) {
                     if (val < 100000) {
                         return Math.round((val/1000) * 10)/10+'k';
                     }
                    else if (val >= 1000000){
                        return val=(val/1000000)+"M";
                    }
                     else{
                         return val;
                     }
          }
},
{
  dataKey: 'year',
  min: 0,
  max: 1,
}];

    return (

       <div id="chart">
            <select class="custom-select"  value={this.state.value_xl} onChange={this.handleSubmitLineChart}
                style={{ width:"110px", marginLeft:"20px" }}>
                 <option>Group</option>
                 {this.state.books.map((value,index)=>
                          {return   <option class="btn btn-custom btn-block btn-detail"
                          style={{ cursor: "pointer;", fontSize: "14px"}} key={index}> {value} </option> }
                          )}
           </select>
           <select class="custom-select"  value={this.state.value_yl} onChange={this.handleSubmitLineChart1}
                style={{ width:"110px", marginLeft:"20px" }}>
                 <option>{this.state.select_amount}</option>
                 {this.state.intHeader.map((value,index)=>
                          {return   <option class="btn btn-custom btn-block btn-detail"
                          style={{ cursor: "pointer;", fontSize: "14px"}} key={index}> {value} </option> }
                          )}
           </select>
           <React.Fragment>
                <button onClick={this.handleSubmitLineChartOK} className='btn btn-info' style={{marginLeft:"10px"}}
                  type='button'>OK</button>
            </React.Fragment>
         <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#myModal_line" style={{marginLeft:"3px"}}>
            Table View</button>
              <div class="modal fade" id="myModal_line" role="dialog">
                <div class="modal-dialog">
                  <div class="modal-content">
                    <div class="modal-header">
                     {/* <button type="button" class="close" data-dismiss="modal" style={{marginLeft:"1px"}}>&times;</button> */}
                      <h4 class="modal-title">Line Chart TableData</h4>

                    </div>
                    <div>
                    <h5 class="modal-title" style={{marginLeft:"160px"}}>
                    {this.state.value_xl}, {this.state.value_yl}</h5>
                    </div>
                    <div class="modal-body">
                     <Table columns={this.state.line_table_columns} dataSource={this.state.line_table_data} style={{overflowY:"scroll"}}/>

                    </div>
                    <div class="modal-footer">
                      <button type="button" class="btn btn-info" data-dismiss="modal">Close</button>
                      <CSVLink data={this.state.download_lineChart_table}>
                      <button type="button" class="btn btn-primary" > Download </button>
                      </CSVLink>;
                    </div>
                  </div>

                </div>
              </div>

              <Chart forceFit width={400} height={400} data={this.state.line_chart_source_data}
                                                       scale={line_chart_source_scale}>
                <Tooltip />
                <Axis />
                <Legend />
                <Line position="name*value"/>
                <Point position="name*value" shape="circle"/>
              </Chart>
        </div>
    );
  }
}
export default LineChart;