import { Chart, Tooltip, Axis, Legend, Pie, Coord, Line, Bar, Point} from 'viser-react';
import * as React from 'react';
import { Row, Col, Card, Button, Icon, Progress, Form , Modal, Table} from "antd";
import axios from "axios";
import ReactApexChart from 'react-apexcharts'
import 'bootstrap/dist/css/bootstrap.min.css';
import $ from 'jquery';
import Popper from 'popper.js';
import 'bootstrap/dist/js/bootstrap.bundle.min';
import { CSVLink } from "react-csv";

const DataSet = require('@antv/data-set');

class MixedChart extends React.Component {

 constructor(props) {
    super(props);
   this.state = {

mixed_chart_options:  {
            dataLabels: {
              enabled: false
            },

            stroke: {
              width:4
            },
            title: {
              text: '',
              align: 'left',
              offsetX: 110
            },
            xaxis: {
              categories: [],

              labels: {
                    formatter: function(val) {
                       if (val < 100000) {
                                    return Math.round((val/1000) * 10)/10+'k';
                                }
                        else if (val >= 1000000){

                        return val=(val/1000000)+"M";

                        }
                         else {
                                    return val;
                                }

                    }
                }
            },
            yaxis: [
              {
                axisTicks: {
                  show: true,
                },
                axisBorder: {
                  show: true,
                  color: '#008FFB'
                },
                 labels: {
                   style: {
                    color: '#008FFB',
                  },
                    formatter: function(val) {
                       if (val < 100000) {
                                    return Math.round((val/1000) * 10)/10+'k';
                                }
                        else if (val >= 1000000){

                        return val=(val/1000000)+"M";

                        }
                         else {
                                    return val;
                                }

                    }
                },
                title: {
                  text: "",
                  style: {
                    color: '#008FFB',
                  }
                },
                tooltip: {
                  enabled: true
                }
              },

              {
                seriesName: 'Income',
                opposite: true,
                axisTicks: {
                  show: true,
                },
                axisBorder: {
                  show: true,
                  color: '#00E396'
                },
                   labels: {
                   style: {
                    color: '#00E396',
                  },
                    formatter: function(val) {
                       if (val < 100000) {
                                    return Math.round((val/1000) * 10)/10+'k';
                                }
                        else if (val >= 1000000){

                        return val=(val/1000000)+"M";

                        }
                         else {
                                    return val;
                                }

                    }
                },
                title: {
                  text: "",
                  style: {
                    color: '#00E396',
                  }
                },
              },
              {
                seriesName: 'Revenue',
                opposite: true,
                axisTicks: {
                  show: true,
                },
                axisBorder: {
                  show: true,
                  color: '#FEB019'
                },
                 labels: {
                   style: {
                    color: '#FEB019',

                  },
                    formatter: function(val) {
                       if (val < 100000) {
                                    return Math.round((val/1000) * 10)/10+'k';
                                }
                        else if (val >= 1000000){

                        return val=(val/1000000)+"M";

                        }
                         else {
                                    return val;
                                }

                    }
                },
                title: {
                  text: "",
                  style: {
                    color: '#FEB019',
                  }
                }
              },
            ],


            tooltip: {
              fixed: {
                enabled: true,
                position: 'topLeft', // topRight, topLeft, bottomRight, bottomLeft
                offsetY: 30,
                offsetX: 60
              },
            },
            legend: {
              horizontalAlign: 'left',
              offsetX: 40
            }
          },
mixed_chart_series: [{
name: 'Status',
type: 'column',
data: [10]
}, {
name: 'A',
type: 'column',
data: [20]
},

{
name: 'B',
type: 'column',
data: [30]
},
{
name: 'C',
type: 'column',
data: [150]
},


{
name: 'LINE',
type: 'line',
data: [40, 20]
},

],

      books:[],
     intHeader:[],
     filter:[],
     select_group:"Group",
     select_amount:"Amount",
     chart_data:[],
     donut_data:[],
     pie_data:[],
     bar_data:[],
     ve_bar_data:[],
     line_data:[{name:"", 'A':1, 'B':12}],
     field_list:["A","B"],
     chartData: [],
     sourceData :[],
     line_chart_source_data:[{name: 'A', value: 13000000}],
     sourceData_donut:[],
     value_xl : "Status",
     value_yl : "Amount_USD",

     table_columns : [{ title: 'Order Number',dataIndex: 'oNumber', key: 'oNumber',}],
     table_data : [{ key: '1', oNumber: 'DVO524',}],


     load_table_columns : [{ title: 'Order Number',dataIndex: 'oNumber', key: 'oNumber',}],
     load_table_data : [{ key: '1', oNumber: 'DVO524',}],



     mix_table_columns : [{ title: 'Order Number',dataIndex: 'oNumber', key: 'oNumber',}],
     mix_table_data : [{ key: '1', oNumber: 'DVO524',}],

     download_mixedChart_table :[{ firstname: "Ravi", lastname: "Tomi", email: "ah@smthing.co.com" }],

   }
 }
// ============================= Loading all charts ====================================================================

componentWillMount() {
    this.loadAnalytical();
     this.loadIntHeaders();
     this.loadMixedChartData({A:"Group", B:"Amount", C:"Group"})
  }

 async loadAnalytical()
  {
    const promise = await axios.post("http://127.0.0.1:8070/api/v1/header_api", { firstName: 'Mokka Ravi', lastName: 'Flintstone' });
    const status = promise.status;
    if(status===200)
    {
      const data = promise.data.data;
      console.log(data);
      this.setState({books:data});
    }
  }

async loadIntHeaders()
  {
    const promise = await axios.post("http://127.0.0.1:8070/api/v1/int_header_api", { firstName: 'Mokka Ravi', lastName: 'Flintstone' });
    const status = promise.status;
    if(status===200)
    {
      const data = promise.data.data;
      console.log(data);
      this.setState({intHeader:data});
      const d = [{'name': 'Actual','data': []}, {'name': 'Budget','data': []}]
      const dou = [1,3,4]
      this.setState({donut_data:dou})
      this.setState({chart_data:d})
       console.log(this.state.chart_data);

    }
  }

async loadMixedChartData(data){

    const headers  = new Headers()
    headers.append('Content-Type', 'application/json');
    const options = {
    method : 'POST',
    headers,
    body:JSON.stringify(data),
    }
    this.setState({mixed_chart_series : []})

    this.setState({mix_table_columns:[]})
     this.setState({mix_table_data:[]})


     this.setState({download_mixedChart_table:[]})
 const promise = await axios.post("http://127.0.0.1:8070/api/v1/fin_Maxdata_api", options);
    const status = promise.status;
    if(status===200)
    {

      const sum_data = promise.data.data["sum_data"];
      const count_data = promise.data.data["count_data"];
      var table_dict = sum_data;
      this.setState(data);
      var i;
      var keys_list =[];
      var value_list =[];
      var max_chart_list = [];

      var table_column_list = [];
      var table_data_list = [];
      var table_data_dict = {}

      for (i = 0; i < Object.keys(sum_data).length; i++) {
            console.log(data[i])
            var key = Object.keys(sum_data)[i]
//            keys_list.push(key)
            var value = sum_data[key]
            value_list.push(value)
            var data_dict = {};
            data_dict['name']=key;
            data_dict['type']='column';
            data_dict['data']=[value];
            max_chart_list.push(data_dict)

            var column_dict = {}
            column_dict['title'] =key;
            column_dict['dataIndex'] =key;
            column_dict['key'] =key;
            table_data_dict[key] = value;
            table_column_list.push(column_dict)
        }
      table_data_list.push(table_data_dict)
      var j;
      var c_keys_list =[];
      var c_value_list =[];
      var max_chart_count_list ={};
      for (j = 0; j < Object.keys(count_data).length; j++) {
            console.log(data[j])
            var key = Object.keys(sum_data)[j]
//            keys_list.push(key)
            var value = sum_data[key]
            c_value_list.push(value)
            var data_dict = {};
            max_chart_count_list['name']=count_data["label"];
            max_chart_count_list['type']='line';
            max_chart_count_list['data']=c_value_list;

        }

       max_chart_list.push(max_chart_count_list)
      const g_data = [this.state.Actual, this.state.Budget]
      this.setState({g:g_data})
      this.setState({mixed_chart_series:max_chart_list})
      this.setState({mix_table_columns:table_column_list})
     this.setState({mix_table_data:table_data_list})

     this.setState({download_mixedChart_table:[table_dict]})
    }

}

//=================================================Mixed chart==========================================================

mixedCharthandleSubmit = (e) => {
     this.setState({value_mx: e.target.value});
 };

mixedCharthandleSubmit1 = (e) => {
    this.setState({value_my: e.target.value});
  };


 mixedCharthandleSubmit2 = (e) => {
    this.setState({value_mz: e.target.value});
  };


mixed_handleSubmit = (e) => {
    e.preventDefault();
     this.loadMixedChartData(
         {A:this.state.value_mx, B:this.state.value_my, C:this.state.value_mz}
  );
  };


async loadMixedChartData(data){

    const headers  = new Headers()
    headers.append('Content-Type', 'application/json');
    const options = {
    method : 'POST',
    headers,
    body:JSON.stringify(data),
    }
    this.setState({mixed_chart_series : []})

    this.setState({mix_table_columns:[]})
     this.setState({mix_table_data:[]})

     this.setState({download_mixedChart_table:[]})
 const promise = await axios.post("http://127.0.0.1:8070/api/v1/fin_Maxdata_api", options);
    const status = promise.status;
    if(status===200)
    {

      const sum_data = promise.data.data["sum_data"];
      const count_data = promise.data.data["count_data"];
      var table_dict = sum_data;
      this.setState(data);
      var i;
      var keys_list =[];
      var value_list =[];
      var max_chart_list = [];

      var table_column_list = [];
      var table_data_list = [];
      var table_data_dict = {}

      for (i = 0; i < Object.keys(sum_data).length; i++) {
            console.log(data[i])
            var key = Object.keys(sum_data)[i]
//            keys_list.push(key)
            var value = sum_data[key]
            value_list.push(value)
            var data_dict = {};
            data_dict['name']=key;
            data_dict['type']='column';
            data_dict['data']=[value];
            max_chart_list.push(data_dict)

            var column_dict = {}
            column_dict['title'] =key;
            column_dict['dataIndex'] =key;
            column_dict['key'] =key;
            table_data_dict[key] = value;
            table_column_list.push(column_dict)
        }
      table_data_list.push(table_data_dict)
      var j;
      var c_keys_list =[];
      var c_value_list =[];
      var max_chart_count_list ={};
      for (j = 0; j < Object.keys(count_data).length; j++) {
            console.log(data[j])
            var key = Object.keys(sum_data)[j]
//            keys_list.push(key)
            var value = sum_data[key]
            c_value_list.push(value)
            var data_dict = {};
            max_chart_count_list['name']=count_data["label"];
            max_chart_count_list['type']='line';
            max_chart_count_list['data']=c_value_list;

        }

       max_chart_list.push(max_chart_count_list)
      const g_data = [this.state.Actual, this.state.Budget]
      this.setState({g:g_data})
      const m = [{name: "SQBL", data: [1000000], type: "column"},]
      this.setState({mixed_chart_series:max_chart_list})
      this.setState({mix_table_columns:table_column_list})
     this.setState({mix_table_data:table_data_list})

     this.setState({download_mixedChart_table:[table_dict]})
    }

}


render() {
    return (
   <div id="chart">
        <select class="custom-select"  value={this.state.value_mx} onChange={this.mixedCharthandleSubmit}
            style={{ width:"110px", marginLeft:"8px" }}>
             <option>{this.state.select_group}</option>
             {this.state.books.map((value,index)=>
                      {return   <option class="btn btn-custom btn-block btn-detail"
                      style={{ cursor: "pointer;", fontSize: "14px"}} key={index}> {value} </option> }
                      )}
       </select>
       <select class="custom-select"  value={this.state.value_my} onChange={this.mixedCharthandleSubmit1}
            style={{ width:"110px", marginLeft:"8px" }}>
             <option>{this.state.select_amount}</option>
             {this.state.intHeader.map((value,index)=>
                      {return   <option class="btn btn-custom btn-block btn-detail"
                      style={{ cursor: "pointer;", fontSize: "14px"}} key={index}> {value} </option> }
                      )}
       </select>
       <select class="custom-select"  value={this.state.value_mz} onChange={this.mixedCharthandleSubmit2}
            style={{ width:"110px", marginLeft:"8px" }}>
             <option>{this.state.select_group}</option>
             {this.state.books.map((value,index)=>
                      {return   <option class="btn btn-custom btn-block btn-detail"
                      style={{ cursor: "pointer;", fontSize: "14px"}} key={index}> {value} </option> }
                      )}
       </select>
       <React.Fragment>
            <button onClick={this.mixed_handleSubmit} className='btn btn-info' style={{marginLeft:"15px"}}
              type='button'>OK</button>
        </React.Fragment>
        <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#myModal_Mixed"
        style={{marginLeft:"10px", marginTop:"5px"}}>Table View</button>
          <div class="modal fade" id="myModal_Mixed" role="dialog">
            <div class="modal-dialog">
              <div class="modal-content">
                <div class="modal-header">
                 {/* <button type="button" class="close" data-dismiss="modal" style={{marginLeft:"1px"}}>&times;</button> */}
                  <h4 class="modal-title">Mixed Table Data</h4>
                </div>
                <div class="modal-body">
                 <Table columns={this.state.mix_table_columns} dataSource={this.state.mix_table_data}
                 style={{overflowY:"scroll"}}/>

                </div>
                <div class="modal-footer">
                  <button type="button" class="btn btn-info" data-dismiss="modal">Close</button>
                  <CSVLink data={this.state.download_mixedChart_table}>
                  <button type="button" class="btn btn-primary" > Download </button>
                  </CSVLink>;
                </div>
              </div>

            </div>
          </div>

      <ReactApexChart options={this.state.mixed_chart_options}
      series={this.state.mixed_chart_series} type="line" width="420" height="350" />
 </div>

    );
  }
}
export default MixedChart;