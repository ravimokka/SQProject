export { default as ManagementHome } from "./Home";
