import { Chart, Tooltip, Axis, Legend, Pie, Coord, Line, Bar, Point} from 'viser-react';
import * as React from 'react';
import { Row, Col, Card, Button, Icon, Progress, Form , Modal, Table} from "antd";
import axios from "axios";
import ReactApexChart from 'react-apexcharts'
import 'bootstrap/dist/css/bootstrap.min.css';
import $ from 'jquery';
import Popper from 'popper.js';
import 'bootstrap/dist/js/bootstrap.bundle.min';
import { CSVLink } from "react-csv";

const DataSet = require('@antv/data-set');


const scale = [{
  dataKey: 'percent',
  min: 0,
  formatter: '.0%',
}];


const scale1 = [{
  dataKey: 'percent',
  min: 0,
  formatter: '.0%',
}];



const sourceData = [
  { name: 'A', value: 131744 },
  { name: 'B', value: 104970 },
  { name: 'C', value: 29034 },
  { name: 'D', value: 23489 },
  { name: 'E', value: 18203 },
];




const vertical_data = [
  { name: 'A', value: 30000000 },
  { name: 'B', value: 40000000 },
  { name: 'C', value: 530000000 },

];

const vertical_scale = [{
  dataKey: 'value',
  min: 0,
  formatter: function formatter(val) {
             if (val < 100000) {
                                    return Math.round((val/1000) * 10)/10+'k';
                                }
                        else if (val >= 1000000){

                        return val=(val/1000000)+"M";

                        }

                         else {
                                    return val;
                                }
        }
},{
  dataKey: 'year',
  min: 0,
  max: 1,
}];





























var categories_data = [];

var months = categories_data.map((item) => item.month).filter((item, index, array) => array.indexOf(item) == index)


const productTotals = categories_data.reduce((obj, curr) => {
    if(!obj[curr.name]){
        obj[curr.name] = []
    }

    obj[curr.name][months.indexOf(curr.month)] = parseInt(curr.records)
    return obj
}, {})

const series = Object.entries(productTotals).map(([name, prodArr]) => {
    return {
        name: name,
        data: months.map((month, monthIndex) => {
            if(!prodArr[monthIndex]){
                return 0
            } else {
                return prodArr[monthIndex]
            }

        })
    }

})



class AnalyticalTest extends React.Component {

 constructor(props) {
    super(props);
   this.state = {


line_chart_options: {
            chart: {
                  zoom: {
                      enabled: false
                  }
              },
              dataLabels: {
                  enabled: false
              },
              stroke: {
                  curve: 'straight'
              },
              title: {
                  text: '',
                  align: 'left'
              },
              grid: {
                  row: {
                      colors: ['#f3f3f3', 'transparent'], // takes an array which will be repeated on columns
                      opacity: 0.5
                  },
              },
              xaxis: {
                  categories: [...months],
              }
          },
          line_chart_series:[],




options2: {
            plotOptions: {
              bar: {
                horizontal: true,
                dataLabels: {
                  position: 'top',
                },
              }
            },
            dataLabels: {
              enabled: false,
              offsetX: -6,
              style: {
                fontSize: '12px',
                colors: ['#fff']
              }
            },
            stroke: {
              show: true,
              width: 1,
              colors: ['#fff']
            },

            xaxis: {
              categories: [""],
              labels: {
                    formatter: function(val) {
                       if (val < 100000) {
                                    return Math.round((val/1000) * 10)/10+'k';
                                }
                        else if (val >= 1000000){

                        return val=(val/1000000)+"M";

                        }
                         else {
                                    return val;
                                }

                    }
                }
            },
            yaxis: {
              categories: [2001, 2002, 2003, 2004, 2005, 2006, 2007],
              labels: {
                    formatter: function(val) {
                       if (val < 100000) {
                                    return Math.round((val/1000) * 10)/10+'k';
                                }
                        else if (val >= 1000000){

                        return val=(val/1000000)+"M";

                        }
                         else {
                                    return val;
                                }

                    }
                }
            }
          },

      series2:[],


bar_chart_options: {
            plotOptions: {
              bar: {
                horizontal: true,
              }
            },
            dataLabels: {
              enabled: false,

            },


            xaxis: {
              categories: [],
            }
          },
bar_chart_series: [],





mixed_chart_options:  {
            dataLabels: {
              enabled: false
            },

            stroke: {
              width:4
            },
            title: {
              text: '',
              align: 'left',
              offsetX: 110
            },
            xaxis: {
              categories: [],

              labels: {
                    formatter: function(val) {
                       if (val < 100000) {
                                    return Math.round((val/1000) * 10)/10+'k';
                                }
                        else if (val >= 1000000){

                        return val=(val/1000000)+"M";

                        }
                         else {
                                    return val;
                                }

                    }
                }
            },
            yaxis: [
              {
                axisTicks: {
                  show: true,
                },
                axisBorder: {
                  show: true,
                  color: '#008FFB'
                },
                 labels: {
                   style: {
                    color: '#008FFB',
                  },
                    formatter: function(val) {
                       if (val < 100000) {
                                    return Math.round((val/1000) * 10)/10+'k';
                                }
                        else if (val >= 1000000){

                        return val=(val/1000000)+"M";

                        }
                         else {
                                    return val;
                                }

                    }
                },
                title: {
                  text: "",
                  style: {
                    color: '#008FFB',
                  }
                },
                tooltip: {
                  enabled: true
                }
              },

              {
                seriesName: 'Income',
                opposite: true,
                axisTicks: {
                  show: true,
                },
                axisBorder: {
                  show: true,
                  color: '#00E396'
                },
                   labels: {
                   style: {
                    color: '#00E396',
                  },
                    formatter: function(val) {
                       if (val < 100000) {
                                    return Math.round((val/1000) * 10)/10+'k';
                                }
                        else if (val >= 1000000){

                        return val=(val/1000000)+"M";

                        }
                         else {
                                    return val;
                                }

                    }
                },
                title: {
                  text: "",
                  style: {
                    color: '#00E396',
                  }
                },
              },
              {
                seriesName: 'Revenue',
                opposite: true,
                axisTicks: {
                  show: true,
                },
                axisBorder: {
                  show: true,
                  color: '#FEB019'
                },
                 labels: {
                   style: {
                    color: '#FEB019',

                  },
                    formatter: function(val) {
                       if (val < 100000) {
                                    return Math.round((val/1000) * 10)/10+'k';
                                }
                        else if (val >= 1000000){

                        return val=(val/1000000)+"M";

                        }
                         else {
                                    return val;
                                }

                    }
                },
                title: {
                  text: "",
                  style: {
                    color: '#FEB019',
                  }
                }
              },
            ],


            tooltip: {
              fixed: {
                enabled: true,
                position: 'topLeft', // topRight, topLeft, bottomRight, bottomLeft
                offsetY: 30,
                offsetX: 60
              },
            },
            legend: {
              horizontalAlign: 'left',
              offsetX: 40
            }
          },
mixed_chart_series: [{
name: 'Status',
type: 'column',
data: [10]
}, {
name: 'A',
type: 'column',
data: [20]
},

{
name: 'B',
type: 'column',
data: [30]
},
{
name: 'C',
type: 'column',
data: [150]
},


{
name: 'LINE',
type: 'line',
data: [40, 20]
},

],





area_chart_options :{
            chart: {
              stacked: true,

            },
            colors: ['#008FFB', '#00E396', '#CED4DC'],
            dataLabels: {
              enabled: false
            },
            stroke: {
              show: true,

            },
            xaxis: {
              categories:[''],
            },
             yaxis: {

              labels: {
                    formatter: function(val) {
                       if (val < 100000) {
                                    return Math.round((val/1000) * 10)/10+'k';
                                }
                        else if (val >= 1000000){

                        return val=(val/1000000)+"M";

                        }
                        else if (val >= 10000000){

                        return val=(val/10000000)+"10M";

                        }
                        else if (val >= 10000000){

                        return val=(val/10000000)+"100M";

                        }

                        else if (val >= 1000000000){

                        return val=(val/1000000000)+"1B";

                        }
                         else {
                                    return val;
                                }

                    }
                }
            },
            fill: {
              type: 'gradient',
              gradient: {
                opacityFrom: 0.6,
                opacityTo: 0.8,
              }
            },
            legend: {
              position: 'bottom',
              horizontalAlign: 'left'
            },

          },

area_chart_series:[{
            name: 'series1',
            data: [31, 40]
          },
          {
            name: 'series1',
            data: [35, 19]
          }],

      books:[],
     intHeader:[],
     filter:[],
     select_status:"Status",
     select_amount_USD:"Amount_USD",
     chart_data:[],
     donut_data:[],
     pie_data:[],
     bar_data:[],
     ve_bar_data:[],
     line_data:[{name:"", 'A':1, 'B':12}],
     field_list:["A","B"],
     chartData: [],
     sourceData :[],
     line_chart_source_data:[{name: 'A', value: 13000000}],
     sourceData_donut:[],

     table_columns : [{ title: 'Order Number',dataIndex: 'oNumber', key: 'oNumber',}],
     table_data : [{ key: '1', oNumber: 'DVO524',}],


     load_table_columns : [{ title: 'Order Number',dataIndex: 'oNumber', key: 'oNumber',}],
     load_table_data : [{ key: '1', oNumber: 'DVO524',}],

     line_table_columns : [{ title: 'Order Number',dataIndex: 'oNumber', key: 'oNumber',}],
     line_table_data : [{ key: '1', oNumber: 'DVO524',}],

     bar_table_columns : [{ title: 'Order Number',dataIndex: 'oNumber', key: 'oNumber',}],
     bar_table_data : [{ key: '1', oNumber: 'DVO524',}],

     vertical_table_columns : [{ title: 'Order Number',dataIndex: 'oNumber', key: 'oNumber',}],
     vertical_table_data : [{ key: '1', oNumber: 'DVO524',}],

     Gbar_table_columns : [{ title: 'Order Number',dataIndex: 'oNumber', key: 'oNumber',}],
     Gbar_table_data : [{ key: '1', oNumber: 'DVO524',}],

     donut_table_columns : [{ title: 'Order Number',dataIndex: 'oNumber', key: 'oNumber',}],
     donut_table_data : [{ key: '1', oNumber: 'DVO524',}],

     pie_table_columns : [{ title: 'Order Number',dataIndex: 'oNumber', key: 'oNumber',}],
     pie_table_data : [{ key: '1', oNumber: 'DVO524',}],

     mix_table_columns : [{ title: 'Order Number',dataIndex: 'oNumber', key: 'oNumber',}],
     mix_table_data : [{ key: '1', oNumber: 'DVO524',}],

     area_table_columns : [{ title: 'Order Number',dataIndex: 'oNumber', key: 'oNumber',}],
     area_table_data : [{ key: '1', oNumber: 'DVO524',}],
     value_xl : "Status",
     value_yl : "Amount_USD",


       download_lineChart_table :[{ firstname: "Ravi", lastname: "Tomi", email: "ah@smthing.co.com" }],
       download_barChart_table :[{ firstname: "Ravi", lastname: "Tomi", email: "ah@smthing.co.com" }],
       download_verticalChart_table :[{ firstname: "Ravi", lastname: "Tomi", email: "ah@smthing.co.com" }],
       download_group_barChart_table :[{ firstname: "Ravi", lastname: "Tomi", email: "ah@smthing.co.com" }],
       download_donutChart_table :[{ firstname: "Ravi", lastname: "Tomi", email: "ah@smthing.co.com" }],
       download_pieChart_table :[{ firstname: "Ravi", lastname: "Tomi", email: "ah@smthing.co.com" }],
       download_mixedChart_table :[{ firstname: "Ravi", lastname: "Tomi", email: "ah@smthing.co.com" }],
       download_areaChart_table :[{ firstname: "Ravi", lastname: "Tomi", email: "ah@smthing.co.com" }]







      }


   }


 showModal = () => {
    this.setState({ modalVisible: true });
  };

  handleCancel = () => {
    this.setState({ modalVisible: false });
  };



  saveFormRef = formRef => {
    this.formRef = formRef;
  };

  showDrawer = () => {
    this.setState({
      drawerVisible: true
    });
  };

  onClose = () => {
    this.setState({
      drawerVisible: false
    });
  };


// ============================= Loading all charts ====================================================================

componentWillMount() {
    this.loadAnalytical();
     this.loadIntHeaders();
     this.loadAll_count_view();
     this.loadAllChartData({A:"Status", B:"Amount_USD"});
     this.loadMixedChartData({A:"Status", B:"Amount_USD", C:"Status"})
  }

 async loadAnalytical()
  {
    const promise = await axios.post("http://127.0.0.1:8070/api/v1/sqd_api", { firstName: 'Mokka Ravi', lastName: 'Flintstone' });
    const status = promise.status;
    if(status===200)
    {
      const data = promise.data.data;
      console.log(data);
      this.setState({books:data});
    }
  }

async loadIntHeaders()
  {
    const promise = await axios.post("http://127.0.0.1:8070/api/v1/intHeader", { firstName: 'Mokka Ravi', lastName: 'Flintstone' });
    const status = promise.status;
    if(status===200)
    {
      const data = promise.data.data;
      console.log(data);
      this.setState({intHeader:data});
      const d = [{'name': 'Actual','data': []}, {'name': 'Budget','data': []}]
      const dou = [1,3,4]
      this.setState({donut_data:dou})
      this.setState({chart_data:d})
       console.log(this.state.chart_data);

    }
  }
  async loadAll_count_view()
  {
    this.setState({table_columns : []})
    this.setState({table_data : []})

    this.setState({download_barChart_table:[]})
    this.setState({download_verticalChart_table:[]})
    this.setState({download_donutChart_table:[]})
    this.setState({download_pieChart_table:[]})
    const promise = await axios.post("http://127.0.0.1:8070/api/v1/load_count_api");
    const status = promise.status;
    if(status===200)
    {
      const data = promise.data.data;
      var table_dict = data
      var i;
      var keys_list =[];
      var bar_value_list =[];
      var load_chart_list = [];
      var load_donut_chart_list = [];
      var ct_list1 = [];
      var table_column_list = [];
      var table_data_list = [];
      var table_data_dict = {}
      for (i = 0; i < Object.keys(data).length; i++) {
            console.log(data[i])
            var key = Object.keys(data)[i]

            keys_list.push(key)
            if (key != "label"){
            ct_list1.push(key)

            }
            else{}

            var value = data[key]
            if (this.state.value_bar != value){bar_value_list.push(value)}
            else {
            }

            var data_dict = {};

            var load_data_dict = {};
            if (key != "label"){
            data_dict['name']=key;
            load_data_dict['item']=key;
            data_dict['value']=value;
            load_data_dict['count']=value;
            load_chart_list.push(data_dict)
            load_donut_chart_list.push(load_data_dict)
            var column_dict = {}
            column_dict['title'] =key;
            column_dict['dataIndex'] =key;
            column_dict['key'] =key;
            table_data_dict[key] = value;
            table_column_list.push(column_dict)





            }
            else{}
        }
      table_data_list.push(table_data_dict)
      this.setState({bar_data:load_chart_list})
      this.setState({ve_bar_data:load_chart_list})
      this.setState({sourceData:load_donut_chart_list})
      this.setState({sourceData_donut:load_donut_chart_list})

      this.setState({bar_table_columns:table_column_list})
      this.setState({bar_table_data:table_data_list})

      this.setState({vertical_table_columns:table_column_list})
      this.setState({vertical_table_data:table_data_list})

      this.setState({donut_table_columns:table_column_list})
      this.setState({donut_table_data:table_data_list})

      this.setState({pie_table_columns:table_column_list})
      this.setState({pie_table_data:table_data_list})

     this.setState({download_barChart_table:[table_dict]})
    this.setState({download_verticalChart_table:[table_dict]})
    this.setState({download_donutChart_table:[table_dict]})
    this.setState({download_pieChart_table:[table_dict]})






    }
  }



async loadAllChartData(data){

    const headers  = new Headers()
    headers.append('Content-Type', 'application/json');
    const options = {
    method : 'POST',
    headers,
    body:JSON.stringify(data),
    }
    this.setState({load_table_columns : []})
    this.setState({load_table_data : []})
    this.setState({line_data : []})
    this.setState({field_list : []})
    this.setState({line_chart_source_data : []})
    this.setState({chart_data:[]})
    this.setState({area_chart_series:[]})

     this.setState({download_lineChart_table:[]})
     this.setState({download_group_barChart_table:[]})
 const promise = await axios.post("http://127.0.0.1:8070/api/v1/data", options);
    const status = promise.status;

    if(status===200)
    {
      const data = promise.data.data;
      var l_data = [data];
      var table_dict = [data]
      this.setState(data);
      var i;
      var keys_list =[];
      var line_value_list =[];
      var line_chart_list = [];
      var load_bar_chart_list = [];
       var table_column_list = [];
       var table_data_list = [];
       var table_data_dict = {}
       var area_list = [];
       var area_chart_data = [];
      for (i = 0; i < Object.keys(data).length; i++) {
            console.log(data[i])
            var key = Object.keys(data)[i]
            keys_list.push(key)
            var value = data[key]
            line_value_list.push(value)
            var data_dict = {};
            data_dict['name']=key;
            data_dict['value']=value;
            line_chart_list.push(data_dict)
            var load_data_dict = {};
            load_data_dict['name']=key;
            load_data_dict['data']=[value];
            load_bar_chart_list.push(load_data_dict)
            var column_dict = {}
            column_dict['title'] =key;
            column_dict['dataIndex'] =key;
            column_dict['key'] =key;
            table_data_dict[key] = value;
            table_column_list.push(column_dict)

            var area_dict = {}
            area_list.push(value);
            area_dict['name']=key;
            area_dict['data'] = area_list;
            area_chart_data.push(area_dict);


        }
       table_data_list.push(table_data_dict)


      this.setState({line_chart_source_data:line_chart_list})
      this.setState({field_list:keys_list})
      this.setState({chart_data:load_bar_chart_list})
      this.setState({area_chart_series:area_chart_data})


      this.setState({line_table_columns:table_column_list})
      this.setState({line_table_data:table_data_list})

       this.setState({Gbar_table_columns:table_column_list})
      this.setState({Gbar_table_data:table_data_list})

       this.setState({mix_table_columns:table_column_list})
      this.setState({mix_table_data:table_data_list})

       this.setState({area_table_columns:table_column_list})
      this.setState({area_table_data:table_data_list})


       this.setState({download_lineChart_table:table_dict})
       this.setState({download_group_barChart_table:table_dict})
       this.setState({download_areaChart_table:table_dict})
 }
}

async loadMixedChartData(data){

    const headers  = new Headers()
    headers.append('Content-Type', 'application/json');
    const options = {
    method : 'POST',
    headers,
    body:JSON.stringify(data),
    }
    this.setState({mixed_chart_series : []})

    this.setState({mix_table_columns:[]})
     this.setState({mix_table_data:[]})


     this.setState({download_mixedChart_table:[]})
 const promise = await axios.post("http://127.0.0.1:8070/api/v1/dataView_api", options);
    const status = promise.status;
    if(status===200)
    {

      const sum_data = promise.data.data["sum_data"];
      const count_data = promise.data.data["count_data"];
      var table_dict = sum_data;
      this.setState(data);
      var i;
      var keys_list =[];
      var value_list =[];
      var max_chart_list = [];

      var table_column_list = [];
      var table_data_list = [];
      var table_data_dict = {}

      for (i = 0; i < Object.keys(sum_data).length; i++) {
            console.log(data[i])
            var key = Object.keys(sum_data)[i]
//            keys_list.push(key)
            var value = sum_data[key]
            value_list.push(value)
            var data_dict = {};
            data_dict['name']=key;
            data_dict['type']='column';
            data_dict['data']=[value];
            max_chart_list.push(data_dict)

            var column_dict = {}
            column_dict['title'] =key;
            column_dict['dataIndex'] =key;
            column_dict['key'] =key;
            table_data_dict[key] = value;
            table_column_list.push(column_dict)
        }
      table_data_list.push(table_data_dict)
      var j;
      var c_keys_list =[];
      var c_value_list =[];
      var max_chart_count_list ={};
      for (j = 0; j < Object.keys(count_data).length; j++) {
            console.log(data[j])
            var key = Object.keys(sum_data)[j]
//            keys_list.push(key)
            var value = sum_data[key]
            c_value_list.push(value)
            var data_dict = {};
            max_chart_count_list['name']=count_data["label"];
            max_chart_count_list['type']='line';
            max_chart_count_list['data']=c_value_list;

        }

       max_chart_list.push(max_chart_count_list)
      const g_data = [this.state.Actual, this.state.Budget]
      this.setState({g:g_data})
      this.setState({mixed_chart_series:max_chart_list})
      this.setState({mix_table_columns:table_column_list})
     this.setState({mix_table_data:table_data_list})

     this.setState({download_mixedChart_table:[table_dict]})
    }

}


// =================================================== Line Chart ======================================================

handleSubmitLineChart = (e) => {
     this.setState({value_xl:""})
     this.setState({value_xl: e.target.value});
 };

handleSubmitLineChart1 = (e) => {
    this.setState({value_yl:""})
    this.setState({value_yl: e.target.value});
  };


handleSubmitLineChartOK = (e) => {
    e.preventDefault();
     this.loadLineChartData(
         {A:this.state.value_xl, B:this.state.value_yl}
  );
  };


async loadLineChartData(data){

    const headers  = new Headers()
    headers.append('Content-Type', 'application/json');
    const options = {
    method : 'POST',
    headers,
    body:JSON.stringify(data),
    }
    this.setState({line_data : []})
    this.setState({field_list : []})
    this.setState({line_chart_source_data : []})

     this.setState({line_table_columns:[]})
      this.setState({line_table_data:[]})
      this.setState({download_lineChart_table:[]})
 const promise = await axios.post("http://127.0.0.1:8070/api/v1/data", options);
    const status = promise.status;

    if(status===200)
    {
      const data = promise.data.data;
      const table_dict = data
      var l_data = [data];
      this.setState(data);
      var i;
      var keys_list =[];
      var line_value_list =[];
      var line_chart_list = []
       var table_column_list = [];
       var table_data_list = [];
       var table_data_dict = {}
      for (i = 0; i < Object.keys(data).length; i++) {
            console.log(data[i])
            var key = Object.keys(data)[i]
            keys_list.push(key)
            var value = data[key]
            line_value_list.push(value)
            var data_dict = {};
            data_dict['name']=key;
            data_dict['value']=value;
            line_chart_list.push(data_dict)
            var column_dict = {}
            column_dict['title'] =key;
            column_dict['dataIndex'] =key;
            column_dict['key'] =key;
            table_data_dict[key] = value;
            table_column_list.push(column_dict)
        }

      table_data_list.push(table_data_dict)
      this.setState({download_lineChart_table:[table_dict]})
      this.setState({line_chart_source_data:line_chart_list})
      this.setState({field_list:keys_list})

      this.setState({line_table_columns:table_column_list})
      this.setState({line_table_data:table_data_list})
    }
}


//=================================================== Line Chart Table Data Download ===================================








//================================================ Group Bar Chart ====================================================================
handleSubmit = (e) => {
     this.setState({value_x: e.target.value});
 };

handleSubmit1 = (e) => {
    this.setState({value_y: e.target.value});
  };


handleSubmit12 = (e) => {
    e.preventDefault();
     this.loadGroupBarData(
         {A:this.state.value_x, B:this.state.value_y}
  );
  };


async loadGroupBarData(data){

    const headers  = new Headers()
    headers.append('Content-Type', 'application/json');
    const options = {
    method : 'POST',
    headers,
    body:JSON.stringify(data),
    }
    this.setState({chart_data : []})
    this.setState({Gbar_table_columns:[]})
      this.setState({Gbar_table_data:[]})

      this.setState({download_group_barChart_table:[]})
 const promise = await axios.post("http://127.0.0.1:8070/api/v1/data", options);
    const status = promise.status;
    if(status===200)
    {
      const data = promise.data.data;
      var table_dict = data;
      this.setState(data);
      var i;
      var keys_list =[];
      var value_list =[];
      var chart_list = [];
       var table_column_list = [];
       var table_data_list = [];
       var table_data_dict = {}


      for (i = 0; i < Object.keys(data).length; i++) {
            console.log(data[i])
            var key = Object.keys(data)[i]
//            keys_list.push(key)
            var value = data[key]
//            value_list.push(value)
            var data_dict = {};
            data_dict['name']=key;
            data_dict['data']=[value];
            chart_list.push(data_dict)

            var column_dict = {}
            column_dict['title'] =key;
            column_dict['dataIndex'] =key;
            column_dict['key'] =key;
            table_data_dict[key] = value;
            table_column_list.push(column_dict)
        }

      table_data_list.push(table_data_dict)
      const g_data = [this.state.Actual, this.state.Budget]
      this.setState({g:g_data})
      this.setState({chart_data:chart_list})

      this.setState({Gbar_table_columns:table_column_list})
      this.setState({Gbar_table_data:table_data_list})

      this.setState({download_group_barChart_table:[table_dict]})
    }

}

//========================================== Bar Chart ================================================================
handleSubmitBarChart = (e) => {
        e.preventDefault();
        this.setState({value_bar: e.target.value});
         this.BarCheckbox(
             {Column:e.target.value }
      );
 };


async BarCheckbox(data){
    const headers  = new Headers()
    headers.append('Content-Type', 'application/json');
    const options = {
    method : 'POST',
    headers,
    body:JSON.stringify(data),
    }

    this.setState({bar_data : []})

    this.setState({bar_table_columns:[]})
    this.setState({bar_table_data:[]})
   this.setState({download_barChart_table:[]})
    const promise = await axios.post("http://127.0.0.1:8070/api/v1/count_api", options);
    const status = promise.status;
    if(status===200)
    {
      const data = promise.data.data;
      var table_dict = data;
      this.setState(data);
      console.log(data);
      var i;
      var keys_list =[];
      var bar_value_list =[];
      var Bar_chart_list = []
      var ct_list1 = []
      var table_column_list = [];
      var table_data_list = [];
      var table_data_dict = {}

      for (i = 0; i < Object.keys(data).length; i++) {
            console.log(data[i])
            var key = Object.keys(data)[i]
            keys_list.push(key)
            if (key != "label"){
            ct_list1.push(key)

            }
            else{}

            var value = data[key]
            if (this.state.value_bar != value){bar_value_list.push(value)}
            else {
            }

            var data_dict = {};
            if (key != "label"){
            data_dict['name']=key;
            data_dict['value']=value;
            Bar_chart_list.push(data_dict)

            var column_dict = {}
            column_dict['title'] =key;
            column_dict['dataIndex'] =key;
            column_dict['key'] =key;
            table_data_dict[key] = value;
            table_column_list.push(column_dict)


            }
            else{}
        }

      table_data_list.push(table_data_dict)
      this.setState({bar_data:Bar_chart_list})
      this.setState({bar_table_columns:table_column_list})
      this.setState({bar_table_data:table_data_list})


      this.setState({download_barChart_table:[table_dict]})

    }

}


//========================================== Vertical bar Chart ================================================================
handleSubmitVerticalBarChart = (e) => {
        e.preventDefault();
        this.setState({value_v_bar: e.target.value});
         this.VerticalBarCheckbox(
             {Column:e.target.value }
      );
 };


async VerticalBarCheckbox(data){
    const headers  = new Headers()
    headers.append('Content-Type', 'application/json');
    const options = {
    method : 'POST',
    headers,
    body:JSON.stringify(data),
    }

    this.setState({ve_bar_data : []})

    this.setState({vertical_table_columns:[]})
      this.setState({vertical_table_data:[]})


 this.setState({download_verticalChart_table:[]})
    const promise = await axios.post("http://127.0.0.1:8070/api/v1/count_api", options);
    const status = promise.status;
    if(status===200)
    {
      const data = promise.data.data;
      var table_dict = data;

      this.setState(data);
      console.log(data);
      var i;
      var keys_list =[];
      var bar_value_list =[];
      var Ve_Bar_chart_list = []
      var ct_list1 = []

      var table_column_list = [];
      var table_data_list = [];
      var table_data_dict = {}
      for (i = 0; i < Object.keys(data).length; i++) {
            console.log(data[i])
            var key = Object.keys(data)[i]

            keys_list.push(key)
            if (key != "label"){
            ct_list1.push(key)

            }
            else{}

            var value = data[key]
            if (this.state.value_bar != value){bar_value_list.push(value)}
            else {
            }

            var data_dict = {};
            if (key != "label"){
            data_dict['name']=key;
            data_dict['value']=value;
            Ve_Bar_chart_list.push(data_dict)

            var column_dict = {}
            column_dict['title'] =key;
            column_dict['dataIndex'] =key;
            column_dict['key'] =key;
            table_data_dict[key] = value;
            table_column_list.push(column_dict)



            }
            else{}
        }
     table_data_list.push(table_data_dict)
     this.setState({ve_bar_data:Ve_Bar_chart_list})
     this.setState({vertical_table_columns:table_column_list})
     this.setState({vertical_table_data:table_data_list})

     this.setState({download_verticalChart_table:[table_dict]})

    }

}











//========================================== Donut Chart ================================================================
handleSubmitDonut = (e) => {
    e.preventDefault();
    this.setState({value_donut: e.target.value});
     this.DonutCheckbox(
         {Column:e.target.value }
  );
  };
async DonutCheckbox(data){

    const headers  = new Headers()
    headers.append('Content-Type', 'application/json');
    const options = {
    method : 'POST',
    headers,
    body:JSON.stringify(data),
    }

    this.setState({sourceData_donut : []})
    this.setState({donut_table_columns:[]})
     this.setState({donut_table_data:[]})
     this.setState({download_donutChart_table:[]})

    const promise = await axios.post("http://127.0.0.1:8070/api/v1/count_api", options);
    const status = promise.status;
    if(status===200)
    {
      const data = promise.data.data;
      var table_dict = data;
      this.setState(data);
      console.log(data);
      var i;
      var keys_list =[];
      var value_list =[];
      var chart_list = []
      var ct_list1 = []

      var table_column_list = [];
      var table_data_list = [];
      var table_data_dict = {}

      for (i = 0; i < Object.keys(data).length; i++) {
            console.log(data[i])
            var key = Object.keys(data)[i]

            keys_list.push(key)
            if (key != "label"){
            ct_list1.push(key)

            }
            else{}

            var value = data[key]
            if (this.state.value != value){value_list.push(value)}
            else {
            }

            var data_dict = {};
            if (key != "label"){
            data_dict['item']=key;
            data_dict['count']=value;
            chart_list.push(data_dict)

            var column_dict = {}
            column_dict['title'] =key;
            column_dict['dataIndex'] =key;
            column_dict['key'] =key;
            table_data_dict[key] = value;
            table_column_list.push(column_dict)

            }
            else{}


        }
      table_data_list.push(table_data_dict)
      this.setState({sourceData_donut:chart_list})
      this.setState({donut_data:value_list})
      this.setState({donut_table_columns:table_column_list})
     this.setState({donut_table_data:table_data_list})

     this.setState({download_donutChart_table:[table_dict]})

    }

}


//===============================================Pie Chart ==============================================================
 handleSubmitPie = (e) => {
    e.preventDefault();
    this.setState({value_pie: e.target.value});
     this.PieCheckbox(
         {Column:e.target.value }
  );
  };
async PieCheckbox(data){

    const headers  = new Headers()
    headers.append('Content-Type', 'application/json');
    const options = {
    method : 'POST',
    headers,
    body:JSON.stringify(data),
    }

    this.setState({sourceData : []})

    this.setState({pie_table_columns:[]})
     this.setState({pie_table_data:[]})

     this.setState({download_pieChart_table:[]})
    const promise = await axios.post("http://127.0.0.1:8070/api/v1/count_api", options);
    const status = promise.status;
    if(status===200)
    {
      const data = promise.data.data;

      var table_dict = data;
      this.setState(data);
      console.log(data);
      var i;
      var keys_list =[];
      var value_list =[];
      var chart_list = []
      var ct_list1 = []

      var table_column_list = [];
      var table_data_list = [];
      var table_data_dict = {}
      for (i = 0; i < Object.keys(data).length; i++) {
            console.log(data[i])
            var key = Object.keys(data)[i]

            keys_list.push(key)
            if (key != "label"){
            ct_list1.push(key)

            }
            else{}

            var value = data[key]
            if (this.state.value != value){value_list.push(value)}
            else {
            }

            var data_dict = {};
            if (key != "label"){
            data_dict['item']=key;
            data_dict['count']=value;
            chart_list.push(data_dict)

            var column_dict = {}
            column_dict['title'] =key;
            column_dict['dataIndex'] =key;
            column_dict['key'] =key;
            table_data_dict[key] = value;
            table_column_list.push(column_dict)

            }
            else{}


        }

      table_data_list.push(table_data_dict)
      this.setState({sourceData:chart_list})
      this.setState({donut_data:value_list})
      this.setState({pie_table_columns:table_column_list})
     this.setState({pie_table_data:table_data_list})

     this.setState({download_pieChart_table:[table_dict]})

    }

}

//=================================================Mixed chart==========================================================

mixedCharthandleSubmit = (e) => {
     this.setState({value_mx: e.target.value});
 };

mixedCharthandleSubmit1 = (e) => {
    this.setState({value_my: e.target.value});
  };


 mixedCharthandleSubmit2 = (e) => {
    this.setState({value_mz: e.target.value});
  };


mixed_handleSubmit = (e) => {
    e.preventDefault();
     this.loadMixedChartData(
         {A:this.state.value_mx, B:this.state.value_my, C:this.state.value_mz}
  );
  };


async loadMixedChartData(data){

    const headers  = new Headers()
    headers.append('Content-Type', 'application/json');
    const options = {
    method : 'POST',
    headers,
    body:JSON.stringify(data),
    }
    this.setState({mixed_chart_series : []})

    this.setState({mix_table_columns:[]})
     this.setState({mix_table_data:[]})

     this.setState({download_mixedChart_table:[]})
 const promise = await axios.post("http://127.0.0.1:8070/api/v1/dataView_api", options);
    const status = promise.status;
    if(status===200)
    {

      const sum_data = promise.data.data["sum_data"];
      const count_data = promise.data.data["count_data"];
      var table_dict = sum_data;
      this.setState(data);
      var i;
      var keys_list =[];
      var value_list =[];
      var max_chart_list = [];

      var table_column_list = [];
      var table_data_list = [];
      var table_data_dict = {}

      for (i = 0; i < Object.keys(sum_data).length; i++) {
            console.log(data[i])
            var key = Object.keys(sum_data)[i]
//            keys_list.push(key)
            var value = sum_data[key]
            value_list.push(value)
            var data_dict = {};
            data_dict['name']=key;
            data_dict['type']='column';
            data_dict['data']=[value];
            max_chart_list.push(data_dict)

            var column_dict = {}
            column_dict['title'] =key;
            column_dict['dataIndex'] =key;
            column_dict['key'] =key;
            table_data_dict[key] = value;
            table_column_list.push(column_dict)
        }
      table_data_list.push(table_data_dict)
      var j;
      var c_keys_list =[];
      var c_value_list =[];
      var max_chart_count_list ={};
      for (j = 0; j < Object.keys(count_data).length; j++) {
            console.log(data[j])
            var key = Object.keys(sum_data)[j]
//            keys_list.push(key)
            var value = sum_data[key]
            c_value_list.push(value)
            var data_dict = {};
            max_chart_count_list['name']=count_data["label"];
            max_chart_count_list['type']='line';
            max_chart_count_list['data']=c_value_list;

        }

       max_chart_list.push(max_chart_count_list)
      const g_data = [this.state.Actual, this.state.Budget]
      this.setState({g:g_data})
      const m = [{name: "SQBL", data: [1000000], type: "column"},]
      this.setState({mixed_chart_series:max_chart_list})
      this.setState({mix_table_columns:table_column_list})
     this.setState({mix_table_data:table_data_list})

     this.setState({download_mixedChart_table:[table_dict]})
    }

}

//==========================================================Stacked Area chart==========================================

Area_CharthandleSubmit = (e) => {
     this.setState({value_ax: e.target.value});
 };

Area_CharthandleSubmit1 = (e) => {
    this.setState({value_ay: e.target.value});
  };


area_handleSubmit = (e) => {
    e.preventDefault();
     this.loadStackedAreaChartData(
         {A:this.state.value_ax, B:this.state.value_ay}
  );
  };


async loadStackedAreaChartData(data){

    const headers  = new Headers()
    headers.append('Content-Type', 'application/json');
    const options = {
    method : 'POST',
    headers,
    body:JSON.stringify(data),
    }
    this.setState({area_chart_series : []})
    this.setState({download_areaChart_table : []})

 const promise = await axios.post("http://127.0.0.1:8070/api/v1/data", options);
    const status = promise.status;
    if(status===200)
    {
      const data = promise.data.data;
      var table_dict = data;
      this.setState(data);
      var i;
      var keys_list =[];
      var value_list =[];

      var table_column_list = [];
      var table_data_list = [];
      var table_data_dict = {};

      var SArea_chart_list = [];
      for (i = 0; i < Object.keys(data).length; i++) {
            console.log(data[i])
            var key = Object.keys(data)[i]
            keys_list.push(key)
            var value = data[key]
            value_list.push(value)
            var data_dict = {};
            data_dict['name']=key;
            data_dict['data']=value_list;
            SArea_chart_list.push(data_dict)

            var column_dict = {}
            column_dict['title'] =key;
            column_dict['dataIndex'] =key;
            column_dict['key'] =key;
            table_data_dict[key] = value;
            table_column_list.push(column_dict)

        }
        table_data_list.push(table_data_dict)
      this.setState({area_chart_series:SArea_chart_list})

       this.setState({area_table_columns:table_column_list})
      this.setState({area_table_data:table_data_list})


      this.setState({download_areaChart_table : [table_dict]})
    }

}


















componentDidMount() {
//  const sourceDataDaily = {"Actual": 1800000, "Budget": 18000};
//  this.setState({line_data:sourceDataDaily})


  }




  render() {


const dv = new DataSet.View().source(this.state.sourceData);
dv.transform({
  type: 'percent',
  field: 'count',
  dimension: 'item',
  as: 'percent',
  align: 'left'
});
const pie_data = dv.rows;


const dv1 = new DataSet.View().source(this.state.sourceData_donut);
dv1.transform({
  type: 'percent',
  field: 'count',
  dimension: 'item',
  as: 'percent'
});
const don_data = dv1.rows;

const dv12 = new DataSet.View().source(this.state.line_data);
    dv12.transform({
      type: "fold",
      fields:this.state.field_list,
      key: "keySelect",
      value: "average"
    });
    const data1233 = dv12.rows;



const bar_dv = new DataSet.View().source(this.state.bar_data);
bar_dv.transform({
  type: 'sort',
  callback(a, b) {
    return a.value - b.value > 0;
  },
});
const basic_bar_data = bar_dv.rows;





const line_chart_source_scale = [{
  dataKey: 'value',
  min: 0,
  formatter: function formatter(val) {
             if (val < 100000) {
                                    return Math.round((val/1000) * 10)/10+'k';
                                }
                        else if (val >= 1000000){

                        return val=(val/1000000)+"M";

                        }

                         else {
                                    return val;
                                }
        }
},{
  dataKey: 'year',
  min: 0,
  max: 1,
}];



const ve_bar_dv = new DataSet.View().source(this.state.ve_bar_data);
ve_bar_dv.transform({
  type: 'sort',
  callback(a, b) {
    return a.value - b.value > 0;
  },
});
const vertical_bar_data = ve_bar_dv.rows;



    return (
    <div>
        <div id="content">
        <Row type="flex" gutter={24}>
            <Col xs={24} sm={24} md={{span: 12, order: 4}} lg={12} xl={{span:12, order: 5}} className="c-mb">
            <Card
                title=""
                style={{ minHeight: "100%" }}
                bordered={false}
                className="mi-card mi-card-header-borderless mi-card-boxshadow" >
               <div id="chart">
                    <select class="custom-select"  value={this.state.value_xl} onChange={this.handleSubmitLineChart}
                        style={{ width:"110px", marginLeft:"20px" }}>
                         <option>{this.state.select_status}</option>
                         {this.state.books.map((value,index)=>
                                  {return   <option class="btn btn-custom btn-block btn-detail"
                                  style={{ cursor: "pointer;", fontSize: "14px"}} key={index}> {value} </option> }
                                  )}
                   </select>
                   <select class="custom-select"  value={this.state.value_yl} onChange={this.handleSubmitLineChart1}
                        style={{ width:"110px", marginLeft:"20px" }}>
                         <option>{this.state.select_amount_USD}</option>
                         {this.state.intHeader.map((value,index)=>
                                  {return   <option class="btn btn-custom btn-block btn-detail"
                                  style={{ cursor: "pointer;", fontSize: "14px"}} key={index}> {value} </option> }
                                  )}
                   </select>
                   <React.Fragment>
                        <button onClick={this.handleSubmitLineChartOK} className='btn btn-info' style={{marginLeft:"10px"}}
                          type='button'>OK</button>
                    </React.Fragment>
          <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#myModal_line" style={{marginLeft:"3px"}}>
                    Table View</button>
                      <div class="modal fade" id="myModal_line" role="dialog">
                        <div class="modal-dialog">
                          <div class="modal-content">
                            <div class="modal-header">
                             {/* <button type="button" class="close" data-dismiss="modal" style={{marginLeft:"1px"}}>&times;</button> */}
                              <h4 class="modal-title">Line Chart TableData</h4>

                            </div>
                            <div>
                            <h5 class="modal-title" style={{marginLeft:"160px"}}>
                            {this.state.value_xl}, {this.state.value_yl}</h5>
                            </div>
                            <div class="modal-body">
                             <Table columns={this.state.line_table_columns} dataSource={this.state.line_table_data} style={{overflowY:"scroll"}}/>

                            </div>
                            <div class="modal-footer">
                              <button type="button" class="btn btn-info" data-dismiss="modal">Close</button>
                              <CSVLink data={this.state.download_lineChart_table}>
                              <button type="button" class="btn btn-primary" > Download </button>
                              </CSVLink>;
                            </div>
                          </div>

                        </div>
                      </div>

      <Chart forceFit height={400} data={this.state.line_chart_source_data} scale={line_chart_source_scale}>
        <Tooltip />
        <Axis />
        <Legend />
        <Line position="name*value"/>
        <Point position="name*value" shape="circle"/>
      </Chart>


             </div>
         </Card>
      </Col>
<Col xs={24} sm={24} md={{span: 12, order: 4}} lg={12} xl={{span:12, order: 5}} className="c-mb">
            <Card
                title=""
                style={{ minHeight: "100%" }}
                bordered={false}
                className="mi-card mi-card-header-borderless mi-card-boxshadow" >
               <div id="chart">
                    <select class="custom-select"  value={this.state.value_bar} onChange={this.handleSubmitBarChart}
                        style={{ width:"110px", marginLeft:"20px" }}>
                         <option>{this.state.select_status}</option>
                         {this.state.books.map((value,index)=>
                                  {return   <option class="btn btn-custom btn-block btn-detail"
                                  style={{ cursor: "pointer;", fontSize: "14px"}} key={index}> {value} </option> }
                                  )}
                   </select>
                    <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#myModalBar" style={{marginLeft:"3px"}}>
                    Table View</button>
                      <div class="modal fade" id="myModalBar" role="dialog">
                        <div class="modal-dialog">
                          <div class="modal-content">
                            <div class="modal-header">
                             {/* <button type="button" class="close" data-dismiss="modal" style={{marginLeft:"1px"}}>&times;</button> */}
                              <h4 class="modal-title">Bar Chart Table Data</h4>
                            </div>
                            <div class="modal-body">
                             <Table columns={this.state.bar_table_columns} dataSource={this.state.bar_table_data} style={{overflowY:"scroll"}}/>

                            </div>
                            <div class="modal-footer">
                              <button type="button" class="btn btn-info" data-dismiss="modal">Close</button>
                              <CSVLink data={this.state.download_barChart_table}>
                              <button type="button" class="btn btn-primary" > Download </button>
                              </CSVLink>;
                            </div>
                          </div>

                        </div>
                      </div>

               <Chart forceFit height={400} data={basic_bar_data} scale={line_chart_source_scale}>
        <Coord type="rect" direction="LB" />
        <Tooltip />
        <Axis dataKey="country" label={{ offset: 12 }} />
        <Bar position="name*value" />
      </Chart>
             </div>
         </Card>
      </Col>


 </Row>
 <Row type="flex" gutter={24}>
           <Col xs={24} sm={24} md={{span: 12, order: 4}} lg={12} xl={{span:12, order: 5}} className="c-mb">
            <Card
                title=""
                style={{ minHeight: "100%" }}
                bordered={false}
                className="mi-card mi-card-header-borderless mi-card-boxshadow" >
               <div id="chart">
                    <select class="custom-select"  value={this.state.value_v_bar} onChange={this.handleSubmitVerticalBarChart}
                        style={{ width:"110px", marginLeft:"20px" }}>
                         <option  value="" >{this.state.select_status}</option>
                         {this.state.books.map((value,index)=>
                                  {return   <option class="btn btn-custom btn-block btn-detail"
                                  style={{ cursor: "pointer;", fontSize: "14px"}} key={index}> {value} </option> }
                                  )}
                   </select>
                   <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#myModal_Vertical" style={{marginLeft:"3px"}}>
                    Table View</button>
                      <div class="modal fade" id="myModal_Vertical" role="dialog">
                        <div class="modal-dialog">
                          <div class="modal-content">
                            <div class="modal-header">
                             {/* <button type="button" class="close" data-dismiss="modal" style={{marginLeft:"1px"}}>&times;</button> */}
                              <h4 class="modal-title">Vertical Bar Chart Table Data</h4>
                            </div>
                            <div class="modal-body">
                             <Table columns={this.state.vertical_table_columns} dataSource={this.state.vertical_table_data} style={{overflowY:"scroll"}}/>

                            </div>
                            <div class="modal-footer">
                              <button type="button" class="btn btn-info" data-dismiss="modal">Close</button>
                              <CSVLink data={this.state.download_verticalChart_table}>
                              <button type="button" class="btn btn-primary" > Download </button>
                              </CSVLink>;
                            </div>
                          </div>

                        </div>
                      </div>

      <Chart forceFit height={400} data={vertical_bar_data} scale={vertical_scale}>
        <Tooltip />
        <Axis />
        <Bar position="name*value" />
      </Chart>
             </div>
         </Card>
      </Col>

<Col xs={24} sm={24} md={{span: 12, order: 4}} lg={12} xl={{span:12, order: 5}} className="c-mb">
            <Card
                title=""
                style={{ minHeight: "100%" }}
                bordered={false}
                className="mi-card mi-card-header-borderless mi-card-boxshadow" >
               <div id="chart">
                    <select class="custom-select"  value={this.state.value_x} onChange={this.handleSubmit}
                        style={{ width:"110px", marginLeft:"20px" }}>
                         <option>Status</option>
                         {this.state.books.map((value,index)=>
                                  {return   <option class="btn btn-custom btn-block btn-detail"
                                  style={{ cursor: "pointer;", fontSize: "14px"}} key={index}> {value} </option> }
                                  )}
                   </select>
                   <select class="custom-select"  value={this.state.value_y} onChange={this.handleSubmit1}
                        style={{ width:"110px", marginLeft:"20px" }}>
                         <option>Amount_USD</option>
                         {this.state.intHeader.map((value,index)=>
                                  {return   <option class="btn btn-custom btn-block btn-detail"
                                  style={{ cursor: "pointer;", fontSize: "14px"}} key={index}> {value} </option> }
                                  )}
                   </select>
                   <React.Fragment>
                        <button onClick={this.handleSubmit12} className='btn btn-info' style={{marginLeft:"10px"}}
                          type='button'>OK</button>
                    </React.Fragment>
                    <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#myModal_GroupBar"
                    style={{marginLeft:"3px"}}>Table View</button>
                      <div class="modal fade" id="myModal_GroupBar" role="dialog">
                        <div class="modal-dialog">
                          <div class="modal-content">
                            <div class="modal-header">
                             {/* <button type="button" class="close" data-dismiss="modal" style={{marginLeft:"1px"}}>&times;</button> */}
                              <h4 class="modal-title">Group Bar TableData</h4>
                            </div>
                            <div class="modal-body">
                             <Table columns={this.state.Gbar_table_columns} dataSource={this.state.Gbar_table_data} style={{overflowY:"scroll"}}/>

                            </div>
                            <div class="modal-footer">
                              <button type="button" class="btn btn-info" data-dismiss="modal">Close</button>
                              <CSVLink data={this.state.download_group_barChart_table}>
                              <button type="button" class="btn btn-primary" > Download </button>
                              </CSVLink>;
                            </div>
                          </div>

                        </div>
                      </div>

                  <ReactApexChart options={this.state.options2} series={this.state.chart_data} type="bar" width="420" height="350" />
             </div>
         </Card>
      </Col>
 </Row>


 <Row type="flex" gutter={24}>

 <Col xs={24} sm={24} md={{span: 12, order: 4}} lg={12} xl={{span:12, order: 5}} className="c-mb">

        <Card
                title=""
                style={{ minHeight: "100%" }}
                bordered={false}
                className="mi-card mi-card-header-borderless mi-card-boxshadow" >
         <div id="chart">
        <select class="custom-select"  value={this.state.value_donut} onChange={this.handleSubmitDonut}
                    style={{ width:"110px", marginLeft:"20px" }}>
                     <option  value="" >{this.state.select_status}</option>
                     {this.state.books.map((value,index)=>
                              {return   <option class="btn btn-custom btn-block btn-detail"
                              style={{ cursor: "pointer;", fontSize: "14px"}} key={index}> {value} </option> }
                              )}


                             </select>
                             <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#myModal_Donut" style={{marginLeft:"3px"}}>
                    Table View</button>
                      <div class="modal fade" id="myModal_Donut" role="dialog">
                        <div class="modal-dialog">
                          <div class="modal-content">
                            <div class="modal-header">
                             {/* <button type="button" class="close" data-dismiss="modal" style={{marginLeft:"1px"}}>&times;</button> */}
                              <h4 class="modal-title">Donut Chart TableData</h4>
                            </div>
                            <div class="modal-body">
                             <Table columns={this.state.donut_table_columns} dataSource={this.state.donut_table_data} style={{overflowY:"scroll"}}/>


                            </div>
                            <div class="modal-footer">
                              <button type="button" class="btn btn-info" data-dismiss="modal">Close</button>
                              <CSVLink data={this.state.download_donutChart_table}>
                              <button type="button" class="btn btn-primary" > Download </button>
                              </CSVLink>;
                            </div>
                          </div>

                        </div>
                      </div>


        <Chart forceFit height={400} data={don_data} scale={scale1}>
        <Tooltip showTitle={false} />
        <Axis />
        <Legend dataKey="item" />
        <Coord type="theta" radius={0.75} innerRadius={0.6} />
        <Pie position="percent" color="item" style={{ stroke: '#fff', lineWidth: 1 }}
          label={['percent', {
            formatter: (val, item) => {
              return item.point.item + ': ' + val;
            }
          }]}
        />
      </Chart>
                             </div>


        </Card>


      </Col>

<Col xs={24} sm={24} md={{span: 12, order: 4}} lg={12} xl={{span:12, order: 5}} className="c-mb">

        <Card
                title=""
                style={{ minHeight: "100%" }}
                bordered={false}
                className="mi-card mi-card-header-borderless mi-card-boxshadow" >
         <div id="chart">
        <select class="custom-select"  value={this.state.value_pie} onChange={this.handleSubmitPie}
                    style={{ width:"110px", marginLeft:"20px" }}>
                     <option  value="" >{this.state.select_status}</option>
                     {this.state.books.map((value,index)=>
                              {return   <option class="btn btn-custom btn-block btn-detail"
                              style={{ cursor: "pointer;", fontSize: "14px"}} key={index}> {value} </option> }
                              )}


                             </select>

                             <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#myModal_Pie" style={{marginLeft:"3px"}}>
                    Table View</button>
                      <div class="modal fade" id="myModal_Pie" role="dialog">
                        <div class="modal-dialog">
                          <div class="modal-content">
                            <div class="modal-header">
                             {/* <button type="button" class="close" data-dismiss="modal" style={{marginLeft:"1px"}}>&times;</button> */}
                              <h4 class="modal-title">Pie Chart TableData</h4>
                            </div>
                            <div class="modal-body">
                             <Table columns={this.state.pie_table_columns} dataSource={this.state.pie_table_data} style={{overflowY:"scroll"}}/>

                            </div>
                            <div class="modal-footer">
                              <button type="button" class="btn btn-info" data-dismiss="modal">Close</button>
                              <CSVLink data={this.state.download_pieChart_table}>
                              <button type="button" class="btn btn-primary" > Download </button>
                              </CSVLink>;
                            </div>
                          </div>

                        </div>
                      </div>


        <Chart forceFit height={400} data={pie_data} scale={scale} >
            <Tooltip showTitle={false} />
            <Coord type="theta" />
            <Axis />
            <Legend dataKey="item" />
                            <Pie
          position="percent"
          color="item"
          style={{ stroke: '#fff', lineWidth: 1 }}
          label={['percent', {
            formatter: (val, item) => {
              return item.point.item + ': ' + val;
            }
          }]}
        />
       </Chart>
                             </div>


        </Card>


      </Col>


 </Row>




<Row type="flex" gutter={24}>

<Col xs={24} sm={24} md={{span: 12, order: 4}} lg={12} xl={{span:12, order: 5}} className="c-mb">
            <Card
                title=""
                style={{ minHeight: "100%" }}
                bordered={false}
                className="mi-card mi-card-header-borderless mi-card-boxshadow" >
               <div id="chart">
                    <select class="custom-select"  value={this.state.value_mx} onChange={this.mixedCharthandleSubmit}
                        style={{ width:"110px", marginLeft:"8px" }}>
                         <option>Status</option>
                         {this.state.books.map((value,index)=>
                                  {return   <option class="btn btn-custom btn-block btn-detail"
                                  style={{ cursor: "pointer;", fontSize: "14px"}} key={index}> {value} </option> }
                                  )}
                   </select>
                   <select class="custom-select"  value={this.state.value_my} onChange={this.mixedCharthandleSubmit1}
                        style={{ width:"110px", marginLeft:"8px" }}>
                         <option>Amount_USD</option>
                         {this.state.intHeader.map((value,index)=>
                                  {return   <option class="btn btn-custom btn-block btn-detail"
                                  style={{ cursor: "pointer;", fontSize: "14px"}} key={index}> {value} </option> }
                                  )}
                   </select>
                   <select class="custom-select"  value={this.state.value_mz} onChange={this.mixedCharthandleSubmit2}
                        style={{ width:"110px", marginLeft:"8px" }}>
                         <option>Status</option>
                         {this.state.books.map((value,index)=>
                                  {return   <option class="btn btn-custom btn-block btn-detail"
                                  style={{ cursor: "pointer;", fontSize: "14px"}} key={index}> {value} </option> }
                                  )}
                   </select>
                   <React.Fragment>
                        <button onClick={this.mixed_handleSubmit} className='btn btn-info' style={{marginLeft:"15px"}}
                          type='button'>OK</button>
                    </React.Fragment>
                    <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#myModal_Mixed" style={{marginLeft:"3px"}}>
                    Table View</button>
                      <div class="modal fade" id="myModal_Mixed" role="dialog">
                        <div class="modal-dialog">
                          <div class="modal-content">
                            <div class="modal-header">
                             {/* <button type="button" class="close" data-dismiss="modal" style={{marginLeft:"1px"}}>&times;</button> */}
                              <h4 class="modal-title">Mixed Table Data</h4>
                            </div>
                            <div class="modal-body">
                             <Table columns={this.state.mix_table_columns} dataSource={this.state.mix_table_data} style={{overflowY:"scroll"}}/>

                            </div>
                            <div class="modal-footer">
                              <button type="button" class="btn btn-info" data-dismiss="modal">Close</button>
                              <CSVLink data={this.state.download_mixedChart_table}>
                              <button type="button" class="btn btn-primary" > Download </button>
                              </CSVLink>;
                            </div>
                          </div>

                        </div>
                      </div>

                  <ReactApexChart options={this.state.mixed_chart_options}
                  series={this.state.mixed_chart_series} type="line" width="420" height="350" />
             </div>
         </Card>
      </Col>

<Col xs={24} sm={24} md={{span: 12, order: 4}} lg={12} xl={{span:12, order: 5}} className="c-mb">
            <Card
                title=""
                style={{ minHeight: "100%" }}
                bordered={false}
                className="mi-card mi-card-header-borderless mi-card-boxshadow" >
               <div id="chart">
                    <select class="custom-select"  value={this.state.value_ax} onChange={this.Area_CharthandleSubmit}
                        style={{ width:"110px", marginLeft:"20px" }}>
                         <option>Xaxis</option>
                         {this.state.books.map((value,index)=>
                                  {return   <option class="btn btn-custom btn-block btn-detail"
                                  style={{ cursor: "pointer;", fontSize: "14px"}} key={index}> {value} </option> }
                                  )}
                   </select>
                   <select class="custom-select"  value={this.state.value_ay} onChange={this.Area_CharthandleSubmit1}
                        style={{ width:"110px", marginLeft:"20px" }}>
                         <option>Yaxis</option>
                         {this.state.intHeader.map((value,index)=>
                                  {return   <option class="btn btn-custom btn-block btn-detail"
                                  style={{ cursor: "pointer;", fontSize: "14px"}} key={index}> {value} </option> }
                                  )}
                   </select>
                   <React.Fragment>
                        <button onClick={this.area_handleSubmit} className='btn btn-info' style={{marginLeft:"10px"}}
                          type='button'>OK</button>
                    </React.Fragment>
                    <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#myModal_Stacked" style={{marginLeft:"3px"}}>
                    Table View</button>
                      <div class="modal fade" id="myModal_Stacked" role="dialog">
                        <div class="modal-dialog">
                          <div class="modal-content">
                            <div class="modal-header">
                             {/* <button type="button" class="close" data-dismiss="modal" style={{marginLeft:"1px"}}>&times;</button> */}
                              <h4 class="modal-title">Stacked Chart Table Data</h4>
                            </div>
                            <div class="modal-body">
                             <Table columns={this.state.area_table_columns} dataSource={this.state.area_table_data}
                             style={{overflowY:"scroll"}}/>

                            </div>
                            <div class="modal-footer">
                              <button type="button" class="btn btn-info" data-dismiss="modal">Close</button>
                              <CSVLink data={this.state.download_areaChart_table}>
                              <button type="button" class="btn btn-primary" > Download </button>
                              </CSVLink>;
                            </div>
                          </div>

                        </div>
                      </div>

                  <ReactApexChart options={this.state.area_chart_options}
                  series={this.state.area_chart_series} type="area" width="420" height="350" />
             </div>
         </Card>
      </Col>
</Row>
  <Row type="flex" gutter={24}>

     </Row>
        </div>
      </div>

    );
  }
}
export default AnalyticalTest;