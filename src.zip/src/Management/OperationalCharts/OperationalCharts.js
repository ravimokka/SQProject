import React, { Component } from "react";
import { Row, Col, Card, Button, Icon, Progress,Table } from "antd";

import LineChart from "./LineChart";
import BarChart from "./BarChart";
import VerticalChart from "./VerticalChart";
import DonutChart from "./DonutChart";
import PieChart from "./PieChart";
import GroupBarChart from "./GroupBarChart";
import MixedChart from "./MixedChart";
import AreaChart from "./AreaChart";
const DataSet = require("@antv/data-set");



class OperationalAllCharts extends Component {
  constructor(props) {
    super(props);
    this.state = {
      chartData: [],
      selectedKey: "daily"
    };

  }
  render() {
    return (
      <div>
        <div id="content">
          <Row type="flex" gutter={24}>
            <Col xs={24} sm={24} md={{span: 12, order: 4}} lg={12} xl={{span:12, order: 5}} className="c-mb">
              <Card
                title="Line Chart"
                style={{ minHeight: "100%" }}
                bordered={false}
                className="mi-card mi-card-header-borderless mi-card-boxshadow" >
                <div>
                  <LineChart />
                </div>
              </Card>
            </Col>

            <Col xs={24} sm={24} md={{span: 12, order: 4}} lg={12} xl={{span:12, order: 5}} className="c-mb">
              <Card
                title="Bar Chart"
                style={{ minHeight: "100%" }}
                bordered={false}
                className="mi-card mi-card-header-borderless mi-card-boxshadow" >
                <div>
                  <BarChart />
                </div>
              </Card>
            </Col>
          </Row>

          <Row type="flex" gutter={24}>
            <Col xs={24} sm={24} md={{span: 12, order: 4}} lg={12} xl={{span:12, order: 5}} className="c-mb">
              <Card
                title="Vertical Chart"
                style={{ minHeight: "100%" }}
                bordered={false}
                className="mi-card mi-card-header-borderless mi-card-boxshadow" >
                <div>
                  <VerticalChart />
                </div>
              </Card>
            </Col>

           <Col xs={24} sm={24} md={{span: 12, order: 4}} lg={12} xl={{span:12, order: 5}} className="c-mb">
              <Card
                title="GroupBar Chart"
                style={{ minHeight: "100%" }}
                bordered={false}
                className="mi-card mi-card-header-borderless mi-card-boxshadow" >
                <div>
                  <GroupBarChart />
                </div>
              </Card>
            </Col>

          </Row>
           <Row type="flex" gutter={24}>
            <Col xs={24} sm={24} md={{span: 12, order: 4}} lg={12} xl={{span:12, order: 5}} className="c-mb">
              <Card
                title="Pie Chart"
                style={{ minHeight: "100%" }}
                bordered={false}
                className="mi-card mi-card-header-borderless mi-card-boxshadow" >
                <div>
                  <PieChart />
                </div>
              </Card>
            </Col>

            <Col xs={24} sm={24} md={{span: 12, order: 4}} lg={12} xl={{span:12, order: 5}} className="c-mb">
              <Card
                title="Mixed Chart"
                style={{ minHeight: "100%" }}
                bordered={false}
                className="mi-card mi-card-header-borderless mi-card-boxshadow" >
                <div>
                  <MixedChart />
                </div>
              </Card>
            </Col>
          </Row>


           <Row type="flex" gutter={24}>
            <Col xs={24} sm={24} md={{span: 12, order: 4}} lg={12} xl={{span:12, order: 5}} className="c-mb">
              <Card
                title="Donut Chart"
                style={{ minHeight: "100%" }}
                bordered={false}
                className="mi-card mi-card-header-borderless mi-card-boxshadow" >
                <div>
                  <DonutChart />
                </div>
              </Card>
            </Col>

            <Col xs={24} sm={24} md={{span: 12, order: 4}} lg={12} xl={{span:12, order: 5}} className="c-mb">
              <Card
                title="Area Chart"
                style={{ minHeight: "100%" }}
                bordered={false}
                className="mi-card mi-card-header-borderless mi-card-boxshadow" >
                <div>
                  <AreaChart />
                </div>
              </Card>
            </Col>
          </Row>
          <Row type="flex" gutter={24}>
          </Row>

        </div>
      </div>
    );
  }
}
export default OperationalAllCharts;

