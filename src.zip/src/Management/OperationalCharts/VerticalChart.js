import { Chart, Tooltip, Axis, Legend, Pie, Coord, Line, Bar, Point} from 'viser-react';
import * as React from 'react';
import { Row, Col, Card, Button, Icon, Progress, Form , Modal, Table} from "antd";
import { Host } from  "../../Host";
import axios from "axios";
import ReactApexChart from 'react-apexcharts'
import 'bootstrap/dist/css/bootstrap.min.css';
import $ from 'jquery';
import Popper from 'popper.js';
import 'bootstrap/dist/js/bootstrap.bundle.min';
import { CSVLink } from "react-csv";
import { css } from "@emotion/core";
import { RingLoader} from "react-spinners";
const Menu_name = "Operational"
const DataSet = require('@antv/data-set');

const vertical_scale = [{
  dataKey: 'value',
  min: 0,
  formatter: function formatter(val) {
             if (val < 100000) {
                  return Math.round((val/1000) * 10)/10+'k';
                    }
            else if (val >= 1000000){

            return val=(val/1000000)+"M";

            }
             else {
                      return val;
                    }
  }
},{
  dataKey: 'year',
  min: 0,
  max: 1,
}];

class VerticalChart extends React.Component {

 constructor(props) {
    super(props);
   this.state = {
      books:[],
     intHeader:[],
     filter:[],
     select_group:"Group",
     select_amount_USD:"Amount_USD",
     chart_data:[],
     donut_data:[],
     pie_data:[],
     bar_data:[],
     ve_bar_data:[],
     line_data:[{name:"", 'A':1, 'B':12}],
     field_list:["A","B"],
     chartData: [],
     sourceData :[],
     line_chart_source_data:[{name: 'A', value: 13000000}],
     sourceData_donut:[],
     value_xl : "Status",
     value_yl : "Amount_USD",
     loading:true,

     table_columns : [{ title: 'Order Number',dataIndex: 'oNumber', key: 'oNumber',}],
     table_data : [{ key: '1', oNumber: 'DVO524',}],

     vertical_table_columns : [{ title: 'Order Number',dataIndex: 'oNumber', key: 'oNumber',}],
     vertical_table_data : [{ key: '1', oNumber: 'DVO524',}],

     download_verticalChart_table :[{ firstname: "Ravi", lastname: "Tomi", email: "ah@smthing.co.com" }],

      }
}


// ============================= Loading all charts ====================================================================

componentWillMount() {
    this.loadAnalytical();
     this.loadIntHeaders();
     this.loadAll_count_view();
  }

 async loadAnalytical()
  {
    const promise = await axios.post(Host.loginURL +"/header_api", {Menu:Menu_name});
    const status = promise.status;
    if(status===200)
    {
      const data = promise.data.data;
      console.log(data);
      this.setState({books:data});
    }
  }

async loadIntHeaders()
  {
    const promise = await axios.post(Host.loginURL +"/int_Header_api",{Menu:Menu_name});
    const status = promise.status;
    if(status===200)
    {
      const data = promise.data.data;
      console.log(data);
      this.setState({intHeader:data});
      const d = [{'name': 'Actual','data': []}, {'name': 'Budget','data': []}]
      const dou = [1,3,4]
      this.setState({donut_data:dou})
      this.setState({chart_data:d})
       console.log(this.state.chart_data);

    }
  }

async loadAll_count_view()
  {
    this.setState({table_columns : []})
    this.setState({table_data : []})

    this.setState({download_barChart_table:[]})
    this.setState({download_verticalChart_table:[]})
    this.setState({download_donutChart_table:[]})
    this.setState({download_pieChart_table:[]})
    const promise = await axios.post(Host.loginURL +"/load_count_api", {Column:'Group', Menu:Menu_name});
    const status = promise.status;
    if(status===200)
    {
      const data = promise.data.data;
      var table_dict = data
      var i;
      var keys_list =[];
      var bar_value_list =[];
      var load_chart_list = [];
      var load_donut_chart_list = [];
      var ct_list1 = [];
      var table_column_list = [];
      var table_data_list = [];
      var table_data_dict = {}
      for (i = 0; i < Object.keys(data).length; i++) {
            console.log(data[i])
            var key = Object.keys(data)[i]

            keys_list.push(key)
            if (key != "label"){
            ct_list1.push(key)

            }
            else{}

            var value = data[key]
            if (this.state.value_bar != value){bar_value_list.push(value)}
            else {
            }

            var data_dict = {};

            var load_data_dict = {};
            if (key != "label"){
            data_dict['name']=key;
            load_data_dict['item']=key;
            data_dict['value']=value;
            load_data_dict['count']=value;
            load_chart_list.push(data_dict)
            load_donut_chart_list.push(load_data_dict)
            var column_dict = {}
            column_dict['title'] =key;
            column_dict['dataIndex'] =key;
            column_dict['key'] =key;
            table_data_dict[key] = value;
            table_column_list.push(column_dict)
            }
            else{}
        }
      table_data_list.push(table_data_dict)
      this.setState({bar_data:load_chart_list})
      this.setState({ve_bar_data:load_chart_list})
      this.setState({sourceData:load_donut_chart_list})
      this.setState({sourceData_donut:load_donut_chart_list})

      this.setState({bar_table_columns:table_column_list})
      this.setState({bar_table_data:table_data_list})

      this.setState({vertical_table_columns:table_column_list})
      this.setState({vertical_table_data:table_data_list})

      this.setState({donut_table_columns:table_column_list})
      this.setState({donut_table_data:table_data_list})

      this.setState({pie_table_columns:table_column_list})
      this.setState({pie_table_data:table_data_list})

     this.setState({download_barChart_table:[table_dict]})
    this.setState({download_verticalChart_table:[table_dict]})
    this.setState({download_donutChart_table:[table_dict]})
    this.setState({download_pieChart_table:[table_dict]})
    this.setState({ loading: false })

    }
  }



//========================================== Vertical bar Chart ================================================================
handleSubmitVerticalBarChart = (e) => {
        e.preventDefault();
        this.setState({value_v_bar: e.target.value});
        this.setState({loading:true})
         this.VerticalBarCheckbox(
             {Column:e.target.value, Menu:Menu_name}
      );
 };


async VerticalBarCheckbox(data){
    const headers  = new Headers()
    headers.append('Content-Type', 'application/json');
    const options = {
    method : 'POST',
    headers,
    body:JSON.stringify(data),
    }

    this.setState({ve_bar_data : []})

    this.setState({vertical_table_columns:[]})
      this.setState({vertical_table_data:[]})


 this.setState({download_verticalChart_table:[]})
    const promise = await axios.post(Host.loginURL +"/count_api", options);
    const status = promise.status;
    if(status===200)
    {
      const data = promise.data.data;
      var table_dict = data;

      this.setState(data);
      console.log(data);
      var i;
      var keys_list =[];
      var bar_value_list =[];
      var Ve_Bar_chart_list = []
      var ct_list1 = []

      var table_column_list = [];
      var table_data_list = [];
      var table_data_dict = {}
      for (i = 0; i < Object.keys(data).length; i++) {
            console.log(data[i])
            var key = Object.keys(data)[i]

            keys_list.push(key)
            if (key != "label"){
            ct_list1.push(key)

            }
            else{}

            var value = data[key]
            if (this.state.value_bar != value){bar_value_list.push(value)}
            else {
            }

            var data_dict = {};
            if (key != "label"){
            data_dict['name']=key;
            data_dict['value']=value;
            Ve_Bar_chart_list.push(data_dict)

            var column_dict = {}
            column_dict['title'] =key;
            column_dict['dataIndex'] =key;
            column_dict['key'] =key;
            table_data_dict[key] = value;
            table_column_list.push(column_dict)



            }
            else{}
        }
     table_data_list.push(table_data_dict)
     this.setState({ve_bar_data:Ve_Bar_chart_list})
     this.setState({vertical_table_columns:table_column_list})
     this.setState({vertical_table_data:table_data_list})

     this.setState({download_verticalChart_table:[table_dict]})
     this.setState({loading:false})

    }

}

render() {
const ve_bar_dv = new DataSet.View().source(this.state.ve_bar_data);
ve_bar_dv.transform({
  type: 'sort',
  callback(a, b) {
    return a.value - b.value > 0;
  },
});
const vertical_bar_data = ve_bar_dv.rows;

const override = css`
  display: block;
  margin: 0 auto;
  border-color: red;
  loading: true;
  color: "red";
  css: "";
`;


    return (


   <div id="chart">
        <select class="custom-select"  value={this.state.value_v_bar} onChange={this.handleSubmitVerticalBarChart}
            style={{ width:"110px", marginLeft:"20px" }}>
             <option  value="" >{this.state.select_group}</option>
             {this.state.books.map((value,index)=>
                      {return   <option class="btn btn-custom btn-block btn-detail"
                      style={{ cursor: "pointer;", fontSize: "14px"}} key={index}> {value} </option> }
                      )}
       </select>
       <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#myModal_Vertical" style={{marginLeft:"3px"}}>
        Table View</button>
          <div class="modal fade" id="myModal_Vertical" role="dialog">
            <div class="modal-dialog">
              <div class="modal-content">
                <div class="modal-header">
                 {/* <button type="button" class="close" data-dismiss="modal" style={{marginLeft:"1px"}}>&times;</button> */}
                  <h4 class="modal-title">Vertical Bar Chart Table Data</h4>
                </div>
                <div class="modal-body">
                 <Table columns={this.state.vertical_table_columns} dataSource={this.state.vertical_table_data} style={{overflowY:"scroll"}}/>

                </div>
                <div class="modal-footer">
                  <button type="button" class="btn btn-info" data-dismiss="modal">Close</button>
                  <CSVLink data={this.state.download_verticalChart_table}>
                  <button type="button" class="btn btn-primary" > Download </button>
                  </CSVLink>;
                </div>
              </div>

            </div>
          </div>

           <RingLoader
              css={override}
              size={150} // or 150px
              color={"#123abc"}
              loading={this.state.loading}
              />
            <Chart forceFit height={400} data={vertical_bar_data} scale={vertical_scale}>
            <Tooltip />
            <Axis />
            <Bar position="name*value" />
            </Chart>
    </div>

    );
  }
}
export default VerticalChart;