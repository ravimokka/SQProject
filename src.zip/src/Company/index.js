import React, { Component } from 'react'

export class CompanyHome extends Component {
    render() {
        return (
            <div>
                Company Home
            </div>
        )
    }
}

export default CompanyHome
