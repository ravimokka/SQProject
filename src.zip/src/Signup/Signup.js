import React, { Component } from "react";
import {Link} from "react-router-dom";
import { Row, Col, Form, Icon, Input, Button, Checkbox } from "antd";
import { Host } from  "../Host";
import axios from "axios";
const FormItem = Form.Item;


class SignupForm extends Component {
  constructor(props) {
    super(props);
    this.state = {
    };

  }

  handleSubmit = (e) => {
    e.preventDefault();
    this.props.form.validateFields((err, values) => {
    const f_name =  values.fistName;
    const l_name =  values.lastName;
    const u_name =  values.username;
    const p_word =  values.password;
    const email =  values.email;
    const phone =  values.phone;
    const a_type =  values.accountType;
    const company =  values.company;
    const title =  values.title;
    const of_num =  values.officeNumber;
    const h_num =  values.homeNumber;
    const address =  values.address;
    if(f_name == null && f_name == null && u_name == null && p_word == null && email == null && phone == null &&
     a_type == null && company == null && title == null && of_num == null && h_num == null &&  address == null){
     return false
    }
    else{
        this.SignupAPI({

     first_name:f_name,
    last_name : l_name,
    username :u_name,
    password :  p_word,
    account_type :a_type,
    company : company,
    title : title,
    office_number :of_num,
    cell_number :  phone,
    home_number :h_num,
    email : email,
    address : address,
    'flog_value':'signUp'

                            })

    }
  });
};


  async SignupAPI(data){

    const headers  = new Headers()
    headers.append('Content-Type', 'application/json');
    const options = {
    method : 'POST',
    headers,
    body:JSON.stringify(data),
    }

    const promise = await axios.post(Host.loginURL+"/signup_api", options);
    const status = promise.status;
    if(status==200)
    {
      const data = promise.data.data;
      this.setState(data);
      this.props.history.push("/");
   }
   else {this.setState({msg: "Username & Password not correct"});}

}


  render() {
    localStorage.clear();
    const { getFieldDecorator } = this.props.form;
    return (
      <div className="login-form-container">
        <div className="header-login">
          <div className="login-logo">
            <img src="/assets/images/logo-white.png" alt="SQ"/>
          </div>
        </div>
        <div className="login-row">
          <div className="login-cell cell-login-hero" style={{backgroundImage: 'url(/assets/images/login-bg.jpg)'}}>
            <div className="login-cell-block">
              <div className="login-cell-content">
                <div className="login-hero-content">
                  <h1 className="login-heading">Welcome to SQ</h1>
                  <div className="login-subheading">
                    <p>
                    This is the new face of SQ. New look, new ideas, same core
                    </p>
                  </div>
                  <div className="website-link">
                    <Link to='http://webmamu.com/static/qcn/'>www.sqgc.com/</Link>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div className="login-cell cell-login-form">
            <div className="bg-image-mobile" style={{backgroundImage: 'url(/assets/images/login-bg.jpg)'}}></div>
            <div className="login-cell-block">
              <div className="login-logo text-center">
                <img src="/assets/images/logo-white.png" alt="SQ"/>
              </div>
              <div className="logo-with-form login-cell-content">
                <h4 className="mb-3">Signup with SQ</h4>
               <Form layout="inline" onSubmit={this.handleSubmit}>

        <Form.Item>
          <Row gutter={8}>
            <Col span={12}>
              {getFieldDecorator('fistName', {
                rules: [{ required: true, message: 'Please input the captcha you got!' }],
              })( <Input size="large" prefix={ <Icon type="user" style={{ color: "rgba(0,0,0,.25)" }} /> } type="" placeholder="FirstName" /> )}
            </Col>
             <Col span={12}>
              {getFieldDecorator('lastName', {
                rules: [{ required: true, message: 'Please input the captcha you got!' }],
              })( <Input size="large" prefix={ <Icon type="user" style={{ color: "rgba(0,0,0,.25)" }} /> } type="" placeholder="LastName" /> )}
            </Col>
          </Row>
        </Form.Item>

        <Form.Item>
          <Row gutter={8}>
            <Col span={12}>
              {getFieldDecorator('username', {
                rules: [{ required: true, message: 'Please input your Username!' }],
              })(<Input size="large" prefix={ <Icon type="usergroup-add" style={{ color: "rgba(0,0,0,.25)" }} /> } type="" placeholder="Username" /> )}
            </Col>
             <Col span={12}>
              {getFieldDecorator('password', {
                rules: [{ required: true, message: 'Please input your Password!' }],
              })(<Input size="large" prefix={ <Icon type="lock" style={{ color: "rgba(0,0,0,.25)" }} /> } type="" placeholder="Password" /> )}
            </Col>
          </Row>
        </Form.Item>
        <Form.Item>
          <Row gutter={8}>
            <Col span={12}>
              {getFieldDecorator('accountType', {
                rules: [{ required: true, message: 'Please input the captcha you got!' }],
              })(<Input size="large" prefix={ <Icon type="book" style={{ color: "rgba(0,0,0,.25)" }} /> } type="" placeholder="AccountType" /> )}
            </Col>
             <Col span={12}>
              {getFieldDecorator('company', {
                rules: [{ required: true, message: 'Please input the captcha you got!' }],
              })(<Input size="large" prefix={ <Icon type="home" style={{ color: "rgba(0,0,0,.25)" }} /> } type="" placeholder="Company" /> )}
            </Col>
          </Row>
        </Form.Item>

         <Form.Item>
          <Row gutter={8}>
            <Col span={12}>
              {getFieldDecorator('title', {
                rules: [{ required: true, message: 'Please input the captcha you got!' }],
              })(<Input size="large" prefix={ <Icon type="title" style={{ color: "rgba(0,0,0,.25)" }} /> } type="" placeholder="Title" /> )}
            </Col>
             <Col span={12}>
              {getFieldDecorator('officeNumber', {
                rules: [{ required: true, message: 'Please input the captcha you got!' }],
              })(<Input size="large" prefix={ <Icon type="office" style={{ color: "rgba(0,0,0,.25)" }} /> } type="" placeholder="OfficeNumber" /> )}
            </Col>
          </Row>
        </Form.Item>
        <Form.Item>
          <Row gutter={8}>
            <Col span={12}>
              {getFieldDecorator('phone', {
                rules: [{ required: true, message: 'Please input the captcha you got!' }],
              })(<Input size="large" prefix={ <Icon type="phone" style={{ color: "rgba(0,0,0,.25)" }} /> } type="" placeholder="Phone" /> )}
            </Col>
             <Col span={12}>
              {getFieldDecorator('homeNumber', {
                rules: [{ required: true, message: 'Please input the captcha you got!' }],
              })(<Input size="large" prefix={ <Icon type="home" style={{ color: "rgba(0,0,0,.25)" }} /> } type="" placeholder="HomeNumber" /> )}
            </Col>
          </Row>
        </Form.Item>
        <Form.Item>
          <Row gutter={8}>
            <Col span={12}>
              {getFieldDecorator('email', {
                rules: [{ required: true, message: 'Please input the captcha you got!' }],
              })(<Input size="large" prefix={ <Icon type="mail" style={{ color: "rgba(0,0,0,.25)" }} /> } type="" placeholder="Email" /> )}
            </Col>
             <Col span={12}>
              {getFieldDecorator('address', {
                rules: [{ required: true, message: 'Please input the captcha you got!' }],
              })(<Input size="large" prefix={ <Icon type="address" style={{ color: "rgba(0,0,0,.25)" }} /> } type="" placeholder="Address" /> )}
            </Col>
          </Row>
        </Form.Item>
                 <Form.Item>
                     <Button
                      type="primary"
                      htmlType="submit"
                      size="large"
                      className="login-form-button"
                      style={{ width: "100%" }}
                    >
                      Signup
                    </Button>
                 </Form.Item>


              <Form.Item>

                <Button
                  type="primary"
                  htmlType="submit"
                  size="large"
                  className="btn-info"
                  style={{ width: "100%" }}
                >
                  <Link to='/' style={{textDecoration:"none"}}>Cancel</Link>
                </Button>

              </Form.Item>
      </Form>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
}


const WrappedSignupForm = Form.create()(SignupForm);

export default WrappedSignupForm;
