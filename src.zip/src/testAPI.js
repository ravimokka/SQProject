
import axios from "axios";
const request = axios.post('http://127.0.0.1:4000/test_api', { firstName: 'Mokka Ravi', lastName: 'Flintstone' })



async add(data){

    const headers  = new Headers()
    headers.append('Content-Type', 'application/json');
    const options = {
    method : 'POST',
    headers,
    body:JSON.stringify({first_name: 'raveendra', last_name:"mokka"}),
    }

    const request = new Request("http://127.0.0.1:8900/api/v1/test_api", options);
    const response = await fetch(request);
    const status = await response.status;
    const responseJson = response.json();
    const test = response.data;
    console.log(test);

    if (status == 200 ){
//    alert("your request post! mokka ravi ")

    this.props.history.push("/workspace");

    }
}

