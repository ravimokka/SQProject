import React, { Component } from "react";
import { Form, Input, Select,Row, Table, Col,Card,Modal,Drawer,Button,Icon} from "antd";

import ModalDialog from "./ModalDialog";


class Reactjs extends Component{
 state = {
   isOpen:false

 }
render(){
   return(

   <div className="Reactjs">
  <button onClick={(e) => this.setState({isOpen:true})}> Table View</button>
    <ModalDialog isOpen={this.state.isOpen}  onClose={(e) => this.setState({isOpen:false })}>
    </ModalDialog>

   </div>
);
}
}

export default Reactjs;
