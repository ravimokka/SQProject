

const AppHost = {

  loginURL: "http://127.0.0.1:8070/api/sqd",

}
export default AppHost

