import { Home } from "../Personal/Home";
import { BidRequest } from "../Personal/BidRequest";
import { RequestProposal } from "../Personal/RequestProposal";
import { BankPersonal } from "../Personal/BankPersonal";
import { Analytical } from "../Personal/Analytical";
import { AnalyticalTest } from "../Personal/AnalyticalTest";
import { Reactjs } from "../Personal/TestRect";

import { Operations } from "../Personal/Operations";
import { Finance } from "../Personal/Finance";
import { AccountSetting } from "../Personal/AccountSetting";
import { CalendarPage } from "../Personal/Calendar";


import { ManagementHome } from "../Management/Home";
import { ManagementCharts } from "../Management/ManagementCharts";
import { OperationalCharts } from "../Management/OperationalCharts";
import { FinancialCharts } from "../Management/FinancialCharts";

const routes = [
  {
    path: "/personal-home",
    exact: true,
    component: Home
  },
  {
    path: "/bid-requests",
    exact: true,
    component: BidRequest
  },
  {
    path: "/request-for-proposal",
    exact: true,
    component: RequestProposal
  },
  {
    path: "/bank-parsonal",
    exact: true,
    component: BankPersonal
  },

  {
    path: "/analytical",
    exact: true,
    component: Analytical
  },

{
    path: "/analyticalTest",
    exact: true,
    component: AnalyticalTest
  },


  {
    path: "/testreact",
    exact: true,
    component: Reactjs
  },


  {
    path: "/calendar",
    exact: true,
    component: CalendarPage
  },
  {
    path: "/personal-operations",
    exact: true,
    component: Operations
  },
  {
    path: "/personal-finance",
    exact: true,
    component: Finance
  },
  {
    path: "/persoanl-account",
    exact: true,
    component: AccountSetting
  },
  {
    path: "/management-home",
    exact: true,
    component: ManagementHome
  },

  {
    path: "/management-charts",
    exact: true,
    component: ManagementCharts
  },
{
    path: "/operational-charts",
    exact: true,
    component: OperationalCharts
  },

  {
    path: "/financial-charts",
    exact: true,
    component: FinancialCharts
  },

];
export default routes;
